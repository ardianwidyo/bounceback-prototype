"""Time travel and context changes: advance_days and set_context (spec 023 US3)."""

from __future__ import annotations

from typing import Any

from engine.sandbox.checkin import refresh_progress
from engine.sandbox.commands import Event, Handler
from engine.sandbox.context import (
    add_days,
    fasting_window,
    latest_context,
    next_context_day,
    with_latest_context,
)
from engine.sandbox.proposals import propose_for_context
from engine.sandbox.radar import score_today
from engine.sandbox.recovery_flow import offer_quiet_downshift
from engine.sandbox.state import State
from engine.sandbox.trail import append_entry

CONTEXT_POLICY_VERSION = "context-1"
NIGHTS = "nights"
REGULAR_DAY = "regular_day"


def _next_day(state: State) -> State:
    on = add_days(state["current_date"], 1)
    day = next_context_day(latest_context(state), on)
    return {**state, "current_date": on, "context_days": [*state["context_days"], day]}


def _advance_days(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    assert state is not None  # the command schema requires a state
    working = state
    events: list[Event] = []
    for _ in range(command["days"]):
        working = _next_day(working)
        working, progress_events = refresh_progress(working)
        working, radar_events = score_today(working)
        working, offer_events = offer_quiet_downshift(working)
        events += [*progress_events, *radar_events, *offer_events]
    return working, events


def _apply_context(state: State, command: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    """The updated current-day context, and what changed (for the trail)."""
    day = dict(latest_context(state))
    changes: dict[str, Any] = {}

    if "night_shift_block" in command:
        if command["night_shift_block"]:
            if day["night_shift_block_day"] is None:
                day["night_shift_block_day"] = 1
            if day["work_pattern"] == REGULAR_DAY:
                day["work_pattern"] = NIGHTS  # a night-shift block means working nights
        else:
            day["night_shift_block_day"] = None
            day["work_pattern"] = state["profile"]["work_pattern"]
        changes["night_shift_block"] = command["night_shift_block"]

    if "work_pattern" in command and command["work_pattern"] != day["work_pattern"]:
        day["work_pattern"] = command["work_pattern"]
        day["pattern_change_day"] = 1
        changes["work_pattern"] = command["work_pattern"]

    if "ramadan" in command:
        if command["ramadan"]:
            if not day["ramadan"]:
                day["ramadan_day"] = 1
            day["ramadan"] = True
            day["fasting_window"] = fasting_window()
        else:
            day.update(ramadan=False, ramadan_day=None, fasting_window=None)
        changes["ramadan"] = command["ramadan"]
    return day, changes


def _set_context(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    assert state is not None  # the command schema requires a state
    day, changes = _apply_context(state, command)
    updated = append_entry(
        with_latest_context(state, day),
        decision_type="choice_recorded",
        on=state["current_date"],
        policy_version=CONTEXT_POLICY_VERSION,
        inputs_used={"changes": changes},
        excluded_sources=[],
        candidate_set=[],
        chosen="context_changed",
        propensities=[1.0],
        summary_key="trail.context_changed",
    )
    scored, events = score_today(updated)
    proposed, proposal_events = propose_for_context(scored)
    return proposed, [*events, *proposal_events]


HANDLERS: dict[str, Handler] = {"advance_days": _advance_days, "set_context": _set_context}
