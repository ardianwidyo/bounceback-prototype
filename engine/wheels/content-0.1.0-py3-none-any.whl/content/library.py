"""Load and validate the versioned micro-action library (FR-012 to FR-014)."""

import json
from collections import Counter
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from functools import cache
from importlib.resources import files
from pathlib import Path
from typing import Any, Literal, cast

import yaml

from content.copy_lint import lint_text
from content.validation import (
    ContentValidationError,
    ValidationIssue,
    describe,
    validate_document,
)

PACKAGE = files("content")
LIBRARY_SOURCE = "actions.yaml"
ACTIONS_LOCALES_SOURCE = "locales/actions_locales.yaml"
SUPPORTED_LOCALES: tuple[str, ...] = ("en", "ar", "ur", "hi", "tl", "ml")

EvidenceLevel = Literal["strong", "moderate", "emerging"]


class Behaviour(StrEnum):
    MOVEMENT = "movement"
    NUTRITION = "nutrition"
    SLEEP = "sleep"
    SMOKING_CESSATION = "smoking_cessation"


class Level(StrEnum):
    L1 = "L1"
    L2 = "L2"
    L3 = "L3"
    L4 = "L4"
    L5 = "L5"


@dataclass(frozen=True)
class LocalisedText:
    title: str
    instruction: str


@dataclass(frozen=True)
class WhyCardText:
    technique_label: str
    idea: str
    evidence_summary: str
    limits: tuple[str, ...]


@dataclass(frozen=True)
class WhyCard:
    evidence_level: EvidenceLevel
    en: WhyCardText
    ar: WhyCardText
    translations: Mapping[str, WhyCardText] = None  # type: ignore[assignment]

    def for_locale(self, locale: str) -> WhyCardText:
        if self.translations and locale in self.translations:
            return self.translations[locale]
        if locale == "ar":
            return self.ar
        return self.en


@dataclass(frozen=True)
class MicroAction:
    id: str
    behaviour: str
    level: str
    bct_codes: tuple[str, ...]
    duration_min: int
    text_en: LocalisedText
    text_ar: LocalisedText | None
    contraindications: tuple[str, ...]
    avoid_contexts: tuple[str, ...]
    why_card: WhyCard
    pictogram_id: str = ""
    translations: Mapping[str, LocalisedText] = None  # type: ignore[assignment]

    def text_for_locale(self, locale: str) -> LocalisedText:
        if self.translations and locale in self.translations:
            return self.translations[locale]
        if locale == "ar" and self.text_ar is not None:
            return self.text_ar
        return self.text_en


@dataclass(frozen=True)
class Library:
    version: str
    actions: tuple[MicroAction, ...]

    def get(self, action_id: str) -> MicroAction | None:
        for action in self.actions:
            if action.id == action_id:
                return action
        return None


@cache
def library_schema() -> Mapping[str, Any]:
    schema: dict[str, Any] = json.loads(
        PACKAGE.joinpath("schemas/action-library.schema.json").read_text(encoding="utf-8")
    )
    return schema


def parse_yaml(text: str, source: str) -> tuple[object, list[ValidationIssue]]:
    try:
        return yaml.safe_load(text), []
    except yaml.MarkedYAMLError as error:
        mark = error.problem_mark or error.context_mark
        line = f"line {mark.line + 1}" if mark else "unknown line"
        detail = f"{source}, {line}: invalid YAML ({error.problem})"
        return None, [ValidationIssue(None, "", "yaml_syntax", describe(None, "", detail))]


def duplicate_id_issues(data: object) -> list[ValidationIssue]:
    actions = data.get("actions") if isinstance(data, Mapping) else None
    if not isinstance(actions, list):
        return []
    ids = [a.get("id") for a in actions if isinstance(a, Mapping) and isinstance(a.get("id"), str)]
    return [
        ValidationIssue(
            action_id=action_id,
            path="actions",
            rule="duplicate_id",
            message=describe(action_id, "actions", f"id used by {count} actions"),
        )
        for action_id, count in Counter(ids).items()
        if count > 1
    ]


def why_card_copy_lint_issues(data: object) -> list[ValidationIssue]:
    actions = data.get("actions") if isinstance(data, Mapping) else None
    if not isinstance(actions, list):
        return []
    issues: list[ValidationIssue] = []
    for idx, action in enumerate(actions):
        if not isinstance(action, Mapping):
            continue
        action_id = action.get("id") if isinstance(action.get("id"), str) else None
        why_card = action.get("why_card")
        if not isinstance(why_card, Mapping):
            continue
        for loc in ("en", "ar"):
            card_loc = why_card.get(loc)
            if not isinstance(card_loc, Mapping):
                continue
            for field_name in ("technique_label", "idea", "evidence_summary"):
                val = card_loc.get(field_name)
                if isinstance(val, str):
                    path = f"actions/{idx}/why_card/{loc}/{field_name}"
                    for v in lint_text(val, source=LIBRARY_SOURCE, field_path=path):
                        issues.append(
                            ValidationIssue(
                                action_id=action_id,
                                path=path,
                                rule="copy_lint",
                                message=describe(
                                    action_id,
                                    path,
                                    f"blame-free copy violation ({v.matched_term})",
                                ),
                            )
                        )
            limits = card_loc.get("limits")
            if isinstance(limits, list):
                for lim_idx, lim_val in enumerate(limits):
                    if isinstance(lim_val, str):
                        path = f"actions/{idx}/why_card/{loc}/limits/{lim_idx}"
                        for v in lint_text(lim_val, source=LIBRARY_SOURCE, field_path=path):
                            issues.append(
                                ValidationIssue(
                                    action_id=action_id,
                                    path=path,
                                    rule="copy_lint",
                                    message=describe(
                                        action_id,
                                        path,
                                        f"blame-free copy violation ({v.matched_term})",
                                    ),
                                )
                            )
    return issues


def validate_library(data: object) -> list[ValidationIssue]:
    return (
        validate_document(library_schema(), data)
        + duplicate_id_issues(data)
        + why_card_copy_lint_issues(data)
    )


def validate_library_file(path: Path) -> list[ValidationIssue]:
    data, issues = parse_yaml(path.read_text(encoding="utf-8"), path.name)
    return issues or validate_library(data)


def to_text(raw: Mapping[str, str] | None) -> LocalisedText | None:
    return LocalisedText(raw["title"], raw["instruction"]) if raw else None


def to_why_card_text(raw: Mapping[str, Any]) -> WhyCardText:
    return WhyCardText(
        technique_label=raw["technique_label"],
        idea=raw["idea"],
        evidence_summary=raw["evidence_summary"],
        limits=tuple(raw["limits"]),
    )


@cache
def _load_actions_locales_map() -> Mapping[str, Any]:
    raw_text = PACKAGE.joinpath(ACTIONS_LOCALES_SOURCE).read_text(encoding="utf-8")
    parsed = yaml.safe_load(raw_text)
    if isinstance(parsed, Mapping) and isinstance(parsed.get("actions"), Mapping):
        return cast(Mapping[str, Any], parsed["actions"])
    return {}


def to_why_card(
    raw: Mapping[str, Any],
    extra_why: Mapping[str, Any] | None = None,
) -> WhyCard:
    en_card = to_why_card_text(raw["en"])
    ar_card = to_why_card_text(raw["ar"])
    translations: dict[str, WhyCardText] = {
        "en": en_card,
        "ar": ar_card,
    }
    if extra_why:
        for loc in ("ur", "hi", "tl", "ml"):
            loc_raw = extra_why.get(loc)
            if isinstance(loc_raw, Mapping):
                translations[loc] = to_why_card_text(loc_raw)
    return WhyCard(
        evidence_level=cast(EvidenceLevel, raw["evidence_level"]),
        en=en_card,
        ar=ar_card,
        translations=translations,
    )


def to_action(
    raw: Mapping[str, Any],
    locales_map: Mapping[str, Any] | None = None,
) -> MicroAction:
    action_id = str(raw["id"])
    text_en = to_text(raw["text"]["en"])
    assert text_en is not None  # guaranteed by the schema
    text_ar = to_text(raw["text"].get("ar"))

    extra = locales_map.get(action_id, {}) if locales_map else {}
    extra_text_map = extra.get("text", {}) if isinstance(extra, Mapping) else {}
    extra_why_map = extra.get("why_card", {}) if isinstance(extra, Mapping) else {}
    pictogram_id = (
        str(extra.get("pictogram_id", action_id)) if isinstance(extra, Mapping) else action_id
    )

    translations: dict[str, LocalisedText] = {"en": text_en}
    if text_ar is not None:
        translations["ar"] = text_ar
    if isinstance(extra_text_map, Mapping):
        for loc in ("ur", "hi", "tl", "ml"):
            loc_raw = extra_text_map.get(loc)
            if isinstance(loc_raw, Mapping):
                parsed_loc = to_text(loc_raw)
                if parsed_loc is not None:
                    translations[loc] = parsed_loc

    return MicroAction(
        id=action_id,
        behaviour=raw["behaviour"],
        level=raw["level"],
        bct_codes=tuple(raw["bct_codes"]),
        duration_min=raw["duration_min"],
        text_en=text_en,
        text_ar=text_ar,
        contraindications=tuple(raw["contraindications"]),
        avoid_contexts=tuple(raw["avoid_contexts"]),
        why_card=to_why_card(
            raw["why_card"],
            extra_why=extra_why_map if isinstance(extra_why_map, Mapping) else None,
        ),
        pictogram_id=pictogram_id,
        translations=translations,
    )


def _read_validated(path: Path | None) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    """Parse and validate a library file; return ``(data, locales_map)``."""
    if path is None:
        text, source = PACKAGE.joinpath(LIBRARY_SOURCE).read_text(encoding="utf-8"), LIBRARY_SOURCE
    else:
        text, source = path.read_text(encoding="utf-8"), path.name
    data, issues = parse_yaml(text, source)
    issues = issues or validate_library(data)
    if issues:
        raise ContentValidationError(issues)
    assert isinstance(data, Mapping)
    return data, _load_actions_locales_map()


def _build_library(data: Mapping[str, Any], locales_map: Mapping[str, Any]) -> Library:
    return Library(
        version=data["version"],
        actions=tuple(to_action(a, locales_map=locales_map) for a in data["actions"]),
    )


def load_library(path: Path | None = None) -> Library:
    """Parse and validate a library file (default: the packaged seed library).

    Raises ContentValidationError listing every issue when the file is invalid.
    """
    data, locales_map = _read_validated(path)
    return _build_library(data, locales_map)


def export_library_payload(path: Path | None = None) -> dict[str, Any]:
    """Validate the library and return a JSON-serialisable payload for the browser build.

    The payload holds the raw actions plus the locale map, so ``load_library_from_json`` can rebuild
    an equal Library without importing jsonschema.
    """
    data, locales_map = _read_validated(path)
    payload = {"version": data["version"], "actions": data["actions"], "locales": locales_map}
    return cast(dict[str, Any], json.loads(json.dumps(payload)))


def load_library_from_json(payload: Mapping[str, Any]) -> Library:
    """Build a Library from a payload made by ``export_library_payload`` (already validated)."""
    return _build_library(payload, payload["locales"])
