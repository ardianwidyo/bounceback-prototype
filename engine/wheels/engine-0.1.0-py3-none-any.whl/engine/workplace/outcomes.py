"""Pilot-aligned Workplace Impact Report evaluator and reproducibility digest (T020)."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Sequence
from uuid import uuid5

from engine.aggregates import TeamMemberContribution
from engine.outcome_metrics import (
    EQUITY_GAP_THRESHOLD_POINTS,
    ILLUSTRATIVE_LABEL_AR,
    ILLUSTRATIVE_LABEL_EN,
    _compute_pilot_arm_kpi_summary,
)
from engine.simulator import (
    LANGUAGES,
    WORK_PATTERNS,
    SimulatedLapseEpisode,
    SyntheticUserPersona,
    UserArmTrajectory,
)
from engine.workplace.models import (
    MIN_WORKPLACE_K_ANONYMITY,
    WorkplaceChallengeAggregateView,
    WorkplaceCooperativeChallenge,
    WorkplaceEmployeeEnrollment,
    WorkplaceImpactReport,
    WorkplaceOrganisation,
    WorkplaceSubgroupDimension,
    WorkplaceSubgroupOutcomeRow,
    WorkplaceSustainedOutcomesPayload,
)
from engine.workplace.suppression import (
    PRIVACY_NOTICE_SUPPRESSED_AR,
    PRIVACY_NOTICE_SUPPRESSED_EN,
    PRIVACY_NOTICE_VISIBLE_AR,
    PRIVACY_NOTICE_VISIBLE_EN,
    apply_complementary_k_suppression,
    compute_challenge_aggregate,
)
from engine.workplace.synthetic import SyntheticWorkplaceCohort
from engine.workplace.terms import get_employer_terms_policy

_SYNTHETIC_NAMESPACE = SyntheticWorkplaceCohort  # reference for typing
_ENROLL_NAMESPACE_UUID = "d3221190-54f9-4b11-8e56-9a3f28e79a12"

WORKPLACE_DIMENSIONS: tuple[tuple[WorkplaceSubgroupDimension, tuple[str, ...]], ...] = (
    ("work_pattern", WORK_PATTERNS),
    ("language", LANGUAGES),
)


def _round1(val: float) -> float:
    return round(val, 1)


def _suppressed_outcomes() -> WorkplaceSustainedOutcomesPayload:
    return WorkplaceSustainedOutcomesPayload(
        suppressed_k_anonymity=True,
        persistence_week_12=None,
        persistence_week_26=None,
        lapse_recovery_rate_14d=None,
        median_recovery_days=None,
        weekly_mvpa_minutes=None,
        retention_week_26=None,
        notification_opt_out_rate=None,
        mean_autonomy_support_score=None,
        mean_active_days=None,
    )


def _suppressed_subgroup_row(
    *,
    dimension: WorkplaceSubgroupDimension,
    subgroup: str,
    n: int,
    complementary_suppression: bool,
) -> WorkplaceSubgroupOutcomeRow:
    return WorkplaceSubgroupOutcomeRow(
        dimension=dimension,
        subgroup=subgroup,
        n=n,
        suppressed_k_anonymity=True,
        complementary_suppression=complementary_suppression,
        persistence_week_12=None,
        persistence_week_26=None,
        lapse_recovery_rate_14d=None,
        median_recovery_days=None,
        weekly_mvpa_minutes=None,
        retention_week_26=None,
        notification_opt_out_rate=None,
        mean_autonomy_support_score=None,
        mean_active_days=None,
        persistence_gap_points=None,
        recovery_gap_points=None,
        autonomy_gap_points=None,
        equity_gap_flagged=False,
    )


def _synthesize_persona_and_trajectory_for_enrollment(
    enrollment: WorkplaceEmployeeEnrollment,
    horizon_weeks: int,
) -> tuple[SyntheticUserPersona, UserArmTrajectory]:
    """Create a deterministic synthetic persona + trajectory for a runtime-enrolled employee."""
    uid_str = str(enrollment.user_id)
    persona = SyntheticUserPersona(
        user_id=uid_str,
        synthetic=True,
        language="en",
        nationality_group="emirati",
        sex="female",
        age_band="30-44",
        work_pattern="day",
        disability="none",
        behaviours=("movement", "sleep"),
        preferred_window="evening",
        preferred_channel="app",
        base_adherence_prob=0.8,
        night_shift_lapse_prob=0.15,
        primary_barrier="time",
        opt_out_sensitivity=0.05,
    )
    traj = UserArmTrajectory(
        user_id=uid_str,
        arm="adaptive",
        weekly_active=tuple(True for _ in range(horizon_weeks)),
        cumulative_active_days=88,
        retained_at_w12=True,
        retained_at_w26=True,
        notification_opted_out=False,
        lapse_episodes=(
            SimulatedLapseEpisode(
                onset_day=28,
                recovered=True,
                recovery_days=4,
                recovered_within_14d=True,
                step_down_applied=True,
            ),
        ),
    )
    return persona, traj


def compute_workplace_reproducibility_digest(report: WorkplaceImpactReport) -> str:
    """Compute a deterministic 64-character SHA-256 hex digest of the aggregate report payload."""
    canonical = {
        "org_slug": report.org_slug,
        "active_participants": report.active_participants,
        "enrolled_without_team_count": report.enrolled_without_team_count,
        "min_k_threshold": report.min_k_threshold,
        "suppressed_k_anonymity": report.suppressed_k_anonymity,
        "terms_version": report.non_punitive_terms.version,
        "outcomes": {
            "suppressed_k_anonymity": report.outcomes.suppressed_k_anonymity,
            "persistence_week_12": report.outcomes.persistence_week_12,
            "persistence_week_26": report.outcomes.persistence_week_26,
            "lapse_recovery_rate_14d": report.outcomes.lapse_recovery_rate_14d,
            "median_recovery_days": report.outcomes.median_recovery_days,
            "weekly_mvpa_minutes": report.outcomes.weekly_mvpa_minutes,
            "retention_week_26": report.outcomes.retention_week_26,
            "notification_opt_out_rate": report.outcomes.notification_opt_out_rate,
            "mean_autonomy_support_score": report.outcomes.mean_autonomy_support_score,
            "mean_active_days": report.outcomes.mean_active_days,
        },
        "subgroups": [
            {
                "dimension": row.dimension,
                "subgroup": row.subgroup,
                "n": row.n,
                "suppressed_k_anonymity": row.suppressed_k_anonymity,
                "complementary_suppression": row.complementary_suppression,
                "persistence_week_26": row.persistence_week_26,
                "lapse_recovery_rate_14d": row.lapse_recovery_rate_14d,
                "equity_gap_flagged": row.equity_gap_flagged,
            }
            for row in report.subgroups
        ],
        "challenges": [
            {
                "challenge_slug": ch.challenge_slug,
                "team_slug": ch.team_slug,
                "member_count": ch.member_count,
                "suppressed_k_anonymity": ch.suppressed_k_anonymity,
                "complementary_suppression": ch.complementary_suppression,
                "total_completed_actions": ch.total_completed_actions,
                "total_active_days": ch.total_active_days,
            }
            for ch in report.challenges
        ],
    }
    encoded = json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def compute_workplace_impact_report(
    *,
    organisation: WorkplaceOrganisation,
    cohort: SyntheticWorkplaceCohort,
    extra_enrollments: Sequence[WorkplaceEmployeeEnrollment] = (),
    challenges: Sequence[WorkplaceCooperativeChallenge] = (),
    min_k: int = MIN_WORKPLACE_K_ANONYMITY,
) -> WorkplaceImpactReport:
    """Compute a pilot-aligned Workplace Impact Report enforcing primary + complementary k>=20."""
    effective_k = max(min_k, MIN_WORKPLACE_K_ANONYMITY)
    terms_policy = get_employer_terms_policy()

    # Merge baseline seeded enrollments with any runtime enrollments/leaves by user_id
    enrollment_by_user: dict[str, WorkplaceEmployeeEnrollment] = {
        str(e.user_id): e for e in cohort.enrollments
    }
    for extra in extra_enrollments:
        if extra.org_slug == organisation.org_slug:
            enrollment_by_user[str(extra.user_id)] = extra
        elif str(extra.user_id) in enrollment_by_user and extra.status == "active":
            # User switched organisation after leaving
            del enrollment_by_user[str(extra.user_id)]

    active_enrollments = [e for e in enrollment_by_user.values() if e.status == "active"]

    # Map seeded personas and trajectories by their deterministic UUID string
    from uuid import UUID

    ns = UUID(_ENROLL_NAMESPACE_UUID)
    seeded_persona_by_uuid: dict[str, SyntheticUserPersona] = {}
    seeded_traj_by_uuid: dict[str, UserArmTrajectory] = {}
    traj_by_persona_id = {t.user_id: t for t in cohort.trajectories}
    for p in cohort.personas:
        u_str = str(uuid5(ns, p.user_id))
        seeded_persona_by_uuid[u_str] = p
        if p.user_id in traj_by_persona_id:
            seeded_traj_by_uuid[u_str] = traj_by_persona_id[p.user_id]

    active_personas: list[SyntheticUserPersona] = []
    active_trajectories: list[UserArmTrajectory] = []
    for e in active_enrollments:
        ukey = str(e.user_id)
        if ukey in seeded_persona_by_uuid and ukey in seeded_traj_by_uuid:
            active_personas.append(seeded_persona_by_uuid[ukey])
            active_trajectories.append(seeded_traj_by_uuid[ukey])
        else:
            synth_p, synth_t = _synthesize_persona_and_trajectory_for_enrollment(
                e, cohort.horizon_weeks
            )
            active_personas.append(synth_p)
            active_trajectories.append(synth_t)

    n_active = len(active_personas)
    raw_without_team = sum(1 for e in active_enrollments if e.team_slug is None)
    org_suppressed = n_active < effective_k

    # Evaluate cooperative challenges
    active_team_members: dict[str, list[TeamMemberContribution]] = {}
    base_contribs_by_team = {
        tslug: {c.member_key: c for c in contribs}
        for tslug, contribs in cohort.team_contributions.items()
    }
    for e in active_enrollments:
        if e.team_slug is None:
            continue
        team_list = active_team_members.setdefault(e.team_slug, [])
        ukey = str(e.user_id)
        existing_c = base_contribs_by_team.get(e.team_slug, {}).get(ukey)
        if existing_c is not None:
            team_list.append(existing_c)
        else:
            team_list.append(
                TeamMemberContribution(
                    member_key=ukey,
                    completed_actions=24,
                    active_days=18,
                )
            )

    challenge_views: list[WorkplaceChallengeAggregateView] = []
    challenge_counts: list[int] = []
    for ch in challenges:
        if ch.team_slug in active_team_members:
            contribs = tuple(active_team_members[ch.team_slug])
        elif ch.synthetic_member_count > 0 and ch.team_slug not in cohort.team_contributions:
            # Newly created challenge with synthetic member count
            per_member_actions = max(
                1, ch.synthetic_completed_actions // max(1, ch.synthetic_member_count)
            )
            per_member_days = max(1, ch.synthetic_active_days // max(1, ch.synthetic_member_count))
            contribs = tuple(
                TeamMemberContribution(
                    member_key=f"{ch.challenge_slug}-m-{idx}",
                    completed_actions=per_member_actions,
                    active_days=per_member_days,
                )
                for idx in range(ch.synthetic_member_count)
            )
        else:
            contribs = ()
        challenge_counts.append(len(contribs))

    # Apply complementary suppression across teams + without-team bucket
    team_partition_counts = [*challenge_counts, raw_without_team]
    team_comp_flags = apply_complementary_k_suppression(
        team_partition_counts,
        min_k=effective_k,
    )

    for idx, ch in enumerate(challenges):
        if ch.team_slug in active_team_members:
            contribs = tuple(active_team_members[ch.team_slug])
        elif ch.synthetic_member_count > 0 and ch.team_slug not in cohort.team_contributions:
            per_member_actions = max(
                1, ch.synthetic_completed_actions // max(1, ch.synthetic_member_count)
            )
            per_member_days = max(1, ch.synthetic_active_days // max(1, ch.synthetic_member_count))
            contribs = tuple(
                TeamMemberContribution(
                    member_key=f"{ch.challenge_slug}-m-{i}",
                    completed_actions=per_member_actions,
                    active_days=per_member_days,
                )
                for i in range(ch.synthetic_member_count)
            )
        else:
            contribs = ()
        comp_flag = bool(team_comp_flags[idx]) if not org_suppressed else False
        challenge_views.append(
            compute_challenge_aggregate(
                ch,
                contribs,
                complementary_suppression=comp_flag or org_suppressed,
                min_k=effective_k,
            )
        )

    # Expose without-team count when the organisation cohort satisfies k >= 20
    exposed_without_team: int | None = None if org_suppressed else raw_without_team

    if org_suppressed:
        outcomes_payload = _suppressed_outcomes()
        subgroup_rows: list[WorkplaceSubgroupOutcomeRow] = []
        for dimension, subgroup_values in WORKPLACE_DIMENSIONS:
            for subgroup in subgroup_values:
                matching_n = sum(1 for p in active_personas if getattr(p, dimension) == subgroup)
                subgroup_rows.append(
                    _suppressed_subgroup_row(
                        dimension=dimension,
                        subgroup=subgroup,
                        n=matching_n,
                        complementary_suppression=False,
                    )
                )
    else:
        kpi = _compute_pilot_arm_kpi_summary(
            "adaptive",
            tuple(active_personas),
            tuple(active_trajectories),
            cohort.horizon_weeks,
        )
        outcomes_payload = WorkplaceSustainedOutcomesPayload(
            suppressed_k_anonymity=False,
            persistence_week_12=float(kpi["persistence_week12"]),
            persistence_week_26=float(kpi["persistence_week26"]),
            lapse_recovery_rate_14d=float(kpi["lapse_recovery_rate14d"]),
            median_recovery_days=float(kpi["median_recovery_days"]),
            weekly_mvpa_minutes=float(kpi["weekly_mvpa_minutes_mean"]),
            retention_week_26=float(kpi["retention_week26"]),
            notification_opt_out_rate=float(kpi["notification_opt_out_rate"]),
            mean_autonomy_support_score=float(kpi["mean_autonomy_support_score"]),
            mean_active_days=float(kpi["mean_active_days"]),
        )

        overall_w26 = float(kpi["persistence_week26"])
        overall_rec = float(kpi["lapse_recovery_rate14d"])
        overall_aut = float(kpi["mean_autonomy_support_score"])
        traj_by_pid = {t.user_id: t for t in active_trajectories}

        subgroup_rows = []
        for dimension, subgroup_values in WORKPLACE_DIMENSIONS:
            dim_personas: list[
                tuple[str, tuple[SyntheticUserPersona, ...], tuple[UserArmTrajectory, ...]]
            ] = []
            for subgroup in subgroup_values:
                m_personas = tuple(
                    p
                    for p in active_personas
                    if getattr(p, dimension) == subgroup and p.user_id in traj_by_pid
                )
                m_trajs = tuple(traj_by_pid[p.user_id] for p in m_personas)
                dim_personas.append((subgroup, m_personas, m_trajs))

            dim_counts = [len(item[1]) for item in dim_personas]
            comp_flags = apply_complementary_k_suppression(dim_counts, min_k=effective_k)

            for idx, (subgroup, m_personas, m_trajs) in enumerate(dim_personas):
                n_sub = len(m_personas)
                is_comp = bool(comp_flags[idx])
                if n_sub < effective_k or is_comp:
                    subgroup_rows.append(
                        _suppressed_subgroup_row(
                            dimension=dimension,
                            subgroup=subgroup,
                            n=n_sub,
                            complementary_suppression=is_comp,
                        )
                    )
                    continue

                sub_kpi = _compute_pilot_arm_kpi_summary(
                    "adaptive",
                    m_personas,
                    m_trajs,
                    cohort.horizon_weeks,
                )
                sub_w26 = float(sub_kpi["persistence_week26"])
                sub_rec = float(sub_kpi["lapse_recovery_rate14d"])
                sub_aut = float(sub_kpi["mean_autonomy_support_score"])
                p_gap = _round1(sub_w26 - overall_w26)
                r_gap = _round1(sub_rec - overall_rec)
                a_gap = round(sub_aut - overall_aut, 2)
                flagged = (
                    (p_gap < EQUITY_GAP_THRESHOLD_POINTS)
                    or (r_gap < EQUITY_GAP_THRESHOLD_POINTS)
                    or (a_gap < -0.5)
                )
                subgroup_rows.append(
                    WorkplaceSubgroupOutcomeRow(
                        dimension=dimension,
                        subgroup=subgroup,
                        n=n_sub,
                        suppressed_k_anonymity=False,
                        complementary_suppression=False,
                        persistence_week_12=float(sub_kpi["persistence_week12"]),
                        persistence_week_26=sub_w26,
                        lapse_recovery_rate_14d=sub_rec,
                        median_recovery_days=float(sub_kpi["median_recovery_days"]),
                        weekly_mvpa_minutes=float(sub_kpi["weekly_mvpa_minutes_mean"]),
                        retention_week_26=float(sub_kpi["retention_week26"]),
                        notification_opt_out_rate=float(sub_kpi["notification_opt_out_rate"]),
                        mean_autonomy_support_score=sub_aut,
                        mean_active_days=float(sub_kpi["mean_active_days"]),
                        persistence_gap_points=p_gap,
                        recovery_gap_points=r_gap,
                        autonomy_gap_points=a_gap,
                        equity_gap_flagged=flagged,
                    )
                )

    draft_report = WorkplaceImpactReport(
        org_slug=organisation.org_slug,
        org_name_en=organisation.name_en,
        org_name_ar=organisation.name_ar,
        sector=organisation.sector,
        synthetic=True,
        illustrative_label_en=ILLUSTRATIVE_LABEL_EN,
        illustrative_label_ar=ILLUSTRATIVE_LABEL_AR,
        active_participants=n_active,
        enrolled_without_team_count=exposed_without_team,
        min_k_threshold=effective_k,
        suppressed_k_anonymity=org_suppressed,
        privacy_notice_en=(
            PRIVACY_NOTICE_SUPPRESSED_EN if org_suppressed else PRIVACY_NOTICE_VISIBLE_EN
        ),
        privacy_notice_ar=(
            PRIVACY_NOTICE_SUPPRESSED_AR if org_suppressed else PRIVACY_NOTICE_VISIBLE_AR
        ),
        non_punitive_terms=terms_policy,
        outcomes=outcomes_payload,
        subgroups=tuple(subgroup_rows),
        challenges=tuple(challenge_views),
        reproducibility_digest="",
    )
    digest = compute_workplace_reproducibility_digest(draft_report)
    return WorkplaceImpactReport(
        org_slug=draft_report.org_slug,
        org_name_en=draft_report.org_name_en,
        org_name_ar=draft_report.org_name_ar,
        sector=draft_report.sector,
        synthetic=draft_report.synthetic,
        illustrative_label_en=draft_report.illustrative_label_en,
        illustrative_label_ar=draft_report.illustrative_label_ar,
        active_participants=draft_report.active_participants,
        enrolled_without_team_count=draft_report.enrolled_without_team_count,
        min_k_threshold=draft_report.min_k_threshold,
        suppressed_k_anonymity=draft_report.suppressed_k_anonymity,
        privacy_notice_en=draft_report.privacy_notice_en,
        privacy_notice_ar=draft_report.privacy_notice_ar,
        non_punitive_terms=draft_report.non_punitive_terms,
        outcomes=draft_report.outcomes,
        subgroups=draft_report.subgroups,
        challenges=draft_report.challenges,
        reproducibility_digest=digest,
    )
