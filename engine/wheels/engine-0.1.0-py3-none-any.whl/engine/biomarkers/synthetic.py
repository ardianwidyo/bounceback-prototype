"""Seeded synthetic Malaffi data (F21 FR-020; research R7). No real health data, ever.

``generate_observations`` returns flat FHIR-like ``Observation`` dicts for one synthetic
participant across the three windows, plus deliberate noise the pipeline must reject: an
out-of-scope creatinine result, a ``Condition`` resource and mixed units.
"""

from __future__ import annotations

import random
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from typing import TYPE_CHECKING, Final, Literal

from engine.biomarkers.catalog import BIOMARKER_CATALOG, BiomarkerCode
from engine.biomarkers.validation import BiomarkerResult
from engine.biomarkers.windows import WindowType

if TYPE_CHECKING:
    from engine.biomarkers.change import BiomarkerChange

Observation = dict[str, object]
SyntheticProfile = Literal["default", "safety_boundary"]

# Day offsets from enrolment for each window's result(s); a second, farther baseline HbA1c
# exercises closest-to-target selection.
_WINDOW_OFFSETS: Final = (("baseline", -12), ("month_6", 179), ("month_12", 368))
_EXTRA_BASELINE_OFFSET: Final = -70


class MalaffiUnavailableError(RuntimeError):
    """The (synthetic) Malaffi service did not answer; retrieval is retried later."""


def _obs(resource_id: str, loinc: str, value: Decimal, unit: str, on: date) -> Observation:
    return {
        "resourceType": "Observation",
        "id": resource_id,
        "code": loinc,
        "value": str(value),
        "unit": unit,
        "effectiveDate": on.isoformat(),
    }


def _bp_panel(resource_id: str, systolic: int, diastolic: int, on: date) -> Observation:
    return {
        "resourceType": "Observation",
        "id": resource_id,
        "code": "85354-9",
        "effectiveDate": on.isoformat(),
        "components": [
            {"code": "8480-6", "value": str(systolic), "unit": "mm[Hg]"},
            {"code": "8462-4", "value": str(diastolic), "unit": "mm[Hg]"},
        ],
    }


def _dec(rng: random.Random, low: float, high: float, places: int = 1) -> Decimal:
    return Decimal(str(round(rng.uniform(low, high), places)))


def _window_observations(
    rng: random.Random, prefix: str, index: int, on: date, profile: SyntheticProfile
) -> list[Observation]:
    drift = Decimal(index) * _dec(rng, -0.3, 0.1)
    hba1c_pct = (_dec(rng, 5.6, 7.2) + drift).quantize(Decimal("0.1"))
    systolic = 184 if profile == "safety_boundary" else rng.randint(118, 146) - index * 2
    diastolic = rng.randint(72, 92) - index
    ldl_mg = Decimal(rng.randint(95, 160))
    first_visit = index == 0
    return [
        (
            _obs(f"{prefix}-hba1c-{index}", "59261-8", _mmol_mol(hba1c_pct), "mmol/mol", on)
            if first_visit
            else _obs(f"{prefix}-hba1c-{index}", "4548-4", hba1c_pct, "%", on)
        ),
        _bp_panel(f"{prefix}-bp-{index}", systolic, diastolic, on),
        (
            _obs(f"{prefix}-ldl-{index}", "13457-7", ldl_mg, "mg/dL", on)
            if first_visit
            else _obs(
                f"{prefix}-ldl-{index}",
                "13457-7",
                (ldl_mg / Decimal("38.67")).quantize(Decimal("0.01")),
                "mmol/L",
                on,
            )
        ),
        _obs(f"{prefix}-tc-{index}", "2093-3", _dec(rng, 4.2, 6.4, 2), "mmol/L", on),
        _obs(f"{prefix}-hdl-{index}", "2085-9", _dec(rng, 0.9, 1.7, 2), "mmol/L", on),
        _obs(f"{prefix}-tg-{index}", "2571-8", Decimal(rng.randint(90, 240)), "mg/dL", on),
        _obs(f"{prefix}-bmi-{index}", "39156-5", _dec(rng, 24.0, 33.0), "kg/m2", on),
        _obs(f"{prefix}-waist-{index}", "8280-0", _dec(rng, 34.0, 42.0), "in", on),
    ]


def _mmol_mol(pct: Decimal) -> Decimal:
    return ((pct - Decimal("2.152")) / Decimal("0.09148")).quantize(Decimal("1"))


def _noise(prefix: str, on: date) -> list[Observation]:
    return [
        _obs(f"{prefix}-creatinine", "2160-0", Decimal("0.9"), "mg/dL", on),
        {"resourceType": "Condition", "id": f"{prefix}-condition", "code": "E11.9"},
    ]


def generate_observations(
    seed: int,
    user_ref: str,
    enrolled_on: date,
    unavailable: bool = False,
    profile: SyntheticProfile = "default",
) -> tuple[Observation, ...]:
    """Deterministic synthetic record for one participant (same inputs ⇒ same output)."""
    if unavailable:
        raise MalaffiUnavailableError("synthetic Malaffi source is unavailable")
    rng = random.Random(f"bm-1:{seed}:{user_ref}")
    prefix = f"syn-{user_ref[-8:]}"
    observations: list[Observation] = []
    for index, (_, offset) in enumerate(_WINDOW_OFFSETS):
        on = enrolled_on + timedelta(days=offset)
        observations.extend(_window_observations(rng, prefix, index, on, profile))
    extra_on = enrolled_on + timedelta(days=_EXTRA_BASELINE_OFFSET)
    observations.append(_obs(f"{prefix}-hba1c-early", "4548-4", Decimal("6.9"), "%", extra_on))
    observations.extend(_noise(prefix, enrolled_on))
    return tuple(observations)


# --- Dashboard cohort (research R7) -----------------------------------------------------------
@dataclass(frozen=True, slots=True)
class _CohortSpec:
    code: BiomarkerCode
    baseline_mean: float
    baseline_sd: float
    effect_per_engagement: float
    noise_sd: float
    missing_share: float


_COHORT_SPECS: Final = (
    _CohortSpec(BiomarkerCode.HBA1C, 6.5, 0.8, -0.9, 0.3, 0.10),
    _CohortSpec(BiomarkerCode.SYSTOLIC_BP, 132, 12, -10, 5, 0.10),
    _CohortSpec(BiomarkerCode.DIASTOLIC_BP, 84, 8, -6, 3, 0.10),
    _CohortSpec(BiomarkerCode.TOTAL_CHOLESTEROL, 5.2, 0.8, -0.4, 0.3, 0.30),
    _CohortSpec(BiomarkerCode.LDL_CHOLESTEROL, 3.3, 0.7, -0.5, 0.25, 0.30),
    _CohortSpec(BiomarkerCode.HDL_CHOLESTEROL, 1.2, 0.25, 0.08, 0.1, 0.30),
    _CohortSpec(BiomarkerCode.TRIGLYCERIDES, 1.8, 0.6, -0.3, 0.3, 0.30),
    _CohortSpec(BiomarkerCode.BMI, 29, 4, -2.2, 0.6, 0.10),
    _CohortSpec(BiomarkerCode.WAIST, 98, 10, -7, 2.5, 0.60),
)
_COHORT_ENROLLED_ON: Final = date(2026, 1, 1)
_TIME_POINT_SCALE: Final = ((WindowType.MONTH_6, 182, 1.0), (WindowType.MONTH_12, 365, 1.3))
_TWO_PLACES: Final = Decimal("0.01")
SUBGROUP_FIELDS: Final = (
    "language",
    "nationality_group",
    "sex",
    "age_band",
    "work_pattern",
    "disability",
)


@dataclass(frozen=True, slots=True)
class SyntheticCohortBiomarkers:
    changes_by_user: Mapping[str, tuple[BiomarkerChange, ...]]
    subgroup_attrs: Mapping[str, Mapping[str, str]]


def _synthetic_result(
    spec: _CohortSpec, window: WindowType, value: float, day: int, ref: str
) -> BiomarkerResult:
    amount = Decimal(str(value)).quantize(_TWO_PLACES)
    return BiomarkerResult(
        window_type=window,
        biomarker=spec.code,
        value=amount,
        unit=BIOMARKER_CATALOG[spec.code].standard_unit,
        original_value=amount,
        original_unit=BIOMARKER_CATALOG[spec.code].standard_unit,
        result_date=_COHORT_ENROLLED_ON + timedelta(days=day),
        source_resource_id=f"{ref}-{spec.code.value}-{window.value}",
        safety_flag=False,
    )


def _user_results(rng: random.Random, engagement: float, ref: str) -> list[BiomarkerResult]:
    results: list[BiomarkerResult] = []
    for spec in _COHORT_SPECS:
        if rng.random() < spec.missing_share:
            continue
        baseline = rng.gauss(spec.baseline_mean, spec.baseline_sd)
        results.append(_synthetic_result(spec, WindowType.BASELINE, baseline, 0, ref))
        for window, day, scale in _TIME_POINT_SCALE:
            delta = spec.effect_per_engagement * engagement * scale + rng.gauss(0, spec.noise_sd)
            results.append(_synthetic_result(spec, window, baseline + delta, day, ref))
    return results


def generate_cohort_biomarkers(seed: int, n_users: int = 500) -> SyntheticCohortBiomarkers:
    """Seeded biomarker change for the F09 synthetic cohort, labelled illustrative (R7)."""
    from engine.biomarkers.change import compute_changes
    from engine.simulator import generate_synthetic_cohort

    changes: dict[str, tuple[BiomarkerChange, ...]] = {}
    attrs: dict[str, Mapping[str, str]] = {}
    for persona in generate_synthetic_cohort(n_users=n_users, seed=seed):
        rng = random.Random(f"bm-cohort:{seed}:{persona.user_id}")
        engagement = max(0.0, min(1.0, persona.base_adherence_prob))
        results = _user_results(rng, engagement, persona.user_id)
        changes[persona.user_id] = tuple(
            change
            for window, _, _ in _TIME_POINT_SCALE
            for change in compute_changes(results, window)
        )
        attrs[persona.user_id] = {name: str(getattr(persona, name)) for name in SUBGROUP_FIELDS}
    return SyntheticCohortBiomarkers(changes, attrs)
