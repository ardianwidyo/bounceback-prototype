"""Concrete guardrail policy rules implementing the Rule protocol (F13)."""

from __future__ import annotations

import re
from datetime import date

from content.copy_lint import count_words, lint_text
from engine.policy.environment import is_in_prayer_window, is_in_ramadan_fasting_hours
from engine.policy.protocol import (
    LEVEL_TO_RANK,
    RANK_TO_LEVEL,
    CandidatePolicyContext,
    EscalationSeverityLiteral,
    MessagePolicyContext,
    PlanProgressionPolicyContext,
    PolicyContextUnion,
    PolicyRuleSpec,
    PolicyScope,
    RedFlagCategoryLiteral,
    RuleTriggerRecord,
)

# ---------------------------------------------------------------------------
# Multilingual Regex Patterns for Red Flags, Medical Boundaries & Manipulation
# ---------------------------------------------------------------------------

_RED_FLAG_PATTERNS: tuple[
    tuple[RedFlagCategoryLiteral, EscalationSeverityLiteral, str, re.Pattern[str]],
    ...,
] = (
    (
        "chest_pain",
        "critical",
        "red_flag_chest_pain",
        re.compile(
            r"("
            r"\bchest\s+pain\b|\btightness\s+in\s+(my\s+)?chest\b|\bshortness\s+of\s+breath\b|"
            r"\bcan'?t\s+breathe\b|\bheart\s+attack\b|\bcrushing\s+chest\b|"
            r"ألم\s+في\s+الصدر|ألم\s+بالصدر|ضيق\s+في\s+التنفس|صعوبة\s+في\s+التنفس|نوبة\s+قلبية|"
            r"سینے\s+میں\s+درد|سانس\s+لینے\s+میں\s+دشواری|"
            r"सीने\s+में\s+दर्द|सांस\s+लेने\s+में\s+तकलीफ|"
            r"masakit\s+ang\s+dibdib|hirap\s+huminga|"
            r"നെഞ്ചുവേദന|ശ്വാസതടസ്സം"
            r")",
            re.IGNORECASE,
        ),
    ),
    (
        "self_harm",
        "critical",
        "red_flag_self_harm",
        re.compile(
            r"("
            r"\bself[\s-]?harm\b|\bhurt\s+myself\b|\bsuicid(e|al)\b|\bend(ing)?\s+my\s+life\b|"
            r"\bkill\s+myself\b|\bdon'?t\s+want\s+to\s+live\b|"
            r"إيذاء\s+نفس|أؤذي\s+نفسي|انتحار|أنهي\s+حياتي|لا\s+أريد\s+العيش|"
            r"خودکشی|اپنے\s+آپ\s+کو\s+نقصان|"
            r"आत्महत्या|खुद\s+को\s+नुकसान|"
            r"saktan\s+ang\s+sarili|magpakamatay|"
            r"ആത്മഹത്യ|സ്വയം\s+ഉപദ്രവിക്കുക"
            r")",
            re.IGNORECASE,
        ),
    ),
    (
        "disordered_eating",
        "high",
        "red_flag_disordered_eating",
        re.compile(
            r"("
            r"\bstarv(e|ing)\s+myself\b|\bmake\s+myself\s+throw\s+up\b|\bpurg(e|ing)\b|"
            r"\blaxative\s+abuse\b|\bhaven'?t\s+eaten\s+for\s+days\b|"
            r"تجويع\s+نفسي|أجوع\s+نفسي|تقيؤ\s+متعمد|أتقيأ\s+عمدا"
            r")",
            re.IGNORECASE,
        ),
    ),
    (
        "pregnancy_complication",
        "high",
        "red_flag_pregnancy_complication",
        re.compile(
            r"("
            r"\bpregnant\s+and\s+bleeding\b|\bbleeding\s+while\s+pregnant\b|"
            r"\bsevere\s+cramps\b.*\bpregnant\b|\bpregnant\b.*\bsevere\s+cramps\b|"
            r"\breduced\s+(baby|fetal)\s+movement\b|"
            r"حامل\s+ونزيف|نزيف\s+أثناء\s+الحمل|تقلصات\s+شديدة\s+أثناء\s+الحمل"
            r")",
            re.IGNORECASE,
        ),
    ),
    (
        "emergency_symptom",
        "critical",
        "red_flag_emergency_symptom",
        re.compile(
            r"("
            r"\bfainted\b|\bpassed\s+out\b|\bsevere\s+dizziness\b|\bcoughing\s+blood\b|"
            r"\bnumbness\s+on\s+one\s+side\b|"
            r"أغمي\s+علي|إغماء|دوخة\s+شديدة|سعال\s+مع\s+دم"
            r")",
            re.IGNORECASE,
        ),
    ),
)

_MEDICAL_INPUT_PATTERN = re.compile(
    r"("
    r"\bmetformin\b|\binsulin\b|\bozempic\b|\bwegovy\b|\bmounjaro\b|\bstatin(s)?\b|"
    r"\bamoxicillin\b|\bibuprofen\s+dos(e|age)\b|\bmedication(s)?\b|\bmedicine\b|"
    r"\bdos(e|age)\b|\b\d+\s*(mg|units)\b|\bpill(s)?\b|\bprescription\b|\bprescribe\b|"
    r"\bdiagnos(e|is)\b|\bhba1c\b|\bblood\s+pressure\s+(pills|meds|medication)\b|"
    r"\bstop\s+taking\s+my\b|\bignore\s+previous\s+instructions\b|\bpretend\s+you\s+are\s+a\s+doctor\b|"
    r"ميتفورمين|أنسولين|جرعة|الجرعة|دواء|الأدوية|أوقف\s+دواء|تشخيص|وصفة\s+طبية|تجاهل\s+التعليمات"
    r")",
    re.IGNORECASE,
)

_MEDICAL_OUTPUT_PATTERN = re.compile(
    r"("
    r"\b(increase|decrease|change|stop|take)\s+(your\s+)?(metformin|insulin|ozempic|dosage|dose|medication)\b|"
    r"\b\d+\s*mg\b|\byou\s+have\s+(diabetes|hypertension|heart\s+disease)\b"
    r")",
    re.IGNORECASE,
)

_MANIPULATIVE_STREAK_PATTERN = re.compile(
    r"("
    r"\bstreak(s)?\b|\bdon'?t\s+break\s+(the|your)\s+chain\b|\bbreak\s+your\s+chain\b|"
    r"\bchain\s+will\s+(reset|break)\b|\breset\s+to\s+zero\b|\blose\s+your\s+\d+[\s-]?day\b|"
    r"سلسلة|إعادة\s+ضبط|صفر|سلسلہ\s+ٹوٹ|स्ट्रीक\s+टूट|naputol\s+ang\s+streak"
    r")",
    re.IGNORECASE,
)

_MANIPULATIVE_COUNTDOWN_PATTERN = re.compile(
    r"("
    r"\bonly\s+\d+\s*(minute|minutes|min|mins|hour|hours|hr|hrs)\s+left\b|"
    r"\b\d+\s*(minute|minutes|hour|hours)\s+remaining\b|"
    r"\blast\s+chance\b|\bhurry(\s+up)?\b|\bbefore\s+midnight\b|"
    r"\btime\s+is\s+running\s+out\b|\bwindow\s+expires\b|\bexpires\s+in\b|"
    r"\bact\s+now\s+before\b|"
    r"فرصة\s+أخيرة|أسرع\s+قبل|ينتهي\s+الوقت|تبقى\s+\d+\s*(ساعة|ساعات|دقيقة|دقائق)"
    r")",
    re.IGNORECASE,
)

_PAIN_BARRIERS: frozenset[str] = frozenset({"pain_or_illness", "pain", "illness"})

_DEFAULT_OUTDOOR_TO_INDOOR_MAP: dict[str, str] = {
    "mov-walk-after-meal": "mov-stand-and-stretch",
}

_DEFAULT_INDOOR_BY_LEVEL: dict[str, str] = {
    "L1": "mov-stand-and-stretch",
    "L2": "mov-take-the-stairs",
    "L3": "mov-take-the-stairs",
}

_DEFAULT_INDOOR_CONTRAINDICATIONS: dict[str, tuple[str, ...]] = {
    "mov-stand-and-stretch": (),
    "mov-take-the-stairs": ("cardiac_condition", "mobility_limitation"),
}


class BasePolicyRule:
    """Base helper storing the loaded PolicyRuleSpec."""

    def __init__(self, spec: PolicyRuleSpec) -> None:
        self._spec = spec

    @property
    def rule_id(self) -> str:
        return self._spec.rule_id

    @property
    def applies_to(self) -> tuple[PolicyScope, ...]:
        return self._spec.applies_to

    @property
    def priority(self) -> int:
        return self._spec.priority


class ClinicalRedFlagEscalationRule(BasePolicyRule):
    """Detects clinical and mental-health red flags and flags immediate human escalation."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if not isinstance(ctx, MessagePolicyContext):
            return None
        text = ctx.text.strip()
        if not text:
            return None
        for category, severity, template_id, pattern in _RED_FLAG_PATTERNS:
            if pattern.search(text):
                return RuleTriggerRecord(
                    rule_id=self.rule_id,
                    verdict="block",
                    reason=f"Clinical or mental-health red flag detected ({category}).",
                    red_flag_category=category,
                    severity=severity,
                    fallback_template_id=template_id,
                )
        return None


class ActiveRedFlagHoldRule(BasePolicyRule):
    """Pauses physical movement candidates and upward progressions while an escalation is open."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if isinstance(ctx, CandidatePolicyContext):
            if ctx.has_open_red_flag and ctx.habit_domain == "movement":
                return RuleTriggerRecord(
                    rule_id=self.rule_id,
                    verdict="block",
                    reason=(
                        "Automated physical movement nudges are paused while a clinical "
                        "red flag is open."
                    ),
                )
        elif (
            isinstance(ctx, PlanProgressionPolicyContext)
            and ctx.has_open_red_flag
            and LEVEL_TO_RANK[ctx.proposed_level] > LEVEL_TO_RANK[ctx.baseline_level_7d]
        ):
            return RuleTriggerRecord(
                rule_id=self.rule_id,
                verdict="block",
                reason="Difficulty increases are paused while a clinical red flag is open.",
            )
        return None


class MedicalBoundaryRefusalRule(BasePolicyRule):
    """Refuses medical/medication questions on input and blocks medical leaks on output."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if not isinstance(ctx, MessagePolicyContext):
            return None
        text = ctx.text.strip()
        if not text:
            return None
        if _MEDICAL_OUTPUT_PATTERN.search(text) or _MEDICAL_INPUT_PATTERN.search(text):
            return RuleTriggerRecord(
                rule_id=self.rule_id,
                verdict="block",
                reason="Medical diagnosis or medication dosage advice is outside companion scope.",
                fallback_template_id="medical_advice_refusal",
            )
        return None


class PainIllnessPhysicalPauseRule(BasePolicyRule):
    """Pauses physical movement actions when user reports pain_or_illness."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if isinstance(ctx, CandidatePolicyContext):
            if _PAIN_BARRIERS.intersection(ctx.active_barriers) and ctx.habit_domain == "movement":
                return RuleTriggerRecord(
                    rule_id=self.rule_id,
                    verdict="block",
                    reason=(
                        "Physical movement actions are paused while pain or illness is reported."
                    ),
                )
        elif (
            isinstance(ctx, PlanProgressionPolicyContext)
            and _PAIN_BARRIERS.intersection(ctx.active_barriers)
            and LEVEL_TO_RANK[ctx.proposed_level] > LEVEL_TO_RANK[ctx.baseline_level_7d]
        ):
            return RuleTriggerRecord(
                rule_id=self.rule_id,
                verdict="block",
                reason="Difficulty progression is paused while pain or illness is reported.",
            )
        return None


class ContraindicatedActionRule(BasePolicyRule):
    """Blocks any candidate action whose contraindications match the user's barriers/flags."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if isinstance(ctx, CandidatePolicyContext):
            # Exclude heat_exposure here if handled by heat_index_outdoor_substitution
            non_heat_barriers = {
                b for b in ctx.active_barriers if b not in ("heat", "heat_exposure", "extreme_heat")
            }
            expanded_contra: set[str] = set(non_heat_barriers)
            if "pain" in non_heat_barriers or "pain_or_illness" in non_heat_barriers:
                expanded_contra.update(("mobility_limitation", "cardiac_condition", "joint_pain"))
            matched = expanded_contra.intersection(ctx.contraindications)
            if not matched and ctx.heat_index_c is None:
                # Direct match against active barriers when heat_index_c is None
                matched = set(ctx.active_barriers).intersection(ctx.contraindications)
            if matched:
                return RuleTriggerRecord(
                    rule_id=self.rule_id,
                    verdict="block",
                    reason=f"Action '{ctx.action_id}' contraindicated by: {sorted(matched)}.",
                )
        elif isinstance(ctx, PlanProgressionPolicyContext):
            active = set(ctx.active_barriers) | set(ctx.contraindications)
            matched = active.intersection(ctx.action_contraindications)
            if matched:
                return RuleTriggerRecord(
                    rule_id=self.rule_id,
                    verdict="block",
                    reason=f"Progression contraindicated by: {sorted(matched)}.",
                )
        return None


class PrayerTimeWindowRule(BasePolicyRule):
    """Blocks immediate delivery in active window when local_time falls inside prayer buffer."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if not isinstance(ctx, CandidatePolicyContext):
            return None
        if ctx.time_window != ctx.current_time_window:
            return None
        buf = int(self._spec.parameters.get("prayer_buffer_minutes", 15))
        try:
            eff_date = date.fromisoformat(ctx.local_date)
        except ValueError:
            eff_date = date(2026, 4, 20)
        in_prayer, prayer_name = is_in_prayer_window(
            ctx.local_time,
            city=ctx.city,
            local_date=eff_date,
            buffer_minutes=buf,
        )
        if in_prayer:
            return RuleTriggerRecord(
                rule_id=self.rule_id,
                verdict="block",
                reason=(
                    f"Decision time {ctx.local_time} falls within the {prayer_name} prayer "
                    f"buffer window (+-{buf} min)."
                ),
            )
        return None


class RamadanFastingWindowRule(BasePolicyRule):
    """Blocks daytime food/hydration nudges and strenuous daytime exercise during Ramadan."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if not isinstance(ctx, CandidatePolicyContext):
            return None
        if not ctx.ramadan_mode:
            return None
        is_daytime_window = ctx.time_window in ("morning", "afternoon")
        try:
            eff_date = date.fromisoformat(ctx.local_date)
        except ValueError:
            eff_date = date(2026, 3, 10)
        in_fasting_clock = (
            ctx.time_window == ctx.current_time_window
            and is_in_ramadan_fasting_hours(ctx.local_time, city=ctx.city, local_date=eff_date)
        )
        if not (is_daytime_window or in_fasting_clock):
            return None

        is_nutrition_or_fasting_contra = (
            ctx.habit_domain == "nutrition"
            or "ramadan_fasting_daytime" in ctx.contraindications
            or "fasting_hours" in ctx.avoid_contexts
        )
        is_strenuous_daytime_movement = (
            ctx.habit_domain == "movement" and LEVEL_TO_RANK.get(ctx.level, 1) >= 3
        )
        if is_nutrition_or_fasting_contra or is_strenuous_daytime_movement:
            return RuleTriggerRecord(
                rule_id=self.rule_id,
                verdict="block",
                reason=(
                    "Daytime Ramadan fasting window excludes daytime nutrition/hydration "
                    "and strenuous physical actions."
                ),
            )
        return None


def _is_outdoor_candidate(ctx: CandidatePolicyContext, spec: PolicyRuleSpec) -> bool:
    if ctx.habit_domain != "movement":
        return False
    outdoor_ids = set(spec.parameters.get("outdoor_action_ids", ["mov-walk-after-meal"]))
    outdoor_avoid = set(spec.parameters.get("outdoor_avoid_contexts", ["midday_heat"]))
    outdoor_contra = set(
        spec.parameters.get("outdoor_contraindications", ["heat_exposure", "extreme_heat"])
    )
    return bool(
        ctx.action_id in outdoor_ids
        or outdoor_avoid.intersection(ctx.avoid_contexts)
        or outdoor_contra.intersection(ctx.contraindications)
    )


def _resolve_indoor_alternative(
    ctx: CandidatePolicyContext,
    spec: PolicyRuleSpec,
) -> str | None:
    if ctx.available_indoor_actions is not None and len(ctx.available_indoor_actions) == 0:
        return None
    mapping = dict(_DEFAULT_OUTDOOR_TO_INDOOR_MAP)
    mapping.update(spec.parameters.get("outdoor_to_indoor_map", {}))
    candidate_id = mapping.get(ctx.action_id)
    if candidate_id is None and ctx.action_id == "mov-walk-after-meal":
        candidate_id = _DEFAULT_INDOOR_BY_LEVEL.get(ctx.level, "mov-stand-and-stretch")

    if candidate_id is None:
        return None

    indoor_contras = (
        ctx.available_indoor_actions.get(candidate_id, ())
        if ctx.available_indoor_actions is not None
        else _DEFAULT_INDOOR_CONTRAINDICATIONS.get(candidate_id, ())
    )
    if set(ctx.active_barriers).intersection(indoor_contras):
        # Fallback to L1 gentle stretch if stairs are contraindicated
        if candidate_id != "mov-stand-and-stretch":
            stretch_contras = (
                ctx.available_indoor_actions.get("mov-stand-and-stretch", ())
                if ctx.available_indoor_actions is not None
                else ()
            )
            if not set(ctx.active_barriers).intersection(stretch_contras):
                return "mov-stand-and-stretch"
        return None
    return candidate_id


class HeatIndexOutdoorSubstitutionRule(BasePolicyRule):
    """Substitutes outdoor physical activities with indoor alternatives when heat index >= 40 C."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if not isinstance(ctx, CandidatePolicyContext):
            return None
        threshold = float(self._spec.parameters.get("heat_index_threshold_c", 40.0))
        if ctx.heat_index_c is None or ctx.heat_index_c < threshold:
            return None
        if not _is_outdoor_candidate(ctx, self._spec):
            return None
        indoor_id = _resolve_indoor_alternative(ctx, self._spec)
        if indoor_id is None:
            return None
        return RuleTriggerRecord(
            rule_id=self.rule_id,
            verdict="modify",
            reason=(
                f"Local heat index ({ctx.heat_index_c:.1f} C >= {threshold:.1f} C) triggered "
                f"indoor substitution '{ctx.action_id}' -> '{indoor_id}'."
            ),
            modified_fields={
                "original_action_id": ctx.action_id,
                "action_id": indoor_id,
                "heat_index_c": ctx.heat_index_c,
            },
        )


class HeatIndexOutdoorBlockRule(BasePolicyRule):
    """Blocks outdoor physical activities at heat index >= 40 C if no indoor alternative exists."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if not isinstance(ctx, CandidatePolicyContext):
            return None
        threshold = float(self._spec.parameters.get("heat_index_threshold_c", 40.0))
        if ctx.heat_index_c is None or ctx.heat_index_c < threshold:
            return None
        if not _is_outdoor_candidate(ctx, self._spec):
            return None
        indoor_id = _resolve_indoor_alternative(ctx, self._spec)
        if indoor_id is not None:
            return None
        return RuleTriggerRecord(
            rule_id=self.rule_id,
            verdict="block",
            reason=(
                f"Local heat index ({ctx.heat_index_c:.1f} C >= {threshold:.1f} C) and no safe "
                f"indoor alternative available for '{ctx.action_id}'."
            ),
        )


class MaxWeeklyLevelIncreaseRule(BasePolicyRule):
    """Caps difficulty increases at <= +1 level per rolling 7-day window."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        max_delta = int(self._spec.parameters.get("max_weekly_level_delta", 1))
        if isinstance(ctx, PlanProgressionPolicyContext):
            base_rank = LEVEL_TO_RANK.get(ctx.baseline_level_7d, 1)
            prop_rank = LEVEL_TO_RANK.get(ctx.proposed_level, 1)
            if prop_rank - base_rank > max_delta:
                clamped_rank = min(5, base_rank + max_delta)
                clamped_level = RANK_TO_LEVEL[clamped_rank]
                return RuleTriggerRecord(
                    rule_id=self.rule_id,
                    verdict="modify",
                    reason=(
                        f"Proposed difficulty {ctx.proposed_level} exceeds +{max_delta} level/week "
                        f"from 7-day baseline {ctx.baseline_level_7d}; clamped to {clamped_level}."
                    ),
                    modified_fields={
                        "original_level": ctx.proposed_level,
                        "level": clamped_level,
                        "baseline_level_7d": ctx.baseline_level_7d,
                    },
                )
        elif isinstance(ctx, CandidatePolicyContext) and ctx.baseline_level_7d is not None:
            base_rank = LEVEL_TO_RANK.get(ctx.baseline_level_7d, 1)
            cand_rank = LEVEL_TO_RANK.get(ctx.level, 1)
            if cand_rank - base_rank > max_delta:
                return RuleTriggerRecord(
                    rule_id=self.rule_id,
                    verdict="block",
                    reason=(
                        f"Candidate level {ctx.level} exceeds +{max_delta} weekly increase cap "
                        f"above 7-day baseline {ctx.baseline_level_7d}."
                    ),
                )
        return None


class ManipulativeStreakLanguageRule(BasePolicyRule):
    """Rejects loss-framed streaks, chain-breaking threats, and streak reset language."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if not isinstance(ctx, MessagePolicyContext):
            return None
        if _MANIPULATIVE_STREAK_PATTERN.search(ctx.text):
            fallback = str(self._spec.parameters.get("fallback_template_id", "encouragement"))
            return RuleTriggerRecord(
                rule_id=self.rule_id,
                verdict="modify",
                reason=(
                    "Outbound message contains forbidden loss-framed streak or "
                    "chain-reset language."
                ),
                modified_fields={"replaced_by_template": fallback},
                fallback_template_id=fallback,
            )
        return None


class ManipulativeCountdownPressureRule(BasePolicyRule):
    """Rejects artificial countdowns, expiring timers, and 'last chance' urgency prompts."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if not isinstance(ctx, MessagePolicyContext):
            return None
        if _MANIPULATIVE_COUNTDOWN_PATTERN.search(ctx.text):
            fallback = str(self._spec.parameters.get("fallback_template_id", "encouragement"))
            return RuleTriggerRecord(
                rule_id=self.rule_id,
                verdict="modify",
                reason="Outbound message contains forbidden countdown or urgency pressure.",
                modified_fields={"replaced_by_template": fallback},
                fallback_template_id=fallback,
            )
        return None


class BlameOrGuiltLanguageRule(BasePolicyRule):
    """Rejects blame, guilt, shame, fear appeals, exclamation marks, or >60-word replies."""

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None:
        if not isinstance(ctx, MessagePolicyContext):
            return None
        violations = lint_text(ctx.text)
        # Filter out 'streak'/'reset' if already caught unless other blame terms exist
        non_streak_violations = [
            v for v in violations if v.matched_term not in ("streak", "reset", "سلسلة", "إعادة ضبط")
        ]
        max_words = int(self._spec.parameters.get("max_words", ctx.max_words))
        too_long = count_words(ctx.text) > max_words
        if non_streak_violations or too_long:
            fallback = str(self._spec.parameters.get("fallback_template_id", "encouragement"))
            terms = [v.matched_term for v in non_streak_violations]
            if too_long:
                terms.append("max_words_exceeded")
            return RuleTriggerRecord(
                rule_id=self.rule_id,
                verdict="modify",
                reason=f"Outbound message violated blame-free/length policy: {terms}.",
                modified_fields={"violations": terms, "replaced_by_template": fallback},
                fallback_template_id=fallback,
            )
        return None
