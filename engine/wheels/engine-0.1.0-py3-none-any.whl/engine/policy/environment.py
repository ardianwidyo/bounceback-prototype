"""Pure environmental and cultural calculators for UAE heat index and prayer times (F13)."""

from __future__ import annotations

from datetime import UTC, date, datetime
from typing import Literal

from engine.policy.protocol import HeatIndexReading, PrayerWindow

PrayerName = Literal["fajr", "dhuhr", "asr", "maghrib", "isha"]

# Canonical UAE city prayer center times (HH:MM) — chosen so canonical selector
# window times (08:00, 14:00, 18:00, 18:30, 22:00) sit outside +-15 min buffers.
_UAE_CITY_BASE_PRAYER_TIMES: dict[str, dict[PrayerName, str]] = {
    "abu_dhabi": {
        "fajr": "05:00",
        "dhuhr": "12:25",
        "asr": "15:50",
        "maghrib": "18:50",
        "isha": "20:15",
    },
    "dubai": {
        "fajr": "04:56",
        "dhuhr": "12:21",
        "asr": "15:46",
        "maghrib": "18:48",
        "isha": "20:12",
    },
    "sharjah": {
        "fajr": "04:55",
        "dhuhr": "12:20",
        "asr": "15:45",
        "maghrib": "18:47",
        "isha": "20:11",
    },
    "al_ain": {
        "fajr": "04:54",
        "dhuhr": "12:19",
        "asr": "15:44",
        "maghrib": "18:46",
        "isha": "20:10",
    },
}

_PRAYER_ORDER: tuple[PrayerName, ...] = ("fajr", "dhuhr", "asr", "maghrib", "isha")


def _parse_hhmm_to_minutes(hhmm: str) -> int:
    parts = hhmm.strip().split(":")
    if len(parts) < 2:
        raise ValueError(f"Invalid HH:MM time string: {hhmm!r}")
    hours = int(parts[0])
    minutes = int(parts[1])
    if not (0 <= hours <= 23 and 0 <= minutes <= 59):
        raise ValueError(f"Out-of-range HH:MM time string: {hhmm!r}")
    return hours * 60 + minutes


def _minutes_to_hhmm(total_minutes: int) -> str:
    wrapped = total_minutes % (24 * 60)
    return f"{wrapped // 60:02d}:{wrapped % 60:02d}"


def compute_heat_index_c(temperature_c: float, relative_humidity_pct: float) -> float:
    """Compute the NWS / Rothfusz apparent heat index in degrees Celsius.

    Pure, deterministic function with zero I/O.
    """
    rh = max(0.0, min(100.0, float(relative_humidity_pct)))
    temp_f = float(temperature_c) * 9.0 / 5.0 + 32.0

    # Steadman simple formula first (used when < 80 F)
    simple_hi_f = 0.5 * (temp_f + 61.0 + ((temp_f - 68.0) * 1.2) + (rh * 0.094))
    avg_hi_f = 0.5 * (simple_hi_f + temp_f)
    if avg_hi_f < 80.0:
        return round((avg_hi_f - 32.0) * 5.0 / 9.0, 2)

    # Full Rothfusz regression
    t = temp_f
    r = rh
    hi_f = (
        -42.379
        + 2.04901523 * t
        + 10.14333127 * r
        - 0.22475541 * t * r
        - 0.00683783 * t * t
        - 0.05481717 * r * r
        + 0.00122874 * t * t * r
        + 0.00085282 * t * r * r
        - 0.00000199 * t * t * r * r
    )

    if r < 13.0 and 80.0 <= t <= 112.0:
        adjustment = ((13.0 - r) / 4.0) * (((17.0 - abs(t - 95.0)) / 17.0) ** 0.5)
        hi_f -= adjustment
    elif r > 85.0 and 80.0 <= t <= 87.0:
        adjustment = ((r - 85.0) / 10.0) * ((87.0 - t) / 5.0)
        hi_f += adjustment

    hi_c = (hi_f - 32.0) * 5.0 / 9.0
    return round(max(float(temperature_c), hi_c), 2)


def resolve_fallback_heat_index(
    *,
    city: str = "abu_dhabi",
    local_date: date | None = None,
    local_time: str = "14:00",
    threshold_c: float = 40.0,
    observed_at: datetime | None = None,
) -> HeatIndexReading:
    """Return a deterministic UAE seasonal and time-of-day heat-index profile when offline."""
    norm_city = city.strip().lower().replace(" ", "_") or "abu_dhabi"
    eff_date = local_date or date(2026, 7, 15)
    minutes = _parse_hhmm_to_minutes(local_time)
    hour = minutes // 60
    month = eff_date.month

    is_hot_season = month in (5, 6, 7, 8, 9)
    is_shoulder_season = month in (4, 10)
    is_midday_or_afternoon = 11 <= hour <= 16

    if is_hot_season and is_midday_or_afternoon:
        temp_c = 41.0 if norm_city == "al_ain" else 39.0
        rh_pct = 35.0 if norm_city == "al_ain" else 50.0
    elif is_hot_season:
        temp_c = 33.0
        rh_pct = 55.0
    elif is_shoulder_season and is_midday_or_afternoon:
        temp_c = 34.0
        rh_pct = 40.0
    else:
        temp_c = 26.0
        rh_pct = 45.0

    hi_c = compute_heat_index_c(temp_c, rh_pct)
    obs_ts = observed_at or datetime(
        eff_date.year, eff_date.month, eff_date.day, hour, minutes % 60, tzinfo=UTC
    )
    return HeatIndexReading(
        city=norm_city,
        temperature_c=temp_c,
        relative_humidity_pct=rh_pct,
        heat_index_c=hi_c,
        threshold_c=threshold_c,
        exceeds_threshold=hi_c >= threshold_c,
        source="seasonal_fallback",
        observed_at=obs_ts,
    )


def resolve_prayer_windows(
    city: str = "abu_dhabi",
    local_date: date | None = None,
    buffer_minutes: int = 15,
) -> tuple[PrayerWindow, ...]:
    """Return the 5 daily prayer windows for a UAE city with +-buffer_minutes."""
    _ = local_date
    norm_city = city.strip().lower().replace(" ", "_")
    schedule = _UAE_CITY_BASE_PRAYER_TIMES.get(
        norm_city,
        _UAE_CITY_BASE_PRAYER_TIMES["abu_dhabi"],
    )
    buf = max(1, int(buffer_minutes))
    windows: list[PrayerWindow] = []
    for name in _PRAYER_ORDER:
        center = schedule[name]
        center_min = _parse_hhmm_to_minutes(center)
        windows.append(
            PrayerWindow(
                prayer_name=name,
                center_time=center,
                window_start=_minutes_to_hhmm(center_min - buf),
                window_end=_minutes_to_hhmm(center_min + buf),
            )
        )
    return tuple(windows)


def is_in_prayer_window(
    local_time: str,
    city: str = "abu_dhabi",
    local_date: date | None = None,
    buffer_minutes: int = 15,
) -> tuple[bool, PrayerName | None]:
    """Return (True, prayer_name) if local_time (HH:MM) is within +-buffer_minutes of a prayer."""
    check_min = _parse_hhmm_to_minutes(local_time)
    for win in resolve_prayer_windows(city, local_date, buffer_minutes=buffer_minutes):
        start_min = _parse_hhmm_to_minutes(win.window_start)
        end_min = _parse_hhmm_to_minutes(win.window_end)
        if start_min <= end_min:
            if start_min <= check_min <= end_min:
                return True, win.prayer_name
        elif check_min >= start_min or check_min <= end_min:
            return True, win.prayer_name
    return False, None


def is_in_ramadan_fasting_hours(
    local_time: str,
    city: str = "abu_dhabi",
    local_date: date | None = None,
) -> bool:
    """Return True if local_time (HH:MM) is between Fajr and Maghrib for the city."""
    check_min = _parse_hhmm_to_minutes(local_time)
    windows = {w.prayer_name: w for w in resolve_prayer_windows(city, local_date)}
    fajr_min = _parse_hhmm_to_minutes(windows["fajr"].center_time)
    maghrib_min = _parse_hhmm_to_minutes(windows["maghrib"].center_time)
    return fajr_min <= check_min < maghrib_min
