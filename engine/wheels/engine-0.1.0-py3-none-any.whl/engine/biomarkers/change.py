"""Deterministic change from baseline to 6 and 12 months (F21 FR-008, FR-014; research R5)."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal
from enum import StrEnum
from typing import Final

from engine.biomarkers.catalog import (
    BODY_MEASURES,
    MEANINGFUL_CHANGE,
    RELATIVE_THRESHOLD_CODES,
    BiomarkerCode,
)
from engine.biomarkers.validation import BiomarkerResult
from engine.biomarkers.windows import FOLLOW_UP_WINDOWS, WindowType

PERCENT_QUANTUM: Final = Decimal("0.01")
HUNDRED: Final = Decimal(100)


class PairingStatus(StrEnum):
    PAIRED = "paired"
    NO_RESULT = "no_result"
    NOT_RETRIEVED = "not_retrieved"
    EXCLUDED = "excluded"


@dataclass(frozen=True, slots=True)
class BiomarkerChange:
    biomarker: BiomarkerCode
    time_point: WindowType
    status: PairingStatus
    baseline_value: Decimal | None = None
    followup_value: Decimal | None = None
    absolute_change: Decimal | None = None
    relative_change_pct: Decimal | None = None
    elapsed_days: int | None = None
    meaningful_change_reached: bool | None = None


def _relative_pct(baseline: Decimal, change: Decimal) -> Decimal:
    return (change / baseline * HUNDRED).quantize(PERCENT_QUANTUM, rounding=ROUND_HALF_UP)


def _meaningful(code: BiomarkerCode, absolute: Decimal, relative: Decimal | None) -> bool | None:
    threshold = MEANINGFUL_CHANGE.get(code)
    if threshold is None:
        return None
    measured = relative if code in RELATIVE_THRESHOLD_CODES else absolute
    return measured is not None and measured <= threshold


def _paired(
    code: BiomarkerCode, time_point: WindowType, base: BiomarkerResult, follow: BiomarkerResult
) -> BiomarkerChange:
    absolute = follow.value - base.value
    relative = _relative_pct(base.value, absolute) if code in RELATIVE_THRESHOLD_CODES else None
    return BiomarkerChange(
        biomarker=code,
        time_point=time_point,
        status=PairingStatus.PAIRED,
        baseline_value=base.value,
        followup_value=follow.value,
        absolute_change=absolute,
        relative_change_pct=relative,
        elapsed_days=(follow.result_date - base.result_date).days,
        meaningful_change_reached=_meaningful(code, absolute, relative),
    )


def _unpaired_status(
    base: BiomarkerResult | None,
    follow: BiomarkerResult | None,
    time_point: WindowType,
    not_retrieved: frozenset[WindowType],
) -> PairingStatus:
    if (base is None and WindowType.BASELINE in not_retrieved) or (
        follow is None and time_point in not_retrieved
    ):
        return PairingStatus.NOT_RETRIEVED
    return PairingStatus.NO_RESULT


def compute_changes(
    results: Iterable[BiomarkerResult],
    time_point: WindowType,
    *,
    body_measures_excluded: bool = False,
    not_retrieved_windows: frozenset[WindowType] = frozenset(),
) -> tuple[BiomarkerChange, ...]:
    """One change record per catalogue biomarker for ``month_6`` or ``month_12``."""
    if time_point not in FOLLOW_UP_WINDOWS:
        raise ValueError("time_point must be month_6 or month_12")
    by_key = {(r.window_type, r.biomarker): r for r in results}
    changes: list[BiomarkerChange] = []
    for code in BiomarkerCode:
        if body_measures_excluded and code in BODY_MEASURES:
            changes.append(BiomarkerChange(code, time_point, PairingStatus.EXCLUDED))
            continue
        base = by_key.get((WindowType.BASELINE, code))
        follow = by_key.get((time_point, code))
        if base is not None and follow is not None:
            changes.append(_paired(code, time_point, base, follow))
            continue
        status = _unpaired_status(base, follow, time_point, not_retrieved_windows)
        changes.append(BiomarkerChange(code, time_point, status))
    return tuple(changes)
