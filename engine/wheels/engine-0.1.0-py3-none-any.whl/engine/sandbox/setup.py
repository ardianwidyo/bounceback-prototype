"""Setup commands: load_persona, quick_setup and set_quiet_hours (spec 023, T030)."""

from __future__ import annotations

from datetime import date
from typing import Any

from engine.sandbox.checkin import active_plan, recompute_progress
from engine.sandbox.commands import Event, Handler
from engine.sandbox.context import initial_context_day
from engine.sandbox.cues import avoid_quiet_hours, in_quiet_hours
from engine.sandbox.personas import PERSONAS, START_DATE
from engine.sandbox.planning import DEFAULT_COMB, PlanContext, build_plan_items, quiet_hours_of
from engine.sandbox.radar import score_today
from engine.sandbox.state import SandboxError, State, default_consent, new_state
from engine.sandbox.trail import append_entry, last_decision_id

DEFAULT_SEED = 1
QUIET_HOURS_REASON = "quiet_hours"


def _start(base: State) -> tuple[State, list[Event]]:
    """Build plan version 1 for a fresh state."""
    context = PlanContext(work_pattern=base["profile"]["work_pattern"])
    working, items, seeds = build_plan_items(base, version=1, context=context)
    plan = {
        "version": 1,
        "parent_version": None,
        "created_on": working["current_date"],
        "reason": "initial",
        "items": items,
        "active": True,
        "context": context.to_dict(),
        "seeds": seeds,
    }
    started: State = {**working, "plans": [plan]}
    started["progress"] = recompute_progress(started)
    started["context_days"] = [initial_context_day(started)]
    scored, radar_events = score_today(started)
    return scored, [{"type": "plan_activated", "version": 1}, *radar_events]


def _load_persona(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    persona = PERSONAS.get(command["persona_id"])
    if persona is None:
        raise SandboxError("invalid_command")
    start = date.fromisoformat(persona.start_date)
    base = new_state(
        profile=persona.to_profile(),
        consent=default_consent(start),
        seed=command.get("seed", persona.seed),
        start_date=start,
        locale=command["locale"],
    )
    return _start(base)


def _quick_setup(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    start = date.fromisoformat(START_DATE)
    profile = {
        "persona_id": None,
        "display_name": "You",
        "areas": command["areas"],
        "work_pattern": command["work_pattern"],
        "observes_ramadan": command["observes_ramadan"],
        "quiet_hours": dict(command["quiet_hours"]),
        "contraindications": [],
        "why": "",
        "barriers": [],
        "comb": list(DEFAULT_COMB),
    }
    base = new_state(
        profile=profile,
        consent=default_consent(start),
        seed=command.get("seed", DEFAULT_SEED),
        start_date=start,
        locale=command["locale"],
    )
    return _start(base)


def _set_quiet_hours(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    assert state is not None  # the command schema requires a state
    quiet = (command["start"], command["end"])
    plan = active_plan(state)
    moved_items: list[dict[str, Any]] = []
    changes: list[dict[str, Any]] = []
    for item in plan["items"]:
        if not in_quiet_hours(item["clock_time"], quiet):
            moved_items.append(item)
            continue
        new_time = avoid_quiet_hours(item["clock_time"], quiet)
        moved_items.append({**item, "clock_time": new_time})
        changes.append(
            {
                "kind": "moved",
                "area": item["area"],
                "before": {"action_id": item["action_id"], "clock_time": item["clock_time"]},
                "after": {"action_id": item["action_id"], "clock_time": new_time},
                "reason_code": QUIET_HOURS_REASON,
            }
        )

    updated = {**state, "profile": {**state["profile"], "quiet_hours": dict(command)}}
    updated["profile"]["quiet_hours"] = {"start": quiet[0], "end": quiet[1]}
    on = state["current_date"]
    if not changes:
        recorded = append_entry(
            updated,
            decision_type="choice_recorded",
            on=on,
            policy_version="quiet-hours-1",
            inputs_used={"quiet_hours": updated["profile"]["quiet_hours"], "items_affected": 0},
            excluded_sources=[],
            candidate_set=[],
            chosen="quiet_hours_changed",
            propensities=[1.0],
            summary_key="trail.quiet_hours_changed",
        )
        return recorded, []

    superseded = state["pending_proposal"]["id"] if state["pending_proposal"] else None
    recorded = append_entry(
        updated,
        decision_type="adjustment_proposed",
        on=on,
        policy_version="quiet-hours-1",
        inputs_used={
            "quiet_hours": updated["profile"]["quiet_hours"],
            "items_affected": len(changes),
            "superseded": superseded,
        },
        excluded_sources=[],
        candidate_set=[item["slot_id"] for item in plan["items"]],
        chosen=[change["after"]["clock_time"] for change in changes],
        propensities=[1.0],
        summary_key="trail.adjustment_proposed",
    )
    decision_id = last_decision_id(recorded)
    assert decision_id is not None
    proposal_id = f"p{decision_id[1:]}"
    proposal = {
        "id": proposal_id,
        "trigger": "quiet_hours",
        "created_on": on,
        "before_version": plan["version"],
        "after_items": moved_items,
        "changes": changes,
        "decision_id": decision_id,
        "status": "pending",
    }
    return {**recorded, "pending_proposal": proposal}, [
        {"type": "proposal_ready", "proposal_id": proposal_id}
    ]


HANDLERS: dict[str, Handler] = {
    "load_persona": _load_persona,
    "quick_setup": _quick_setup,
    "set_quiet_hours": _set_quiet_hours,
}

__all__ = ["HANDLERS", "quiet_hours_of"]
