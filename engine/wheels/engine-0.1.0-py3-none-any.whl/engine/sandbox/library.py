"""The action library the sandbox plans from.

In the browser the worker injects a pre-validated JSON payload with ``configure`` (so jsonschema is
never needed). Elsewhere (tests, CPython) the packaged YAML library is loaded and validated.
The library is immutable, so this module-level cache holds no mutable session state.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from content.library import Library, load_library, load_library_from_json

_configured: Library | None = None
_default: Library | None = None


def configure(payload: Mapping[str, Any] | None) -> None:
    """Use ``payload`` (from ``content.library.export_library_payload``), or reset with ``None``."""
    global _configured
    _configured = None if payload is None else load_library_from_json(payload)


def get_library() -> Library:
    """The configured library, else the packaged default (loaded once)."""
    global _default
    if _configured is not None:
        return _configured
    if _default is None:
        _default = load_library()
    return _default
