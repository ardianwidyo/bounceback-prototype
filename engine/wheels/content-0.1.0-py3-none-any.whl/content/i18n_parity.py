"""Six-locale key and interpolation placeholder parity checker (F12, FR-009)."""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from content.library import SUPPORTED_LOCALES

PLACEHOLDER_PATTERN = re.compile(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}|\{([a-zA-Z0-9_]+)\}")


@dataclass(frozen=True, slots=True)
class ParityViolation:
    locale: str
    kind: str  # "missing_key" | "extra_key" | "placeholder_mismatch" | "empty_value"
    key_path: str
    detail: str


def _flatten_catalog(node: Any, prefix: str = "") -> dict[str, str]:
    out: dict[str, str] = {}
    if isinstance(node, Mapping):
        for k, v in node.items():
            key_str = str(k)
            next_prefix = f"{prefix}.{key_str}" if prefix else key_str
            out.update(_flatten_catalog(v, next_prefix))
    elif isinstance(node, list | tuple):
        for idx, item in enumerate(node):
            next_prefix = f"{prefix}[{idx}]"
            out.update(_flatten_catalog(item, next_prefix))
    elif isinstance(node, str):
        out[prefix] = node
    return out


def extract_placeholders(text: str) -> frozenset[str]:
    """Return all `{token}` and `{{token}}` interpolation variables in `text`."""
    tokens: set[str] = set()
    for match in PLACEHOLDER_PATTERN.finditer(text):
        tok = match.group(1) or match.group(2)
        if tok:
            tokens.add(tok)
    return frozenset(tokens)


def check_catalog_parity(
    catalogs: Mapping[str, Mapping[str, Any]],
    *,
    reference_locale: str = "en",
) -> list[ParityViolation]:
    """Verify every locale has identical leaf keys and placeholders to `reference_locale`."""
    violations: list[ParityViolation] = []
    ref_raw = catalogs.get(reference_locale, {})
    ref_flat = _flatten_catalog(ref_raw)
    ref_keys = set(ref_flat.keys())

    for locale, raw_cat in catalogs.items():
        if locale == reference_locale:
            continue
        flat = _flatten_catalog(raw_cat)
        loc_keys = set(flat.keys())

        for missing in sorted(ref_keys - loc_keys):
            violations.append(
                ParityViolation(
                    locale=locale,
                    key_path=missing,
                    kind="missing_key",
                    detail=f"Missing key {missing!r} in locale {locale!r}",
                )
            )
        for extra in sorted(loc_keys - ref_keys):
            # Allow CLDR plural variants (_zero, _two, _few, _many) when _one/_other exists
            if extra.endswith(("_zero", "_two", "_few", "_many")):
                stem = extra.rsplit("_", 1)[0]
                if f"{stem}_one" in ref_keys or f"{stem}_other" in ref_keys:
                    continue
            violations.append(
                ParityViolation(
                    locale=locale,
                    key_path=extra,
                    kind="extra_key",
                    detail=f"Extra key {extra!r} in locale {locale!r}",
                )
            )
        for shared in sorted(ref_keys & loc_keys):
            val = flat[shared]
            if not val.strip():
                violations.append(
                    ParityViolation(
                        locale=locale,
                        key_path=shared,
                        kind="empty_value",
                        detail=f"Empty translation for {shared!r} in locale {locale!r}",
                    )
                )
            ref_tokens = extract_placeholders(ref_flat[shared])
            loc_tokens = extract_placeholders(val)
            is_plural_singular = shared.endswith(("_one", "_zero", "_two"))
            if is_plural_singular and (ref_tokens - loc_tokens) <= {"count"}:
                continue
            if ref_tokens != loc_tokens:
                violations.append(
                    ParityViolation(
                        locale=locale,
                        key_path=shared,
                        kind="placeholder_mismatch",
                        detail=(
                            f"Placeholder mismatch for {shared!r} in {locale!r}: "
                            f"expected {sorted(ref_tokens)}, got {sorted(loc_tokens)}"
                        ),
                    )
                )

    return violations


def check_locale_directory_parity(
    locales_dir: Path,
    *,
    expected_locales: tuple[str, ...] = SUPPORTED_LOCALES,
) -> list[ParityViolation]:
    """Load `{locale}.json` files from `locales_dir` and check 6-locale parity."""
    catalogs: dict[str, Mapping[str, Any]] = {}
    violations: list[ParityViolation] = []
    for loc in expected_locales:
        file_path = locales_dir / f"{loc}.json"
        if not file_path.exists():
            violations.append(
                ParityViolation(
                    locale=loc,
                    key_path="<file>",
                    kind="missing_key",
                    detail=f"Missing locale file {file_path}",
                )
            )
            continue
        catalogs[loc] = json.loads(file_path.read_text(encoding="utf-8"))

    if "en" in catalogs:
        violations.extend(check_catalog_parity(catalogs, reference_locale="en"))
    return violations
