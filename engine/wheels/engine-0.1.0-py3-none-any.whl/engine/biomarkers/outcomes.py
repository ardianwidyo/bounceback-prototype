"""Dashboard aggregation of biomarker change (F21 FR-013 to FR-016; research R5, R6).

Input is keyed by pseudonymous participant reference only. Cells with fewer than 20 paired
participants are suppressed; a subgroup whose share reaching meaningful change trails the overall
cohort by more than 10 percentage points is flagged (attention amber in the UI, never red).
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from typing import Final

from engine.biomarkers.catalog import ANALYSIS_CONFIG_VERSION, BiomarkerCode
from engine.biomarkers.change import BiomarkerChange, PairingStatus
from engine.biomarkers.stats import mean_and_ci95
from engine.biomarkers.windows import WindowType
from engine.outcome_metrics import (
    DIMENSION_SUBGROUPS,
    EQUITY_GAP_THRESHOLD_POINTS,
    K_ANONYMITY_THRESHOLD,
    SubgroupDimension,
)

ROUND_PLACES: Final = 3

ChangesByUser = Mapping[str, Sequence[BiomarkerChange]]
SubgroupAttrs = Mapping[str, Mapping[str, str]]


@dataclass(frozen=True, slots=True)
class BiomarkerOutcomeRow:
    biomarker: BiomarkerCode
    time_point: WindowType
    dimension: SubgroupDimension | None
    subgroup: str | None
    n_consenting: int
    n_paired: int
    completeness_pct: float
    mean_change: float | None
    ci_low: float | None
    ci_high: float | None
    share_meaningful_pct: float | None
    gap_points: float | None
    suppressed: bool
    equity_gap_flagged: bool
    analysis_config_version: str = ANALYSIS_CONFIG_VERSION


@dataclass(frozen=True, slots=True)
class _Cell:
    n_consenting: int
    paired: tuple[BiomarkerChange, ...]


def _cell(
    changes: ChangesByUser, users: Sequence[str], code: BiomarkerCode, tp: WindowType
) -> _Cell:
    paired = tuple(
        change
        for user in users
        for change in changes[user]
        if change.biomarker is code
        and change.time_point is tp
        and change.status is PairingStatus.PAIRED
    )
    return _Cell(len(users), paired)


def _share(cell: _Cell) -> float | None:
    flags = [c.meaningful_change_reached for c in cell.paired]
    if not flags or any(flag is None for flag in flags):
        return None
    return sum(1 for flag in flags if flag) / len(flags) * 100


def _row(
    code: BiomarkerCode,
    tp: WindowType,
    cell: _Cell,
    group: tuple[SubgroupDimension, str] | None,
    overall_share: float | None,
) -> BiomarkerOutcomeRow:
    n_paired = len(cell.paired)
    completeness = round(n_paired / cell.n_consenting * 100, 1) if cell.n_consenting else 0.0
    suppressed = BiomarkerOutcomeRow(
        biomarker=code,
        time_point=tp,
        dimension=None if group is None else group[0],
        subgroup=None if group is None else group[1],
        n_consenting=cell.n_consenting,
        n_paired=n_paired,
        completeness_pct=completeness,
        mean_change=None,
        ci_low=None,
        ci_high=None,
        share_meaningful_pct=None,
        gap_points=None,
        suppressed=True,
        equity_gap_flagged=False,
    )
    if n_paired < K_ANONYMITY_THRESHOLD:
        return suppressed
    values = [float(c.absolute_change) for c in cell.paired if c.absolute_change is not None]
    mean, low, high = mean_and_ci95(values)
    share = _share(cell)
    gap = None if group is None or share is None or overall_share is None else share - overall_share
    return replace(
        suppressed,
        mean_change=round(mean, ROUND_PLACES),
        ci_low=round(low, ROUND_PLACES),
        ci_high=round(high, ROUND_PLACES),
        share_meaningful_pct=None if share is None else round(share, 1),
        gap_points=None if gap is None else round(gap, 1),
        suppressed=False,
        equity_gap_flagged=gap is not None and gap < EQUITY_GAP_THRESHOLD_POINTS,
    )


def compute_biomarker_outcomes(
    changes_by_user: ChangesByUser,
    subgroup_attrs: SubgroupAttrs,
    time_point: WindowType,
    group_by: SubgroupDimension | None,
) -> tuple[BiomarkerOutcomeRow, ...]:
    """Overall row per biomarker, then one row per subgroup of ``group_by`` (deterministic)."""
    users = sorted(changes_by_user)
    rows: list[BiomarkerOutcomeRow] = []
    for code in BiomarkerCode:
        overall_cell = _cell(changes_by_user, users, code, time_point)
        overall_share = (
            _share(overall_cell) if len(overall_cell.paired) >= K_ANONYMITY_THRESHOLD else None
        )
        rows.append(_row(code, time_point, overall_cell, None, None))
        if group_by is None:
            continue
        for subgroup in DIMENSION_SUBGROUPS[group_by]:
            members = [u for u in users if subgroup_attrs.get(u, {}).get(group_by) == subgroup]
            cell = _cell(changes_by_user, members, code, time_point)
            rows.append(_row(code, time_point, cell, (group_by, subgroup), overall_share))
    return tuple(rows)
