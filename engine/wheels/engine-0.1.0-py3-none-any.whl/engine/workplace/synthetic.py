"""Deterministic seed-42 synthetic workplace cohorts for F22 (T006)."""

from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import UTC, date, datetime
from uuid import UUID, uuid5

from engine.aggregates import TeamMemberContribution
from engine.simulator import (
    SimulatedLapseEpisode,
    SyntheticUserPersona,
    UserArmTrajectory,
    WorkPatternSubgroupLiteral,
)
from engine.workplace.models import (
    WORKPLACE_TERMS_VERSION,
    WorkplaceCooperativeChallenge,
    WorkplaceEmployeeEnrollment,
    WorkplaceInviteBatch,
    WorkplaceOrganisation,
)

SYNTHETIC_ORG_ADHN_SLUG = "ad-health-network"
SYNTHETIC_ORG_ALNOOR_SLUG = "al-noor-clinic"

_SYNTHETIC_NAMESPACE = UUID("d3221190-54f9-4b11-8e56-9a3f28e79a12")


@dataclass(frozen=True, slots=True)
class SyntheticWorkplaceCohort:
    """Seed-42 synthetic staff cohort, trajectories, enrollments, and cooperative challenges."""

    org_slug: str
    horizon_weeks: int
    personas: tuple[SyntheticUserPersona, ...]
    trajectories: tuple[UserArmTrajectory, ...]
    enrollments: tuple[WorkplaceEmployeeEnrollment, ...]
    invite_batches: tuple[WorkplaceInviteBatch, ...]
    challenges: tuple[WorkplaceCooperativeChallenge, ...]
    team_contributions: dict[str, tuple[TeamMemberContribution, ...]]


def get_default_workplace_organisations() -> tuple[WorkplaceOrganisation, ...]:
    """Return the two seeded synthetic employer organisations (`n=48` and `n=14`)."""
    accepted_at = datetime(2026, 1, 15, 8, 30, tzinfo=UTC)
    return (
        WorkplaceOrganisation(
            org_slug=SYNTHETIC_ORG_ADHN_SLUG,
            name_en="Abu Dhabi Health Network (Synthetic)",
            name_ar="شبكة أبوظبي الصحية (اصطناعي)",
            sector="healthcare",
            terms_status="accepted",
            terms_version=WORKPLACE_TERMS_VERSION,
            accepted_by_role="Chief People & Wellbeing Officer",
            accepted_at=accepted_at,
            synthetic_cohort_size=48,
            created_at=accepted_at,
            updated_at=accepted_at,
        ),
        WorkplaceOrganisation(
            org_slug=SYNTHETIC_ORG_ALNOOR_SLUG,
            name_en="Al Noor Community Clinic (Synthetic)",
            name_ar="عيادة النور المجتمعية (اصطناعي)",
            sector="community_clinic",
            terms_status="accepted",
            terms_version=WORKPLACE_TERMS_VERSION,
            accepted_by_role="Clinic Operations Director",
            accepted_at=accepted_at,
            synthetic_cohort_size=14,
            created_at=accepted_at,
            updated_at=accepted_at,
        ),
    )


def build_synthetic_workplace_cohort(
    org_slug: str,
    *,
    seed: int = 42,
) -> SyntheticWorkplaceCohort:
    """Deterministically build a synthetic workplace cohort for `org_slug`."""
    rng = random.Random(f"{seed}:{org_slug}")
    horizon_weeks = 26
    joined_at = datetime(2026, 1, 20, 9, 0, tzinfo=UTC)
    expires_at = datetime(2026, 12, 31, 23, 59, tzinfo=UTC)

    invite_batches: tuple[WorkplaceInviteBatch, ...]
    challenges: tuple[WorkplaceCooperativeChallenge, ...]
    if org_slug == SYNTHETIC_ORG_ADHN_SLUG:
        n_staff = 48
        invite_batches = (
            WorkplaceInviteBatch(
                invite_code="ADHN-SHIFT-2026",
                org_slug=SYNTHETIC_ORG_ADHN_SLUG,
                cohort_label_en="Nursing & Shift Operations Cohort",
                cohort_label_ar="دفعة التمريض وعمليات المناوبات",
                estimated_headcount=30,
                status="active",
                expires_at=expires_at,
                created_at=joined_at,
            ),
            WorkplaceInviteBatch(
                invite_code="ADHN-DAY-2026",
                org_slug=SYNTHETIC_ORG_ADHN_SLUG,
                cohort_label_en="Daytime Outpatient & Admin Cohort",
                cohort_label_ar="دفعة العيادات الخارجية والإدارة النهارية",
                estimated_headcount=30,
                status="active",
                expires_at=expires_at,
                created_at=joined_at,
            ),
        )
        challenges = (
            WorkplaceCooperativeChallenge(
                challenge_slug="adhn-steady-steps-w12",
                org_slug=SYNTHETIC_ORG_ADHN_SLUG,
                team_slug="adhn-shift-mobility-team",
                title_en="Shared Shift Mobility & Hydration Weeks",
                title_ar="أسابيع الحركة والترطيب التعاوني للمناوبات",
                summary_en=(
                    "Every completed daily step or hydration action adds to our shared team total."
                ),
                summary_ar="كل خطوة يومية أو عادة ترطيب مكتملة تُضاف إلى مجموع فريقنا المشترك.",
                goal_metric="completed_actions",
                target_value=600,
                start_date=date(2026, 2, 1),
                end_date=date(2026, 3, 15),
                synthetic_member_count=26,
                synthetic_completed_actions=684,
                synthetic_active_days=492,
                created_at=joined_at,
            ),
            WorkplaceCooperativeChallenge(
                challenge_slug="adhn-calm-rest-circle",
                org_slug=SYNTHETIC_ORG_ADHN_SLUG,
                team_slug="adhn-evening-winddown-team",
                title_en="Evening Wind-Down Cooperative Circle",
                title_ar="دائرة الاسترخاء المسائي التعاونية",
                summary_en=(
                    "Small post-shift sleep wind-down routines counted together "
                    "without individual rankings."
                ),
                summary_ar="خطوات استرخاء مسائية بسيطة بعد المناوبة تُحتسب معاً بدون ترتيب فردي.",
                goal_metric="active_days",
                target_value=240,
                start_date=date(2026, 2, 10),
                end_date=date(2026, 3, 25),
                synthetic_member_count=14,
                synthetic_completed_actions=210,
                synthetic_active_days=168,
                created_at=joined_at,
            ),
        )
    elif org_slug == SYNTHETIC_ORG_ALNOOR_SLUG:
        n_staff = 14
        invite_batches = (
            WorkplaceInviteBatch(
                invite_code="ALNOOR-CLINIC-2026",
                org_slug=SYNTHETIC_ORG_ALNOOR_SLUG,
                cohort_label_en="Al Noor Clinic Staff Cohort",
                cohort_label_ar="دفعة موظفي عيادة النور",
                estimated_headcount=18,
                status="active",
                expires_at=expires_at,
                created_at=joined_at,
            ),
        )
        challenges = (
            WorkplaceCooperativeChallenge(
                challenge_slug="alnoor-midday-walk",
                org_slug=SYNTHETIC_ORG_ALNOOR_SLUG,
                team_slug="alnoor-care-circle",
                title_en="Midday Calm Walk Circle",
                title_ar="دائرة المشي الهادئ وقت الظهيرة",
                summary_en="Cooperative 5-minute midday walks counted as a group.",
                summary_ar="مشي تعاوني لمدة 5 دقائق وقت الظهيرة يُحتسب كمجموعة.",
                goal_metric="completed_actions",
                target_value=180,
                start_date=date(2026, 2, 1),
                end_date=date(2026, 3, 15),
                synthetic_member_count=10,
                synthetic_completed_actions=135,
                synthetic_active_days=98,
                created_at=joined_at,
            ),
        )
    else:
        n_staff = 0
        invite_batches = ()
        challenges = ()

    personas: list[SyntheticUserPersona] = []
    trajectories: list[UserArmTrajectory] = []
    enrollments: list[WorkplaceEmployeeEnrollment] = []
    team_contribs: dict[str, list[TeamMemberContribution]] = {ch.team_slug: [] for ch in challenges}

    for idx in range(n_staff):
        uid_str = f"{org_slug}-emp-{idx + 1:03d}"
        uid_uuid = uuid5(_SYNTHETIC_NAMESPACE, uid_str)

        # Work pattern & language distribution designed to test both >=20 and <20 subgroups
        if org_slug == SYNTHETIC_ORG_ADHN_SLUG:
            if idx < 25:
                wp: WorkPatternSubgroupLiteral = "day"
            elif idx < 45:
                wp = "rotating_shifts"
            else:
                wp = "night"  # n = 3 (< 20 -> triggers primary + complementary suppression!)

            if idx < 22:
                lang = "ar"
            elif idx < 44:
                lang = "en"
            else:
                lang = "tl"  # n = 4 (< 20 -> triggers primary + complementary suppression!)
        else:
            wp = "day" if idx < 9 else "rotating_shifts"
            lang = "ar" if idx < 7 else "en"

        is_shift = wp in ("rotating_shifts", "night")
        # Rotating shifts trail daytime workers by >10 pp to demonstrate attention-amber equity flag
        retained_w12 = (idx % 6 != 0) if not is_shift else (idx % 4 != 0)
        retained_w26 = (idx % 5 != 0) if not is_shift else (idx % 3 != 0)
        opted_out = idx % 19 == 18

        active_weeks_count = 22 if retained_w26 else (15 if retained_w12 else 9)
        if is_shift and retained_w26:
            active_weeks_count = 19
        weekly_active = tuple(w < active_weeks_count for w in range(horizon_weeks))
        cumulative_days = active_weeks_count * 4 + (idx % 5)

        recovered_14d = (idx % 5 != 0) if not is_shift else (idx % 3 != 0)
        rec_days = 4 + (idx % 4) if recovered_14d else 16
        episode = SimulatedLapseEpisode(
            onset_day=21 + (idx % 14),
            recovered=True,
            recovery_days=rec_days,
            recovered_within_14d=recovered_14d,
            step_down_applied=True,
        )

        persona = SyntheticUserPersona(
            user_id=uid_str,
            synthetic=True,
            language=lang,  # type: ignore[arg-type]
            nationality_group="emirati" if idx % 3 == 0 else "arab_expat",
            sex="female" if idx % 2 == 0 else "male",
            age_band="30-44" if idx % 2 == 0 else "18-29",
            work_pattern=wp,
            disability="none",
            behaviours=("movement", "sleep") if is_shift else ("movement", "nutrition"),
            preferred_window="evening" if not is_shift else "morning",
            preferred_channel="app",
            base_adherence_prob=0.78 if not is_shift else 0.64,
            night_shift_lapse_prob=0.18 if not is_shift else 0.32,
            primary_barrier="tired" if is_shift else "time",
            opt_out_sensitivity=0.08,
        )
        traj = UserArmTrajectory(
            user_id=uid_str,
            arm="adaptive",
            weekly_active=weekly_active,
            cumulative_active_days=cumulative_days,
            retained_at_w12=retained_w12,
            retained_at_w26=retained_w26,
            notification_opted_out=opted_out,
            lapse_episodes=(episode,),
        )
        personas.append(persona)
        trajectories.append(traj)

        # Assign team or no-team (autonomous enrollment without a team is a first-class path)
        team_slug: str | None
        if org_slug == SYNTHETIC_ORG_ADHN_SLUG:
            if idx < 26:
                team_slug = "adhn-shift-mobility-team"
            elif idx < 40:
                team_slug = "adhn-evening-winddown-team"
            else:
                team_slug = None  # 8 employees enrolled without a team
            inv_code = "ADHN-SHIFT-2026" if is_shift else "ADHN-DAY-2026"
        elif org_slug == SYNTHETIC_ORG_ALNOOR_SLUG:
            team_slug = "alnoor-care-circle" if idx < 10 else None
            inv_code = "ALNOOR-CLINIC-2026"
        else:
            team_slug = None
            inv_code = f"{org_slug.upper()}-2026"

        enrollments.append(
            WorkplaceEmployeeEnrollment(
                id=uuid5(_SYNTHETIC_NAMESPACE, f"enroll:{uid_str}"),
                user_id=uid_uuid,
                org_slug=org_slug,
                invite_code=inv_code,
                team_slug=team_slug,
                status="active",
                joined_at=joined_at,
                updated_at=joined_at,
                left_at=None,
            )
        )

        if team_slug is not None and team_slug in team_contribs:
            actions_count = 24 + (idx % 6)
            days_count = 18 + (idx % 4)
            team_contribs[team_slug].append(
                TeamMemberContribution(
                    member_key=str(uid_uuid),
                    completed_actions=actions_count,
                    active_days=days_count,
                )
            )
        _ = rng

    return SyntheticWorkplaceCohort(
        org_slug=org_slug,
        horizon_weeks=horizon_weeks,
        personas=tuple(personas),
        trajectories=tuple(trajectories),
        enrollments=tuple(enrollments),
        invite_batches=invite_batches,
        challenges=challenges,
        team_contributions={k: tuple(v) for k, v in team_contribs.items()},
    )
