"""Protocol, context, and verdict models for the Central Guardrail & Policy Engine (F13)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict, Field

PolicyScope = Literal[
    "selector_candidate",
    "plan_progression",
    "coach_input",
    "coach_output",
]
PolicyVerdictKind = Literal["allow", "modify", "block"]
PolicyCategory = Literal[
    "environment",
    "cultural",
    "dose_safety",
    "contraindication",
    "anti_manipulation",
    "clinical_red_flag",
]
LevelLiteral = Literal["L1", "L2", "L3", "L4", "L5"]
RedFlagCategoryLiteral = Literal[
    "chest_pain",
    "self_harm",
    "disordered_eating",
    "pregnancy_complication",
    "emergency_symptom",
]
EscalationSeverityLiteral = Literal["high", "critical"]
SupportedPolicyLocale = Literal["ar", "en", "ur", "hi", "tl", "ml"]

LEVEL_TO_RANK: dict[str, int] = {"L1": 1, "L2": 2, "L3": 3, "L4": 4, "L5": 5}
RANK_TO_LEVEL: dict[int, LevelLiteral] = {
    1: "L1",
    2: "L2",
    3: "L3",
    4: "L4",
    5: "L5",
}


class PolicyRuleSpec(BaseModel):
    """Versioned rule specification loaded from rules.yaml."""

    model_config = ConfigDict(frozen=True)

    rule_id: str
    category: PolicyCategory
    applies_to: tuple[PolicyScope, ...]
    priority: int = Field(ge=1, le=1000)
    default_verdict: PolicyVerdictKind
    parameters: dict[str, Any] = Field(default_factory=dict)
    rationale: str


class CandidatePolicyContext(BaseModel):
    """Input context for evaluating a selector candidate arm (scope = 'selector_candidate')."""

    model_config = ConfigDict(frozen=True)

    user_id: str = "anonymous"
    slot_id: str = "slot-1"
    action_id: str
    habit_domain: str
    variant_kind: Literal["primary", "smaller"] = "primary"
    level: LevelLiteral = "L1"
    time_window: Literal["morning", "afternoon", "evening", "night"] = "evening"
    current_time_window: Literal["morning", "afternoon", "evening", "night"] = "evening"
    channel: Literal["app", "whatsapp", "sms"] = "app"
    local_date: str = "2026-04-20"
    local_time: str = "18:00"
    city: str = "abu_dhabi"
    heat_index_c: float | None = None
    ramadan_mode: bool = False
    active_barriers: tuple[str, ...] = ()
    contraindications: tuple[str, ...] = ()
    avoid_contexts: tuple[str, ...] = ()
    baseline_level_7d: LevelLiteral | None = None
    has_open_red_flag: bool = False
    available_indoor_actions: dict[str, tuple[str, ...]] | None = None


class PlanProgressionPolicyContext(BaseModel):
    """Input context for evaluating a plan level progression (scope = 'plan_progression')."""

    model_config = ConfigDict(frozen=True)

    user_id: str = "anonymous"
    habit_domain: str = "movement"
    baseline_level_7d: LevelLiteral = "L1"
    current_level: LevelLiteral = "L1"
    proposed_level: LevelLiteral = "L1"
    active_barriers: tuple[str, ...] = ()
    contraindications: tuple[str, ...] = ()
    action_contraindications: tuple[str, ...] = ()
    has_open_red_flag: bool = False


class MessagePolicyContext(BaseModel):
    """Input context for evaluating coach input or output text."""

    model_config = ConfigDict(frozen=True)

    user_id: str = "anonymous"
    direction: Literal["input", "output"] | None = None
    text: str
    locale: SupportedPolicyLocale = "en"
    max_words: int = 60
    has_open_red_flag: bool = False


PolicyContextUnion = CandidatePolicyContext | PlanProgressionPolicyContext | MessagePolicyContext


class RuleTriggerRecord(BaseModel):
    """Single rule evaluation trigger when a rule modifies or blocks an item."""

    model_config = ConfigDict(frozen=True)

    rule_id: str
    verdict: PolicyVerdictKind
    reason: str
    modified_fields: dict[str, Any] = Field(default_factory=dict)
    red_flag_category: RedFlagCategoryLiteral | None = None
    severity: EscalationSeverityLiteral | None = None
    fallback_template_id: str | None = None


class PolicyEvaluationResult(BaseModel):
    """Deterministic result of running all applicable rules in the policy registry."""

    model_config = ConfigDict(frozen=True)

    policy_version: str
    scope: PolicyScope
    verdict: PolicyVerdictKind
    triggered_rules: tuple[RuleTriggerRecord, ...] = ()
    rule_ids: tuple[str, ...] = ()
    modified_payload: dict[str, Any] = Field(default_factory=dict)
    inputs_snapshot: dict[str, Any] = Field(default_factory=dict)
    escalation_triggered: bool = False
    red_flag_category: RedFlagCategoryLiteral | None = None
    escalation_severity: EscalationSeverityLiteral | None = None
    fallback_template_id: str | None = None

    @property
    def escalation_required(self) -> bool:
        return self.escalation_triggered

    @property
    def red_flag_escalation_required(self) -> bool:
        return self.escalation_triggered


class HeatIndexReading(BaseModel):
    """City-level heat-index reading used by environmental policy evaluation."""

    model_config = ConfigDict(frozen=True)

    city: str
    temperature_c: float
    relative_humidity_pct: float
    heat_index_c: float
    threshold_c: float = 40.0
    exceeds_threshold: bool
    source: Literal["live_api", "cached_weather", "synthetic_override", "seasonal_fallback"]
    observed_at: datetime


class PrayerWindow(BaseModel):
    """Daily prayer time window with configurable +-buffer_minutes."""

    model_config = ConfigDict(frozen=True)

    prayer_name: Literal["fajr", "dhuhr", "asr", "maghrib", "isha"]
    center_time: str
    window_start: str
    window_end: str


@runtime_checkable
class Rule(Protocol):
    """Protocol implemented by every guardrail policy rule in packages/engine/policy."""

    @property
    def rule_id(self) -> str: ...

    @property
    def applies_to(self) -> tuple[PolicyScope, ...]: ...

    @property
    def priority(self) -> int: ...

    def evaluate(self, ctx: PolicyContextUnion) -> RuleTriggerRecord | None: ...
