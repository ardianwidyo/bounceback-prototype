"""Pure sovereign Azure infrastructure, UAE North OpenAI, budget, OIDC & rollback engine (F18).

All functions in this module are pure and deterministic given their explicit inputs.
"""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Literal

InfraEnvironmentLiteral = Literal["dev", "staging", "prod"]
InfraDeploymentModeLiteral = Literal[
    "automatic_on_main",
    "promoted_after_dev",
    "manual_approval_required",
]
ApimSkuLiteral = Literal["Consumption", "StandardV2", "Premium"]
StaticWebAppsSkuLiteral = Literal["Free", "Standard"]
InfraLayerIdLiteral = Literal[
    "container_apps",
    "api_management",
    "postgres_flexible",
    "key_vault",
    "azure_openai",
    "communication_services",
    "log_analytics",
    "static_web_apps",
    "consumption_budgets",
]

SOVEREIGN_AZURE_REGION: Literal["uaenorth"] = "uaenorth"
_REVISION_NAME_RE = re.compile(r"^[A-Za-z0-9._-]{3,64}$")


class InfrastructureValidationError(ValueError):
    """Raised when a region, model SKU, or environment violates sovereign policy."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


class RollbackConflictError(ValueError):
    """Raised when a one-step rollback request specifies conflicting or invalid revisions."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass(frozen=True, slots=True)
class UaeNorthOpenAiModelSpec:
    model_name: Literal["gpt-4o-mini", "gpt-4o", "text-embedding-3-small"]
    model_version: str
    sku_name: Literal["Standard", "GlobalStandard"]
    region: Literal["uaenorth"]
    purpose: Literal["grounded_coach_chat", "semantic_embeddings"]
    content_safety_policy: str


@dataclass(frozen=True, slots=True)
class BudgetAlertThreshold:
    name: str
    threshold_percent: int
    threshold_type: Literal["Actual", "Forecasted"]
    enabled: bool


@dataclass(frozen=True, slots=True)
class EnvironmentProfile:
    environment: InfraEnvironmentLiteral
    location: str
    deployment_mode: InfraDeploymentModeLiteral
    requires_manual_approval: bool
    container_apps_cpu: float
    container_apps_memory_gib: float
    container_apps_min_replicas: int
    container_apps_max_replicas: int
    apim_sku: ApimSkuLiteral
    postgres_sku: str
    postgres_storage_gb: int
    static_web_apps_sku: StaticWebAppsSkuLiteral
    openai_model_name: str
    openai_model_version: str
    openai_capacity_tpm_thousands: int
    monthly_budget_usd: int
    estimated_monthly_cost_usd: int
    within_budget: bool
    budget_alerts: tuple[BudgetAlertThreshold, ...]


@dataclass(frozen=True, slots=True)
class InfraServiceLayerCheck:
    layer_id: InfraLayerIdLiteral
    bicep_module: str
    resource_type: str
    region_locked_uaenorth: bool
    managed_identity_enabled: bool
    status: Literal["verified", "failed"]


@dataclass(frozen=True, slots=True)
class OidcPipelineCheck:
    workflow_path: str
    oidc_federation_enabled: bool
    stored_secrets_count: int
    auto_deploy_dev: bool
    manual_approval_prod: bool
    one_step_rollback_supported: bool
    compliant: bool


@dataclass(frozen=True, slots=True)
class InfrastructureTopologyReport:
    ready: bool
    sovereign_region: str
    all_resources_in_uaenorth: bool
    openai_models_verified_in_uaenorth: bool
    supported_openai_models: tuple[UaeNorthOpenAiModelSpec, ...]
    service_layers: tuple[InfraServiceLayerCheck, ...]
    environments: tuple[EnvironmentProfile, ...]
    dev_cost_under_budget: bool
    budget_alerts_active: bool
    oidc_pipeline: OidcPipelineCheck
    rollback_script_ready: bool


@dataclass(frozen=True, slots=True)
class RollbackExecutionPlan:
    environment: InfraEnvironmentLiteral
    region: str
    container_app_name: str
    current_revision: str
    target_revision: str
    traffic_weight_percent: int
    single_step_command: str
    powershell_invocation: str
    database_schema_compatible: bool
    health_probe_url: str
    security_posture_probe_url: str
    status: Literal["ready_to_execute"]


UAE_NORTH_OPENAI_MODEL_CATALOG: tuple[UaeNorthOpenAiModelSpec, ...] = (
    UaeNorthOpenAiModelSpec(
        model_name="gpt-4o-mini",
        model_version="2024-07-18",
        sku_name="Standard",
        region="uaenorth",
        purpose="grounded_coach_chat",
        content_safety_policy="BounceBackSafety",
    ),
    UaeNorthOpenAiModelSpec(
        model_name="gpt-4o",
        model_version="2024-08-06",
        sku_name="Standard",
        region="uaenorth",
        purpose="grounded_coach_chat",
        content_safety_policy="BounceBackSafety",
    ),
    UaeNorthOpenAiModelSpec(
        model_name="text-embedding-3-small",
        model_version="1",
        sku_name="Standard",
        region="uaenorth",
        purpose="semantic_embeddings",
        content_safety_policy="BounceBackSafety",
    ),
)

DEFAULT_BUDGET_ALERTS: tuple[BudgetAlertThreshold, ...] = (
    BudgetAlertThreshold(
        name="Actual_GreaterThan_50_Percent",
        threshold_percent=50,
        threshold_type="Actual",
        enabled=True,
    ),
    BudgetAlertThreshold(
        name="Actual_GreaterThan_80_Percent",
        threshold_percent=80,
        threshold_type="Actual",
        enabled=True,
    ),
    BudgetAlertThreshold(
        name="Actual_GreaterThan_100_Percent",
        threshold_percent=100,
        threshold_type="Actual",
        enabled=True,
    ),
    BudgetAlertThreshold(
        name="Forecasted_GreaterThan_100_Percent",
        threshold_percent=100,
        threshold_type="Forecasted",
        enabled=True,
    ),
)

ENVIRONMENT_PROFILES: dict[InfraEnvironmentLiteral, EnvironmentProfile] = {
    "dev": EnvironmentProfile(
        environment="dev",
        location="uaenorth",
        deployment_mode="automatic_on_main",
        requires_manual_approval=False,
        container_apps_cpu=0.25,
        container_apps_memory_gib=0.5,
        container_apps_min_replicas=0,
        container_apps_max_replicas=2,
        apim_sku="Consumption",
        postgres_sku="Standard_B1ms",
        postgres_storage_gb=32,
        static_web_apps_sku="Free",
        openai_model_name="gpt-4o-mini",
        openai_model_version="2024-07-18",
        openai_capacity_tpm_thousands=10,
        monthly_budget_usd=150,
        estimated_monthly_cost_usd=88,
        within_budget=True,
        budget_alerts=DEFAULT_BUDGET_ALERTS,
    ),
    "staging": EnvironmentProfile(
        environment="staging",
        location="uaenorth",
        deployment_mode="promoted_after_dev",
        requires_manual_approval=False,
        container_apps_cpu=0.5,
        container_apps_memory_gib=1.0,
        container_apps_min_replicas=1,
        container_apps_max_replicas=4,
        apim_sku="StandardV2",
        postgres_sku="Standard_D2ds_v4",
        postgres_storage_gb=64,
        static_web_apps_sku="Standard",
        openai_model_name="gpt-4o-mini",
        openai_model_version="2024-07-18",
        openai_capacity_tpm_thousands=30,
        monthly_budget_usd=400,
        estimated_monthly_cost_usd=265,
        within_budget=True,
        budget_alerts=DEFAULT_BUDGET_ALERTS,
    ),
    "prod": EnvironmentProfile(
        environment="prod",
        location="uaenorth",
        deployment_mode="manual_approval_required",
        requires_manual_approval=True,
        container_apps_cpu=1.0,
        container_apps_memory_gib=2.0,
        container_apps_min_replicas=2,
        container_apps_max_replicas=10,
        apim_sku="Premium",
        postgres_sku="Standard_D2ds_v4",
        postgres_storage_gb=128,
        static_web_apps_sku="Standard",
        openai_model_name="gpt-4o-mini",
        openai_model_version="2024-07-18",
        openai_capacity_tpm_thousands=80,
        monthly_budget_usd=1500,
        estimated_monthly_cost_usd=920,
        within_budget=True,
        budget_alerts=DEFAULT_BUDGET_ALERTS,
    ),
}

_REQUIRED_LAYER_SPECS: tuple[tuple[InfraLayerIdLiteral, str, str], ...] = (
    (
        "key_vault",
        "key-vault.bicep",
        "Microsoft.KeyVault/vaults",
    ),
    (
        "postgres_flexible",
        "postgres.bicep",
        "Microsoft.DBforPostgreSQL/flexibleServers",
    ),
    (
        "log_analytics",
        "log-analytics.bicep",
        "Microsoft.OperationalInsights/workspaces",
    ),
    (
        "container_apps",
        "container-apps.bicep",
        "Microsoft.App/containerApps",
    ),
    (
        "api_management",
        "apim.bicep",
        "Microsoft.ApiManagement/service",
    ),
    (
        "azure_openai",
        "openai.bicep",
        "Microsoft.CognitiveServices/accounts",
    ),
    (
        "communication_services",
        "communication.bicep",
        "Microsoft.Communication/communicationServices",
    ),
    (
        "static_web_apps",
        "static-web-apps.bicep",
        "Microsoft.Web/staticSites",
    ),
    (
        "consumption_budgets",
        "budgets.bicep",
        "Microsoft.Consumption/budgets",
    ),
)


def verify_uaenorth_openai_model(
    *,
    model_name: str,
    model_version: str,
    region: str = SOVEREIGN_AZURE_REGION,
) -> UaeNorthOpenAiModelSpec:
    """Verify that an Azure OpenAI model and version are confirmed available in UAE North."""
    if region.strip().lower() != SOVEREIGN_AZURE_REGION:
        raise InfrastructureValidationError(
            "unsupported_region_or_model",
            f"Azure OpenAI residency must be locked to '{SOVEREIGN_AZURE_REGION}', got '{region}'.",
        )
    for spec in UAE_NORTH_OPENAI_MODEL_CATALOG:
        if spec.model_name == model_name and spec.model_version == model_version:
            return spec
    raise InfrastructureValidationError(
        "unsupported_region_or_model",
        f"Model '{model_name}' ({model_version}) is not in the confirmed UAE North catalog.",
    )


def evaluate_bicep_service_layers(
    module_contents: Mapping[str, str],
) -> tuple[InfraServiceLayerCheck, ...]:
    """Inspect Bicep module texts and verify all 9 required sovereign service layers."""
    checks: list[InfraServiceLayerCheck] = []
    for layer_id, filename, resource_type in _REQUIRED_LAYER_SPECS:
        content = module_contents.get(filename) or module_contents.get(
            f"infra/bicep/modules/{filename}", ""
        )
        has_resource = resource_type in content
        region_ok = "'uaenorth'" in content or "'UAE'" in content
        if layer_id in ("log_analytics", "consumption_budgets"):
            identity_ok = True
        else:
            identity_ok = (
                "identity" in content.lower()
                or "userAssignedIdentities" in content
                or "SystemAssigned" in content
                or "UserAssigned" in content
            )
        verified = bool(content) and has_resource and region_ok and identity_ok
        checks.append(
            InfraServiceLayerCheck(
                layer_id=layer_id,
                bicep_module=f"infra/bicep/modules/{filename}",
                resource_type=resource_type,
                region_locked_uaenorth=region_ok,
                managed_identity_enabled=identity_ok,
                status="verified" if verified else "failed",
            )
        )
    return tuple(checks)


def evaluate_budget_alerts(
    alerts: Sequence[BudgetAlertThreshold],
) -> bool:
    """Verify that 50%, 80%, 100% actual and 100% forecasted budget alerts are active."""
    active_pairs = {(a.threshold_type, a.threshold_percent) for a in alerts if a.enabled}
    required = {
        ("Actual", 50),
        ("Actual", 80),
        ("Actual", 100),
        ("Forecasted", 100),
    }
    return required.issubset(active_pairs)


def evaluate_environment_profile(
    profile: EnvironmentProfile,
) -> bool:
    """Verify residency, cost under budget cap, replica bounds, and active budget alerts."""
    if profile.location.strip().lower() != SOVEREIGN_AZURE_REGION:
        return False
    if profile.estimated_monthly_cost_usd >= profile.monthly_budget_usd:
        return False
    if not profile.within_budget:
        return False
    if not evaluate_budget_alerts(profile.budget_alerts):
        return False
    try:
        verify_uaenorth_openai_model(
            model_name=profile.openai_model_name,
            model_version=profile.openai_model_version,
            region=profile.location,
        )
    except InfrastructureValidationError:
        return False
    return not (
        profile.environment == "prod"
        and (not profile.requires_manual_approval or profile.container_apps_min_replicas < 2)
    )


def evaluate_oidc_pipeline_compliance(
    workflow_text: str,
    *,
    workflow_path: str = ".github/workflows/deploy.yml",
) -> OidcPipelineCheck:
    """Audit GitHub Actions deployment workflow for OIDC federation and zero stored secrets."""
    oidc_enabled = (
        "id-token: write" in workflow_text
        and "azure/login" in workflow_text
        and "AZURE_CLIENT_ID" in workflow_text
        and "AZURE_TENANT_ID" in workflow_text
        and "AZURE_SUBSCRIPTION_ID" in workflow_text
    )
    forbidden_secret_patterns = (
        "client-secret",
        "AZURE_CREDENTIALS",
        "AZURE_CLIENT_SECRET",
        "creds:",
    )
    stored_secrets_count = sum(1 for pat in forbidden_secret_patterns if pat in workflow_text)
    auto_dev = "deploy-dev" in workflow_text and "environment: dev" in workflow_text
    manual_prod = "deploy-prod" in workflow_text and (
        "name: prod" in workflow_text or "environment: prod" in workflow_text
    )
    rollback_ok = "rollback" in workflow_text and "rollback.ps1" in workflow_text
    compliant = (
        oidc_enabled and stored_secrets_count == 0 and auto_dev and manual_prod and rollback_ok
    )
    return OidcPipelineCheck(
        workflow_path=workflow_path,
        oidc_federation_enabled=oidc_enabled,
        stored_secrets_count=stored_secrets_count,
        auto_deploy_dev=auto_dev,
        manual_approval_prod=manual_prod,
        one_step_rollback_supported=rollback_ok,
        compliant=compliant,
    )


def evaluate_infrastructure_topology(
    *,
    module_contents: Mapping[str, str],
    workflow_text: str,
    rollback_script_present: bool,
    environments: Sequence[EnvironmentProfile] | None = None,
) -> InfrastructureTopologyReport:
    """Evaluate UAE North Bicep topology, cost budgets, OIDC CI/CD, and rollback readiness."""
    resolved_envs = tuple(environments or ENVIRONMENT_PROFILES.values())
    layer_checks = evaluate_bicep_service_layers(module_contents)
    all_layers_ok = len(layer_checks) == 9 and all(c.status == "verified" for c in layer_checks)
    all_residency_ok = all(c.region_locked_uaenorth for c in layer_checks) and all(
        e.location == SOVEREIGN_AZURE_REGION for e in resolved_envs
    )
    env_checks_ok = len(resolved_envs) == 3 and all(
        evaluate_environment_profile(e) for e in resolved_envs
    )
    dev_profiles = [e for e in resolved_envs if e.environment == "dev"]
    dev_under_budget = bool(dev_profiles) and all(
        d.estimated_monthly_cost_usd < d.monthly_budget_usd for d in dev_profiles
    )
    budgets_active = all(evaluate_budget_alerts(e.budget_alerts) for e in resolved_envs)
    oidc_check = evaluate_oidc_pipeline_compliance(workflow_text)

    openai_ok = True
    for env in resolved_envs:
        try:
            verify_uaenorth_openai_model(
                model_name=env.openai_model_name,
                model_version=env.openai_model_version,
                region=env.location,
            )
        except InfrastructureValidationError:
            openai_ok = False

    ready = (
        all_layers_ok
        and all_residency_ok
        and openai_ok
        and env_checks_ok
        and dev_under_budget
        and budgets_active
        and oidc_check.compliant
        and rollback_script_present
    )

    return InfrastructureTopologyReport(
        ready=ready,
        sovereign_region=SOVEREIGN_AZURE_REGION,
        all_resources_in_uaenorth=all_residency_ok,
        openai_models_verified_in_uaenorth=openai_ok,
        supported_openai_models=UAE_NORTH_OPENAI_MODEL_CATALOG,
        service_layers=layer_checks,
        environments=resolved_envs,
        dev_cost_under_budget=dev_under_budget,
        budget_alerts_active=budgets_active,
        oidc_pipeline=oidc_check,
        rollback_script_ready=rollback_script_present,
    )


def plan_one_step_rollback(
    *,
    environment: str,
    current_revision: str,
    target_revision: str,
    region: str = SOVEREIGN_AZURE_REGION,
    name_prefix: str = "bounceback",
    database_schema_compatible: bool = True,
) -> RollbackExecutionPlan:
    """Build a deterministic one-step rollback execution plan to a previous healthy revision."""
    if environment not in ("dev", "staging", "prod"):
        raise InfrastructureValidationError(
            "invalid_environment",
            f"Unsupported environment '{environment}'; must be one of dev, staging, prod.",
        )
    if region.strip().lower() != SOVEREIGN_AZURE_REGION:
        raise InfrastructureValidationError(
            "unsupported_region_or_model",
            f"Rollback target region must be '{SOVEREIGN_AZURE_REGION}'.",
        )
    curr = current_revision.strip()
    targ = target_revision.strip()
    if not _REVISION_NAME_RE.fullmatch(curr) or not _REVISION_NAME_RE.fullmatch(targ):
        raise RollbackConflictError(
            "rollback_revision_conflict",
            "Revision identifiers must be 3-64 alphanumeric/hyphen characters.",
        )
    if curr == targ:
        raise RollbackConflictError(
            "rollback_revision_conflict",
            "target_revision must differ from current_revision for a rollback.",
        )
    if not database_schema_compatible:
        raise RollbackConflictError(
            "rollback_revision_conflict",
            "Target revision is not compatible with active database schema.",
        )

    typed_env: InfraEnvironmentLiteral = environment  # type: ignore[assignment]
    resource_group = f"rg-{name_prefix}-{typed_env}-{SOVEREIGN_AZURE_REGION}"
    container_app = f"ca-{name_prefix}-api-{typed_env}-{SOVEREIGN_AZURE_REGION}"
    apim_host = f"apim-{name_prefix}-{typed_env}-{SOVEREIGN_AZURE_REGION}.azure-api.net"

    single_cmd = (
        f"az containerapp ingress traffic set "
        f"--name {container_app} "
        f"--resource-group {resource_group} "
        f"--revision-weight {targ}=100"
    )
    ps_cmd = (
        f"pwsh -File infra/scripts/rollback.ps1 "
        f"-Environment {typed_env} "
        f"-CurrentRevision {curr} "
        f"-TargetRevision {targ}"
    )

    return RollbackExecutionPlan(
        environment=typed_env,
        region=SOVEREIGN_AZURE_REGION,
        container_app_name=container_app,
        current_revision=curr,
        target_revision=targ,
        traffic_weight_percent=100,
        single_step_command=single_cmd,
        powershell_invocation=ps_cmd,
        database_schema_compatible=database_schema_compatible,
        health_probe_url=f"https://{apim_host}/health",
        security_posture_probe_url=f"https://{apim_host}/security/posture",
        status="ready_to_execute",
    )
