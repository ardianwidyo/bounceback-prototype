"""Versioned YAML policy registry and evaluation pipeline (F13)."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Literal, cast

import yaml

from engine.policy.protocol import (
    CandidatePolicyContext,
    EscalationSeverityLiteral,
    MessagePolicyContext,
    PlanProgressionPolicyContext,
    PolicyContextUnion,
    PolicyEvaluationResult,
    PolicyRuleSpec,
    PolicyScope,
    PolicyVerdictKind,
    RedFlagCategoryLiteral,
    Rule,
    RuleTriggerRecord,
)
from engine.policy.rules import (
    ActiveRedFlagHoldRule,
    BlameOrGuiltLanguageRule,
    ClinicalRedFlagEscalationRule,
    ContraindicatedActionRule,
    HeatIndexOutdoorBlockRule,
    HeatIndexOutdoorSubstitutionRule,
    ManipulativeCountdownPressureRule,
    ManipulativeStreakLanguageRule,
    MaxWeeklyLevelIncreaseRule,
    MedicalBoundaryRefusalRule,
    PainIllnessPhysicalPauseRule,
    PrayerTimeWindowRule,
    RamadanFastingWindowRule,
)

POLICY_VERSION: Literal["policy-v1.0.0"] = "policy-v1.0.0"
_RULES_YAML_PATH = Path(__file__).with_name("rules.yaml")

_RULE_CLASS_MAP: dict[str, type[Any]] = {
    "clinical_red_flag_escalation": ClinicalRedFlagEscalationRule,
    "active_red_flag_hold": ActiveRedFlagHoldRule,
    "medical_boundary_refusal": MedicalBoundaryRefusalRule,
    "pain_illness_physical_pause": PainIllnessPhysicalPauseRule,
    "contraindicated_action": ContraindicatedActionRule,
    "prayer_time_window": PrayerTimeWindowRule,
    "ramadan_fasting_window": RamadanFastingWindowRule,
    "heat_index_outdoor_substitution": HeatIndexOutdoorSubstitutionRule,
    "heat_index_outdoor_block": HeatIndexOutdoorBlockRule,
    "max_weekly_level_increase": MaxWeeklyLevelIncreaseRule,
    "manipulative_streak_language": ManipulativeStreakLanguageRule,
    "manipulative_countdown_pressure": ManipulativeCountdownPressureRule,
    "blame_or_guilt_language": BlameOrGuiltLanguageRule,
}


class PolicyRegistry:
    """Immutable, priority-ordered guardrail policy registry loaded from rules.yaml."""

    def __init__(
        self,
        *,
        policy_version: str,
        heat_index_threshold_c: float,
        prayer_buffer_minutes: int,
        max_weekly_level_delta: int,
        outdoor_to_indoor_map: dict[str, str],
        rule_specs: tuple[PolicyRuleSpec, ...],
        rules: tuple[Rule, ...],
    ) -> None:
        self.policy_version = policy_version
        self.heat_index_threshold_c = heat_index_threshold_c
        self.prayer_buffer_minutes = prayer_buffer_minutes
        self.max_weekly_level_delta = max_weekly_level_delta
        self.outdoor_to_indoor_map = dict(outdoor_to_indoor_map)
        self.rule_specs = rule_specs
        self.rules = tuple(sorted(rules, key=lambda r: (r.priority, r.rule_id)))

    def rules_for_scope(self, scope: PolicyScope) -> tuple[Rule, ...]:
        return tuple(r for r in self.rules if scope in r.applies_to)

    def evaluate(
        self,
        scope: PolicyScope,
        ctx: PolicyContextUnion,
    ) -> PolicyEvaluationResult:
        triggered: list[RuleTriggerRecord] = []
        modified_payload: dict[str, Any] = {}
        final_verdict: PolicyVerdictKind = "allow"
        escalation_triggered = False
        red_flag_category: RedFlagCategoryLiteral | None = None
        escalation_severity: EscalationSeverityLiteral | None = None
        fallback_template_id: str | None = None

        for rule in self.rules_for_scope(scope):
            trigger = rule.evaluate(ctx)
            if trigger is None:
                continue
            triggered.append(trigger)
            if trigger.modified_fields:
                modified_payload.update(trigger.modified_fields)
            if trigger.fallback_template_id and fallback_template_id is None:
                fallback_template_id = trigger.fallback_template_id
            if trigger.red_flag_category is not None:
                escalation_triggered = True
                red_flag_category = trigger.red_flag_category
                escalation_severity = trigger.severity or "critical"

            if trigger.verdict == "block":
                final_verdict = "block"
            elif trigger.verdict == "modify" and final_verdict != "block":
                final_verdict = "modify"

        return PolicyEvaluationResult(
            policy_version=self.policy_version,
            scope=scope,
            verdict=final_verdict,
            triggered_rules=tuple(triggered),
            rule_ids=tuple(t.rule_id for t in triggered),
            modified_payload=modified_payload,
            escalation_triggered=escalation_triggered,
            red_flag_category=red_flag_category,
            escalation_severity=escalation_severity,
            fallback_template_id=fallback_template_id,
        )


@lru_cache(maxsize=4)
def load_policy_registry(yaml_path: Path | None = None) -> PolicyRegistry:
    """Load and validate the central guardrail policy catalog from rules.yaml."""
    target = yaml_path or _RULES_YAML_PATH
    raw = yaml.safe_load(target.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"Invalid policy catalog YAML at {target}")

    policy_version = str(raw.get("policy_version", POLICY_VERSION))
    heat_threshold = float(raw.get("heat_index_threshold_c", 40.0))
    prayer_buffer = int(raw.get("prayer_buffer_minutes", 15))
    max_delta = int(raw.get("max_weekly_level_delta", 1))
    outdoor_map = {str(k): str(v) for k, v in (raw.get("outdoor_to_indoor_map") or {}).items()}

    specs: list[PolicyRuleSpec] = []
    rule_instances: list[Rule] = []
    for item in raw.get("rules", []):
        spec = PolicyRuleSpec.model_validate(item)
        specs.append(spec)
        cls = _RULE_CLASS_MAP.get(spec.rule_id)
        if cls is None:
            raise KeyError(f"Unknown policy rule_id in catalog: {spec.rule_id!r}")
        rule_instances.append(cls(spec))

    specs.sort(key=lambda s: (s.priority, s.rule_id))
    return PolicyRegistry(
        policy_version=policy_version,
        heat_index_threshold_c=heat_threshold,
        prayer_buffer_minutes=prayer_buffer,
        max_weekly_level_delta=max_delta,
        outdoor_to_indoor_map=outdoor_map,
        rule_specs=tuple(specs),
        rules=tuple(rule_instances),
    )


def evaluate_candidate_policy(
    ctx: CandidatePolicyContext,
    registry: PolicyRegistry | None = None,
) -> PolicyEvaluationResult:
    reg = registry or load_policy_registry()
    return reg.evaluate("selector_candidate", ctx)


def evaluate_plan_progression_policy(
    ctx: PlanProgressionPolicyContext,
    registry: PolicyRegistry | None = None,
) -> PolicyEvaluationResult:
    reg = registry or load_policy_registry()
    return reg.evaluate("plan_progression", ctx)


def evaluate_coach_input_policy(
    ctx: MessagePolicyContext,
    registry: PolicyRegistry | None = None,
) -> PolicyEvaluationResult:
    reg = registry or load_policy_registry()
    return reg.evaluate("coach_input", ctx)


def evaluate_coach_output_policy(
    ctx: MessagePolicyContext,
    registry: PolicyRegistry | None = None,
) -> PolicyEvaluationResult:
    reg = registry or load_policy_registry()
    return reg.evaluate("coach_output", ctx)


def replay_policy_evaluation(
    scope: str,
    payload: dict[str, Any],
    registry: PolicyRegistry | None = None,
) -> PolicyEvaluationResult:
    """Deterministically replay a policy evaluation from its serialized context snapshot."""
    reg = registry or load_policy_registry()
    typed_scope = cast(PolicyScope, scope)
    if typed_scope == "selector_candidate":
        return reg.evaluate(typed_scope, CandidatePolicyContext.model_validate(payload))
    if typed_scope == "plan_progression":
        return reg.evaluate(typed_scope, PlanProgressionPolicyContext.model_validate(payload))
    if typed_scope in ("coach_input", "coach_output"):
        return reg.evaluate(typed_scope, MessagePolicyContext.model_validate(payload))
    raise ValueError(f"Unsupported policy scope: {scope!r}")
