"""Clickable-prototype helpers: Synthea ingestion and scripted journeys (synthetic only)."""
