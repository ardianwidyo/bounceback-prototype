"""Low-health-literacy readability and native-speaker review gate linter (F12, FR-010)."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

from content.coach_loader import REQUIRED_COACH_TEMPLATE_IDS, load_coach_messages
from content.copy_lint import count_words, lint_text
from content.library import SUPPORTED_LOCALES, load_library
from content.recovery_library import USER_SELECTABLE_BARRIERS, load_recovery_messages

MAX_ACTION_INSTRUCTION_WORDS = 25
MAX_COACH_TEMPLATE_WORDS = 60

MEDICAL_JARGON_TERMS: tuple[str, ...] = (
    "circadian phase",
    "glycemic index",
    "postprandial",
    "parasympathetic",
    "catecholamine",
    "hyperlipidemia",
    "tachycardia",
    "pharmacotherapy",
    "contraindicated",
    "pathophysiology",
    "prophylaxis",
    "etiological",
)

_JARGON_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = tuple(
    (term, re.compile(rf"\b{re.escape(term)}\b", re.IGNORECASE)) for term in MEDICAL_JARGON_TERMS
)


@dataclass(frozen=True, slots=True)
class ReadabilityViolation:
    locale: str
    source: str
    item_id: str
    rule: str  # "max_words" | "medical_jargon" | "copy_lint" | "review_status"
    detail: str


def lint_readability_text(
    text: str,
    *,
    locale: str,
    source: str,
    item_id: str,
    max_words: int,
) -> list[ReadabilityViolation]:
    """Check a single string against word limit, medical jargon, and blame-free rules."""
    violations: list[ReadabilityViolation] = []
    wc = count_words(text)
    if wc > max_words:
        violations.append(
            ReadabilityViolation(
                locale=locale,
                source=source,
                item_id=item_id,
                rule="max_words",
                detail=f"{wc} words exceeds limit of {max_words}: {text!r}",
            )
        )
    for term, pattern in _JARGON_PATTERNS:
        if pattern.search(text):
            violations.append(
                ReadabilityViolation(
                    locale=locale,
                    source=source,
                    item_id=item_id,
                    rule="medical_jargon",
                    detail=f"Medical jargon {term!r} found in {text!r}",
                )
            )
    for cv in lint_text(text, source=source, field_path=item_id):
        violations.append(
            ReadabilityViolation(
                locale=locale,
                source=source,
                item_id=item_id,
                rule="copy_lint",
                detail=f"Blame-free violation ({cv.matched_term!r}) in {text!r}",
            )
        )
    return violations


def check_review_status(review_status_path: Path) -> list[ReadabilityViolation]:
    """Verify that `review-status.json` exists and approves all 6 supported locales."""
    violations: list[ReadabilityViolation] = []
    if not review_status_path.exists():
        return [
            ReadabilityViolation(
                locale="all",
                source=str(review_status_path),
                item_id="review_status",
                rule="review_status",
                detail="Missing review-status.json file",
            )
        ]
    raw = json.loads(review_status_path.read_text(encoding="utf-8"))
    locales_map = raw.get("locales", {})
    for loc in SUPPORTED_LOCALES:
        entry = locales_map.get(loc)
        if not isinstance(entry, dict) or entry.get("status") != "approved":
            violations.append(
                ReadabilityViolation(
                    locale=loc,
                    source=str(review_status_path),
                    item_id=loc,
                    rule="review_status",
                    detail=f"Locale {loc!r} is not marked 'approved' in review-status.json",
                )
            )
        elif not str(entry.get("reviewer", "")).strip():
            violations.append(
                ReadabilityViolation(
                    locale=loc,
                    source=str(review_status_path),
                    item_id=loc,
                    rule="review_status",
                    detail=f"Locale {loc!r} is missing reviewer attribution",
                )
            )
    return violations


def lint_all_multilingual_content(
    review_status_path: Path | None = None,
) -> list[ReadabilityViolation]:
    """Validate all 6 locales across BCT actions, recovery, coach templates, and review status."""
    violations: list[ReadabilityViolation] = []
    library = load_library()

    for action in library.actions:
        for loc in SUPPORTED_LOCALES:
            loc_text = action.text_for_locale(loc)
            violations.extend(
                lint_readability_text(
                    loc_text.instruction,
                    locale=loc,
                    source="actions",
                    item_id=f"{action.id}.instruction",
                    max_words=MAX_ACTION_INSTRUCTION_WORDS,
                )
            )
            why_loc = action.why_card.for_locale(loc)
            violations.extend(
                lint_readability_text(
                    why_loc.idea,
                    locale=loc,
                    source="actions.why_card",
                    item_id=f"{action.id}.why_card.idea",
                    max_words=MAX_COACH_TEMPLATE_WORDS,
                )
            )

    for loc in SUPPORTED_LOCALES:
        rec = load_recovery_messages(loc)
        for code in USER_SELECTABLE_BARRIERS:
            b_item = rec.barriers.get(code)
            if b_item is None:
                violations.append(
                    ReadabilityViolation(
                        locale=loc,
                        source="recovery",
                        item_id=code.value,
                        rule="max_words",
                        detail=f"Missing barrier {code.value} in locale {loc}",
                    )
                )
            else:
                violations.extend(
                    lint_readability_text(
                        b_item.info_note,
                        locale=loc,
                        source="recovery",
                        item_id=f"barrier.{code.value}",
                        max_words=MAX_COACH_TEMPLATE_WORDS,
                    )
                )

        coach = load_coach_messages(loc)
        for tid in REQUIRED_COACH_TEMPLATE_IDS:
            entry = coach.templates.get(tid)
            if entry is None:
                violations.append(
                    ReadabilityViolation(
                        locale=loc,
                        source="coach",
                        item_id=tid,
                        rule="max_words",
                        detail=f"Missing coach template {tid!r} in locale {loc}",
                    )
                )
            else:
                violations.extend(
                    lint_readability_text(
                        entry.body,
                        locale=loc,
                        source="coach",
                        item_id=tid,
                        max_words=MAX_COACH_TEMPLATE_WORDS,
                    )
                )

    if review_status_path is not None:
        violations.extend(check_review_status(review_status_path))

    return violations
