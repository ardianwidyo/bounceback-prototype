"""Pure, deterministic progress and check-in transition rules (F03, Principles II, III, VII)."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from datetime import date
from typing import Literal

CheckInStatus = Literal["done", "partial", "skipped"]
ACTIVE_STATUSES: frozenset[CheckInStatus] = frozenset({"done", "partial"})
_VALID_STATUSES: frozenset[str] = frozenset({"done", "partial", "skipped"})

_STATUS_RANK: dict[CheckInStatus, int] = {
    "skipped": 0,
    "partial": 1,
    "done": 2,
}

_CLINICAL_RED_FLAG_PHRASES: tuple[str, ...] = (
    # English acute physical & crisis phrases
    "chest pain",
    "shortness of breath",
    "cannot breathe",
    "can't breathe",
    "could not breathe",
    "fainting",
    "passed out",
    "self-harm",
    "self harm",
    "hurt myself",
    "suicidal",
    "suicide",
    "end my life",
    "kill myself",
    # Arabic acute physical & crisis phrases
    "ألم في الصدر",
    "الم في الصدر",
    "ضيق تنفس",
    "لا أستطيع التنفس",
    "إغماء",
    "اغماء",
    "إيذاء النفس",
    "ايذاء النفس",
    "أؤذي نفسي",
    "الانتحار",
    "انتحار",
    "أنهي حياتي",
)


@dataclass(frozen=True, slots=True)
class CheckInEntry:
    local_date: date
    status: CheckInStatus
    slot_id: str = "slot-1"
    effort: int | None = None

    def __post_init__(self) -> None:
        if self.status not in _VALID_STATUSES:
            raise ValueError(f"status must be one of {sorted(_VALID_STATUSES)}")
        if not self.slot_id or not self.slot_id.strip():
            raise ValueError("slot_id must be a non-empty string")
        if self.effort is not None and (
            isinstance(self.effort, bool)
            or not isinstance(self.effort, int)
            or not (1 <= self.effort <= 5)
        ):
            raise ValueError("effort must be an integer between 1 and 5 or None")


@dataclass(frozen=True, slots=True)
class ProgressSummary:
    active_days: int
    today_active: bool
    last_active_date: date | None
    total_checkins: int


def active_days(checkins: Sequence[CheckInEntry]) -> int:
    """Count distinct calendar days with at least one `done` or `partial` check-in.

    Guaranteed properties:
    - Non-negative integer (>= 0)
    - Monotonically non-decreasing as new check-in entries are appended
    - Caps at +1 per calendar day regardless of how many actions are checked in on that day
    - Unaffected by `skipped` entries or multi-day gaps
    """
    active_dates = {entry.local_date for entry in checkins if entry.status in ACTIVE_STATUSES}
    return len(active_dates)


def compute_progress(
    checkins: Sequence[CheckInEntry],
    today: date,
) -> ProgressSummary:
    """Compute cumulative active-day progress summary without any streak or loss metrics."""
    active_dates = {entry.local_date for entry in checkins if entry.status in ACTIVE_STATUSES}
    last_active = max(active_dates) if active_dates else None
    return ProgressSummary(
        active_days=len(active_dates),
        today_active=today in active_dates,
        last_active_date=last_active,
        total_checkins=len(checkins),
    )


def can_transition_checkin_status(
    current: CheckInStatus | None,
    target: CheckInStatus,
) -> bool:
    """Return True if transitioning a same-day slot from `current` to `target` is valid
    and preserves active-day monotonicity (`skipped -> partial -> done`).
    """
    if target not in _STATUS_RANK:
        return False
    if current is None:
        return True
    if current not in _STATUS_RANK:
        return False
    return _STATUS_RANK[target] >= _STATUS_RANK[current]


def has_clinical_red_flag(note: str | None) -> bool:
    """Deterministic bilingual (EN/AR) check for acute clinical red flags in a short note."""
    if not note:
        return False
    normalized = " ".join(note.lower().split())
    if not normalized:
        return False
    return any(phrase in normalized for phrase in _CLINICAL_RED_FLAG_PHRASES)
