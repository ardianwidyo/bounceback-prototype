"""Seeded, counter-based randomness (Constitution VII: randomness is injected, never global).

Every sampling call gets its own ``random.Random`` derived from ``(seed, rng_counter)``. The
counter goes up in the *returned* state, so replaying the same commands gives the same draws.
"""

from __future__ import annotations

import hashlib
import random
from collections.abc import Mapping
from typing import Any

_SEED_BYTES = 8


def derive_seed(seed: int, counter: int) -> int:
    """Deterministic 64-bit seed for the ``counter``-th draw of a session seeded with ``seed``."""
    digest = hashlib.sha256(f"{seed}:{counter}".encode()).digest()
    return int.from_bytes(digest[:_SEED_BYTES], "big")


def next_rng(state: Mapping[str, Any]) -> tuple[random.Random, dict[str, Any]]:
    """Return a seeded RNG for the next draw and a copy of ``state`` with the counter advanced."""
    counter = int(state["rng_counter"])
    rng = random.Random(derive_seed(int(state["seed"]), counter))
    return rng, {**state, "rng_counter": counter + 1}


def next_seed(state: Mapping[str, Any]) -> tuple[int, dict[str, Any]]:
    """Like ``next_rng`` but returns the integer seed, for engine functions that take a seed."""
    counter = int(state["rng_counter"])
    return derive_seed(int(state["seed"]), counter), {**state, "rng_counter": counter + 1}
