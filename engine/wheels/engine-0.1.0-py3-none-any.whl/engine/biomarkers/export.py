"""CSV rows for the participant's own biomarker export (F21 FR-018).

The participant's export contains their own values; audit events never do.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, Protocol

CSV_CATEGORY = "clinical_biomarkers"


class RowWriter(Protocol):
    def writerow(self, row: list[str], /) -> Any: ...


def write_biomarker_csv_rows(writer: RowWriter, export_payload: Mapping[str, Any]) -> None:
    section = export_payload.get("clinicalBiomarkers") or {}
    for result in section.get("results") or []:
        writer.writerow(
            [
                CSV_CATEGORY,
                f"{result.get('windowType')}:{result.get('biomarker')}",
                str(result.get("retrievedAt", "")),
                str(result.get("biomarker", "")),
                f"{result.get('value')} {result.get('unit')} on {result.get('resultDate')}",
                json.dumps(result, ensure_ascii=False, sort_keys=True, default=str),
            ]
        )
