"""SandboxState: construction, validation and serialisation (spec 023 data-model.md).

The state is a plain JSON-compatible dict so the UI can persist it and the worker can pass it
across the Python/JS boundary. Functions here never mutate their inputs.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import date
from typing import Any

SCHEMA_VERSION = 1

State = dict[str, Any]

ROOT_KEYS: tuple[str, ...] = (
    "schema_version",
    "synthetic",
    "seed",
    "rng_counter",
    "start_date",
    "current_date",
    "locale",
    "profile",
    "consent",
    "context_days",
    "plans",
    "checkins",
    "progress",
    "risk_results",
    "lapse_episodes",
    "pending_proposal",
    "coach_messages",
    "decision_trail",
    "walkthrough",
)

ERROR_CODES: frozenset[str] = frozenset(
    {
        "invalid_command",
        "invalid_state_version",
        "unknown_slot",
        "date_backwards",
        "no_area_selected",
        "proposal_not_pending",
        "days_out_of_range",
        "engine_not_ready",
        "confirm_required",
    }
)

AREAS: tuple[str, ...] = ("movement", "nutrition", "sleep")
MAX_AREAS = 3
LOCALES: tuple[str, ...] = ("en", "ar")

# (source, purpose) pairs the user can consent to (data-model.md § ConsentSettings).
CONSENT_PAIRS: tuple[str, ...] = (
    "checkins:own_progress",
    "checkins:risk_detection",
    "activity_sensor:risk_detection",
    "work_pattern:risk_detection",
    "work_pattern:schedule_adaptation",
    "ramadan_setting:schedule_adaptation",
)
# The core function: consented at setup, withdrawn only by deleting all data.
NON_TOGGLEABLE_CONSENT: frozenset[str] = frozenset({"checkins:own_progress"})


class SandboxError(Exception):
    """A rejected command or state. ``code`` is one of the contract's error codes."""

    def __init__(self, code: str) -> None:
        if code not in ERROR_CODES:
            raise ValueError(f"unknown sandbox error code: {code}")
        super().__init__(code)
        self.code = code
        self.message_key = f"errors.{code}"


def default_consent(on: date) -> dict[str, dict[str, Any]]:
    """Every (source, purpose) pair granted as of ``on``."""
    stamp = on.isoformat()
    return {pair: {"granted": True, "changed_on": stamp} for pair in CONSENT_PAIRS}


def _validate_profile(profile: Mapping[str, Any]) -> None:
    areas = profile.get("areas")
    if (
        not isinstance(areas, list)
        or not 1 <= len(areas) <= MAX_AREAS
        or len(set(areas)) != len(areas)
    ):
        raise SandboxError("no_area_selected")
    if any(area not in AREAS for area in areas):
        raise SandboxError("invalid_command")


def new_state(
    *,
    profile: Mapping[str, Any],
    consent: Mapping[str, Mapping[str, Any]],
    seed: int,
    start_date: date,
    locale: str,
) -> State:
    """Build a fresh state. Raises SandboxError for an invalid profile or locale."""
    _validate_profile(profile)
    if locale not in LOCALES:
        raise SandboxError("invalid_command")
    start = start_date.isoformat()
    return {
        "schema_version": SCHEMA_VERSION,
        "synthetic": True,
        "seed": seed,
        "rng_counter": 0,
        "start_date": start,
        "current_date": start,
        "locale": locale,
        "profile": {key: _copy_json(value) for key, value in profile.items()},
        "consent": {pair: dict(entry) for pair, entry in consent.items()},
        "context_days": [],
        "plans": [],
        "checkins": [],
        "progress": {},
        "risk_results": [],
        "lapse_episodes": [],
        "pending_proposal": None,
        "coach_messages": [],
        "decision_trail": [],
        "walkthrough": {"step": 0, "active": False},
    }


def validate_state(state: object) -> State:
    """Return ``state`` if it is a usable SandboxState; raise SandboxError otherwise.

    Stored state is untrusted input (it comes from the browser), so shape and version are checked.
    """
    if not isinstance(state, dict):
        raise SandboxError("invalid_state_version")
    if state.get("schema_version") != SCHEMA_VERSION:
        raise SandboxError("invalid_state_version")
    if any(key not in state for key in ROOT_KEYS):
        raise SandboxError("invalid_state_version")
    if not _has_expected_types(state):
        raise SandboxError("invalid_state_version")
    return state


def _is_int(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _is_date(value: object) -> bool:
    if not isinstance(value, str):
        return False
    try:
        date.fromisoformat(value)
    except ValueError:
        return False
    return True


# Root fields that must be a mapping or a list (a state with the right keys but the wrong kind of
# value would pass every key check and then fail somewhere deep inside a handler).
_MAPPING_KEYS = ("profile", "consent", "progress", "walkthrough")
_LIST_KEYS = (
    "plans",
    "checkins",
    "risk_results",
    "lapse_episodes",
    "coach_messages",
    "decision_trail",
)


def _has_expected_types(state: Mapping[str, Any]) -> bool:
    walkthrough = state["walkthrough"]
    return (
        _is_int(state["seed"])
        and _is_int(state["rng_counter"])
        and _is_date(state["start_date"])
        and _is_date(state["current_date"])
        and state["locale"] in LOCALES
        and all(isinstance(state[key], dict) for key in _MAPPING_KEYS)
        and all(isinstance(state[key], list) for key in _LIST_KEYS)
        and isinstance(state["context_days"], list)
        and (state["pending_proposal"] is None or isinstance(state["pending_proposal"], dict))
        and _is_int(walkthrough.get("step"))
        and isinstance(walkthrough.get("active"), bool)
    )


def to_json(state: Mapping[str, Any]) -> str:
    """Canonical JSON: sorted keys, no whitespace, so equal states give byte-identical output."""
    return json.dumps(state, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _copy_json(value: Any) -> Any:
    """Deep copy of JSON-compatible data (dict, list, scalars)."""
    if isinstance(value, Mapping):
        return {key: _copy_json(item) for key, item in value.items()}
    if isinstance(value, list | tuple):
        return [_copy_json(item) for item in value]
    return value


_ENGINE_WORK_PATTERN = {"regular_day": "day", "rotating": "rotating", "nights": "nights"}


def to_engine_work_pattern(work_pattern: str) -> str:
    """The engine's planner and recovery modules say ``day`` where the app says ``regular_day``."""
    try:
        return _ENGINE_WORK_PATTERN[work_pattern]
    except KeyError:
        raise SandboxError("invalid_command") from None
