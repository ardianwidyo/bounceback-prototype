"""Measurement windows and closest-result selection (F21 FR-005, FR-006; research R4)."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import date, timedelta
from enum import StrEnum
from typing import TYPE_CHECKING, Final

if TYPE_CHECKING:
    from engine.biomarkers.validation import BiomarkerResult


class WindowType(StrEnum):
    BASELINE = "baseline"
    MONTH_6 = "month_6"
    MONTH_12 = "month_12"


class RetrievalStatus(StrEnum):
    SCHEDULED = "scheduled"
    PENDING = "pending"
    RETRIEVED = "retrieved"
    NOT_RETRIEVED = "not_retrieved"


FOLLOW_UP_WINDOWS: Final = (WindowType.MONTH_6, WindowType.MONTH_12)

# (window, target day, days before target, days after target)
_WINDOW_RULES: Final = (
    (WindowType.BASELINE, 0, 90, 30),
    (WindowType.MONTH_6, 182, 45, 45),
    (WindowType.MONTH_12, 365, 60, 60),
)


@dataclass(frozen=True, slots=True)
class MeasurementWindow:
    window_type: WindowType
    target_date: date
    opens_on: date
    closes_on: date

    def contains(self, day: date) -> bool:
        return self.opens_on <= day <= self.closes_on


def compute_windows(enrolled_on: date) -> tuple[MeasurementWindow, ...]:
    """The three windows anchored on the enrolment (onboarding completion) date."""
    return tuple(
        MeasurementWindow(
            window_type=window_type,
            target_date=enrolled_on + timedelta(days=target),
            opens_on=enrolled_on + timedelta(days=target - before),
            closes_on=enrolled_on + timedelta(days=target + after),
        )
        for window_type, target, before, after in _WINDOW_RULES
    )


def _selection_key(result: BiomarkerResult, target: date) -> tuple[int, int, str]:
    # Smallest distance first; on a tie the later date wins, then the lexically smaller id.
    distance = abs((result.result_date - target).days)
    return (distance, -result.result_date.toordinal(), result.source_resource_id)


def select_closest(
    results: Iterable[BiomarkerResult], window: MeasurementWindow
) -> BiomarkerResult | None:
    """The in-window result dated closest to the window's target date, or None."""
    in_window = [result for result in results if window.contains(result.result_date)]
    if not in_window:
        return None
    return min(in_window, key=lambda result: _selection_key(result, window.target_date))
