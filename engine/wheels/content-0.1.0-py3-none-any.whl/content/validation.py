"""Generic JSON Schema validation that reports every issue with the offending item's ID."""

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ValidationIssue:
    action_id: str | None
    path: str
    rule: str
    message: str


class ContentValidationError(Exception):
    def __init__(self, issues: Iterable[ValidationIssue]) -> None:
        self.issues = tuple(issues)
        super().__init__("\n".join(issue.message for issue in self.issues))


def item_id(data: object, path: Iterable[object]) -> str | None:
    """Return the ``id`` of the list item a path points into (e.g. ``actions/3/...``)."""
    parts = list(path)
    if len(parts) < 2 or not isinstance(data, Mapping):
        return None
    collection, index = parts[0], parts[1]
    items = data.get(collection)
    if not isinstance(items, list) or not isinstance(index, int) or index >= len(items):
        return None
    item = items[index]
    identifier = item.get("id") if isinstance(item, Mapping) else None
    return identifier if isinstance(identifier, str) else None


def describe(owner: str | None, path: str, detail: str) -> str:
    return f"{owner or 'library'} at {path or '<root>'}: {detail}"


def validate_document(schema: Mapping[str, Any], data: object) -> list[ValidationIssue]:
    # Imported lazily: jsonschema pulls in a native extension, and the browser (Pyodide)
    # build loads a pre-validated library, so importing `content` must not require it.
    from jsonschema import Draft202012Validator

    validator = Draft202012Validator(schema)
    issues = []
    for error in sorted(validator.iter_errors(data), key=lambda e: [str(p) for p in e.path]):
        path = "/".join(str(part) for part in error.absolute_path)
        owner = item_id(data, error.absolute_path)
        issues.append(
            ValidationIssue(
                action_id=owner,
                path=path,
                rule=str(error.validator),
                message=describe(owner, path, error.message),
            )
        )
    return issues
