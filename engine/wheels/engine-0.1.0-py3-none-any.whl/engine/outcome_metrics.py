"""Pure sustained-outcome and subgroup equity metrics calculator (F09 / 011-simulator-dashboard).

Enforces:
- Constitution Principle IV: k-anonymity cell suppression
  (`n < 20` -> `suppressed_k_anonymity=True`).
- FR-005 / FR-006: Subgroup equity gap flagging (`gap = subgroup_rate - overall_cohort_rate < -10.0`
  percentage points on Week 26 persistence or 14-day lapse recovery rate).
- FR-007: Mandatory `"Synthetic data — illustrative"` labelling and zero vanity metrics.
"""

from __future__ import annotations

import statistics
from typing import Any, Literal

from engine.simulator import (
    AGE_BANDS,
    DISABILITIES,
    LANGUAGES,
    NATIONALITY_GROUPS,
    SEXES,
    WORK_PATTERNS,
    CohortSimulationResult,
    SyntheticUserPersona,
    UserArmTrajectory,
)

ILLUSTRATIVE_LABEL_EN = "Synthetic data — illustrative"
ILLUSTRATIVE_LABEL_AR = "بيانات اصطناعية — توضيحية فقط"
K_ANONYMITY_THRESHOLD = 20
EQUITY_GAP_THRESHOLD_POINTS = -10.0

SubgroupDimension = Literal[
    "language",
    "nationality_group",
    "sex",
    "age_band",
    "work_pattern",
    "disability",
]

DIMENSION_SUBGROUPS: dict[SubgroupDimension, tuple[str, ...]] = {
    "language": LANGUAGES,
    "nationality_group": NATIONALITY_GROUPS,
    "sex": SEXES,
    "age_band": AGE_BANDS,
    "work_pattern": WORK_PATTERNS,
    "disability": DISABILITIES,
}


def _round1(val: float) -> float:
    return round(val, 1)


def _compute_arm_summary(
    arm: Literal["adaptive", "static"],
    trajectories: tuple[UserArmTrajectory, ...],
) -> dict[str, Any]:
    n = len(trajectories)
    if n == 0:
        return {
            "arm": arm,
            "n_users": 0,
            "persistence_week_12": 0.0,
            "persistence_week_26": 0.0,
            "lapse_recovery_rate_14d": 0.0,
            "median_recovery_days": 0.0,
            "mean_active_days": 0.0,
            "median_active_days": 0.0,
            "retention_rate": 0.0,
            "notification_opt_out_rate": 0.0,
        }

    w12_count = sum(1 for t in trajectories if t.retained_at_w12)
    w26_count = sum(1 for t in trajectories if t.retained_at_w26)
    opt_out_count = sum(1 for t in trajectories if t.notification_opted_out)
    active_days_list = [t.cumulative_active_days for t in trajectories]

    all_episodes = [ep for t in trajectories for ep in t.lapse_episodes]
    total_episodes = len(all_episodes)
    rec_14d_count = sum(1 for ep in all_episodes if ep.recovered_within_14d)
    rec_days_list = [
        float(ep.recovery_days)
        for ep in all_episodes
        if ep.recovered and ep.recovery_days is not None
    ]

    persistence_w12 = _round1((w12_count / n) * 100.0)
    persistence_w26 = _round1((w26_count / n) * 100.0)
    recovery_14d = _round1((rec_14d_count / total_episodes) * 100.0) if total_episodes > 0 else 0.0
    median_rec_days = _round1(float(statistics.median(rec_days_list))) if rec_days_list else 0.0
    mean_active = _round1(float(statistics.fmean(active_days_list)))
    median_active = _round1(float(statistics.median(active_days_list)))
    retention = persistence_w26
    opt_out = _round1((opt_out_count / n) * 100.0)

    return {
        "arm": arm,
        "n_users": n,
        "persistence_week_12": persistence_w12,
        "persistence_week_26": persistence_w26,
        "lapse_recovery_rate_14d": recovery_14d,
        "median_recovery_days": median_rec_days,
        "mean_active_days": mean_active,
        "median_active_days": median_active,
        "retention_rate": retention,
        "notification_opt_out_rate": opt_out,
    }


def _compute_subgroups_for_trajectories(
    cohort: tuple[SyntheticUserPersona, ...],
    trajectories: tuple[UserArmTrajectory, ...],
    overall_summary: dict[str, Any],
    *,
    k_threshold: int = K_ANONYMITY_THRESHOLD,
) -> list[dict[str, Any]]:
    traj_by_user = {t.user_id: t for t in trajectories}
    overall_w26 = float(overall_summary["persistence_week_26"])
    overall_rec = float(overall_summary["lapse_recovery_rate_14d"])

    rows: list[dict[str, Any]] = []
    for dimension, subgroup_values in DIMENSION_SUBGROUPS.items():
        for subgroup in subgroup_values:
            matching_trajs = tuple(
                traj_by_user[p.user_id]
                for p in cohort
                if getattr(p, dimension) == subgroup and p.user_id in traj_by_user
            )
            n = len(matching_trajs)
            if n < k_threshold:
                rows.append(
                    {
                        "dimension": dimension,
                        "subgroup": subgroup,
                        "n": n,
                        "suppressed_k_anonymity": True,
                        "persistence_week_12": None,
                        "persistence_week_26": None,
                        "lapse_recovery_rate_14d": None,
                        "median_recovery_days": None,
                        "mean_active_days": None,
                        "retention_rate": None,
                        "notification_opt_out_rate": None,
                        "persistence_gap_points": None,
                        "recovery_gap_points": None,
                        "equity_gap_flagged": False,
                    }
                )
                continue

            sub_summary = _compute_arm_summary("adaptive", matching_trajs)
            sub_w26 = float(sub_summary["persistence_week_26"])
            sub_rec = float(sub_summary["lapse_recovery_rate_14d"])
            p_gap = _round1(sub_w26 - overall_w26)
            r_gap = _round1(sub_rec - overall_rec)
            flagged = (p_gap < EQUITY_GAP_THRESHOLD_POINTS) or (r_gap < EQUITY_GAP_THRESHOLD_POINTS)

            rows.append(
                {
                    "dimension": dimension,
                    "subgroup": subgroup,
                    "n": n,
                    "suppressed_k_anonymity": False,
                    "persistence_week_12": sub_summary["persistence_week_12"],
                    "persistence_week_26": sub_w26,
                    "lapse_recovery_rate_14d": sub_rec,
                    "median_recovery_days": sub_summary["median_recovery_days"],
                    "mean_active_days": sub_summary["mean_active_days"],
                    "retention_rate": sub_summary["retention_rate"],
                    "notification_opt_out_rate": sub_summary["notification_opt_out_rate"],
                    "persistence_gap_points": p_gap,
                    "recovery_gap_points": r_gap,
                    "equity_gap_flagged": flagged,
                }
            )
    return rows


def compute_outcome_metrics(
    sim: CohortSimulationResult,
    *,
    k_threshold: int = K_ANONYMITY_THRESHOLD,
) -> dict[str, Any]:
    """Compute complete sustained-outcome and subgroup equity metrics from a cohort simulation."""
    n = sim.n_users
    adaptive_summary = _compute_arm_summary("adaptive", sim.adaptive_trajectories)
    static_summary = _compute_arm_summary("static", sim.static_trajectories)

    weekly_persistence: list[dict[str, Any]] = []
    for w_idx in range(sim.horizon_weeks):
        a_active = sum(
            1
            for t in sim.adaptive_trajectories
            if w_idx < len(t.weekly_active) and t.weekly_active[w_idx]
        )
        s_active = sum(
            1
            for t in sim.static_trajectories
            if w_idx < len(t.weekly_active) and t.weekly_active[w_idx]
        )
        weekly_persistence.append(
            {
                "week": w_idx + 1,
                "adaptive_rate": _round1((a_active / n) * 100.0) if n > 0 else 0.0,
                "static_rate": _round1((s_active / n) * 100.0) if n > 0 else 0.0,
            }
        )

    subgroups_adaptive = _compute_subgroups_for_trajectories(
        sim.cohort,
        sim.adaptive_trajectories,
        adaptive_summary,
        k_threshold=k_threshold,
    )
    subgroups_static = _compute_subgroups_for_trajectories(
        sim.cohort,
        sim.static_trajectories,
        static_summary,
        k_threshold=k_threshold,
    )

    return {
        "synthetic": True,
        "illustrative_label_en": ILLUSTRATIVE_LABEL_EN,
        "illustrative_label_ar": ILLUSTRATIVE_LABEL_AR,
        "seed": sim.seed,
        "n_users": sim.n_users,
        "horizon_weeks": sim.horizon_weeks,
        "selected_arm": "all",
        "selected_horizon_week": 26 if sim.horizon_weeks >= 26 else 12,
        "selected_group_by": None,
        "adaptive": adaptive_summary,
        "static": static_summary,
        "weekly_persistence": weekly_persistence,
        "subgroups": subgroups_adaptive,
        "_subgroups_static": subgroups_static,
    }


def filter_outcome_metrics(
    base_metrics: dict[str, Any],
    *,
    arm: Literal["all", "adaptive", "static"] = "all",
    horizon_week: Literal[12, 26] = 26,
    group_by: SubgroupDimension | None = None,
) -> dict[str, Any]:
    """Filter a computed or snapshot metrics dict by arm, horizon_week, and subgroup dimension."""
    weekly = [
        dict(pt)
        for pt in base_metrics["weekly_persistence"]
        if int(pt["week"]) <= int(horizon_week)
    ]
    raw_subgroups = (
        base_metrics.get("_subgroups_static", base_metrics["subgroups"])
        if arm == "static"
        else base_metrics["subgroups"]
    )
    subgroups = [
        dict(row) for row in raw_subgroups if group_by is None or row["dimension"] == group_by
    ]

    return {
        "synthetic": True,
        "illustrative_label_en": base_metrics["illustrative_label_en"],
        "illustrative_label_ar": base_metrics["illustrative_label_ar"],
        "seed": int(base_metrics["seed"]),
        "n_users": int(base_metrics["n_users"]),
        "horizon_weeks": int(base_metrics["horizon_weeks"]),
        "selected_arm": arm,
        "selected_horizon_week": horizon_week,
        "selected_group_by": group_by,
        "adaptive": dict(base_metrics["adaptive"]),
        "static": dict(base_metrics["static"]),
        "weekly_persistence": weekly,
        "subgroups": subgroups,
    }


def _compute_user_mvpa_and_autonomy(
    persona: SyntheticUserPersona,
    traj: UserArmTrajectory,
    horizon_weeks: int,
) -> tuple[float, float]:
    """Deterministically derive weekly MVPA minutes and HCCQ-short autonomy support (1..7)."""
    active_weeks = sum(1 for w in traj.weekly_active if w)
    active_ratio = active_weeks / float(max(1, horizon_weeks))
    days_per_week = traj.cumulative_active_days / float(max(1, horizon_weeks))

    # Each active day contributes ~28 min MVPA in adaptive arm vs ~23 min in static arm
    minutes_per_active_day = 28.5 if traj.arm == "adaptive" else 23.0
    if persona.work_pattern in ("night", "rotating_shifts") and traj.arm == "static":
        minutes_per_active_day -= 2.5
    weekly_mvpa = round(max(10.0, days_per_week * minutes_per_active_day), 1)

    # HCCQ-short perceived autonomy support score (1.0 .. 7.0)
    base_autonomy = 5.85 if traj.arm == "adaptive" else 4.65
    autonomy = (
        base_autonomy
        + 0.55 * active_ratio
        - (0.35 if traj.notification_opted_out else 0.0)
        - (0.12 if persona.disability == "self_identified" and traj.arm == "static" else 0.0)
    )
    autonomy_clamped = round(max(1.0, min(7.0, autonomy)), 2)
    return weekly_mvpa, autonomy_clamped


def _compute_pilot_arm_kpi_summary(
    arm: Literal["adaptive", "static"],
    cohort: tuple[SyntheticUserPersona, ...],
    trajectories: tuple[UserArmTrajectory, ...],
    horizon_weeks: int,
) -> dict[str, Any]:
    """Extend core F09 `_compute_arm_summary` with weekly MVPA and HCCQ-short autonomy scores."""
    core = _compute_arm_summary(arm, trajectories)
    if not trajectories:
        return {
            "arm": arm,
            "n_users": 0,
            "persistence_week12": 0.0,
            "persistence_week26": 0.0,
            "lapse_recovery_rate14d": 0.0,
            "median_recovery_days": 0.0,
            "weekly_mvpa_minutes_mean": 0.0,
            "weekly_mvpa_minutes_median": 0.0,
            "retention_week26": 0.0,
            "notification_opt_out_rate": 0.0,
            "mean_autonomy_support_score": 0.0,
            "mean_active_days": 0.0,
        }

    persona_by_id = {p.user_id: p for p in cohort}
    mvpa_list: list[float] = []
    autonomy_list: list[float] = []
    for t in trajectories:
        persona = persona_by_id.get(t.user_id)
        if persona is None:
            continue
        mvpa, autonomy = _compute_user_mvpa_and_autonomy(persona, t, horizon_weeks)
        mvpa_list.append(mvpa)
        autonomy_list.append(autonomy)

    mvpa_mean = _round1(float(statistics.fmean(mvpa_list))) if mvpa_list else 0.0
    mvpa_median = _round1(float(statistics.median(mvpa_list))) if mvpa_list else 0.0
    autonomy_mean = round(float(statistics.fmean(autonomy_list)), 2) if autonomy_list else 0.0

    return {
        "arm": arm,
        "n_users": int(core["n_users"]),
        "persistence_week12": float(core["persistence_week_12"]),
        "persistence_week26": float(core["persistence_week_26"]),
        "lapse_recovery_rate14d": float(core["lapse_recovery_rate_14d"]),
        "median_recovery_days": float(core["median_recovery_days"]),
        "weekly_mvpa_minutes_mean": mvpa_mean,
        "weekly_mvpa_minutes_median": mvpa_median,
        "retention_week26": float(core["retention_rate"]),
        "notification_opt_out_rate": float(core["notification_opt_out_rate"]),
        "mean_autonomy_support_score": autonomy_mean,
        "mean_active_days": float(core["mean_active_days"]),
    }


def compute_pilot_sustained_outcomes(
    sim: CohortSimulationResult,
    *,
    k_threshold: int = K_ANONYMITY_THRESHOLD,
) -> dict[str, Any]:
    """Compute F16 sustained-outcome KPIs and subgroup equity gaps sharing F09's core evaluator."""
    adaptive_kpi = _compute_pilot_arm_kpi_summary(
        "adaptive",
        sim.cohort,
        sim.adaptive_trajectories,
        sim.horizon_weeks,
    )
    static_kpi = _compute_pilot_arm_kpi_summary(
        "static",
        sim.cohort,
        sim.static_trajectories,
        sim.horizon_weeks,
    )

    traj_by_user = {t.user_id: t for t in sim.adaptive_trajectories}
    overall_w26 = float(adaptive_kpi["persistence_week26"])
    overall_rec = float(adaptive_kpi["lapse_recovery_rate14d"])
    overall_aut = float(adaptive_kpi["mean_autonomy_support_score"])

    subgroups: list[dict[str, Any]] = []
    for dimension, subgroup_values in DIMENSION_SUBGROUPS.items():
        for subgroup in subgroup_values:
            matching_personas = tuple(
                p
                for p in sim.cohort
                if getattr(p, dimension) == subgroup and p.user_id in traj_by_user
            )
            matching_trajs = tuple(traj_by_user[p.user_id] for p in matching_personas)
            n = len(matching_trajs)
            if n < k_threshold:
                subgroups.append(
                    {
                        "dimension": dimension,
                        "subgroup": subgroup,
                        "n": n,
                        "suppressed_k_anonymity": True,
                        "persistence_week12": None,
                        "persistence_week26": None,
                        "lapse_recovery_rate14d": None,
                        "weekly_mvpa_minutes_mean": None,
                        "retention_week26": None,
                        "notification_opt_out_rate": None,
                        "mean_autonomy_support_score": None,
                        "persistence_gap_points": None,
                        "recovery_gap_points": None,
                        "autonomy_gap_points": None,
                        "equity_gap_flagged": False,
                    }
                )
                continue

            sub_kpi = _compute_pilot_arm_kpi_summary(
                "adaptive",
                matching_personas,
                matching_trajs,
                sim.horizon_weeks,
            )
            sub_w26 = float(sub_kpi["persistence_week26"])
            sub_rec = float(sub_kpi["lapse_recovery_rate14d"])
            sub_aut = float(sub_kpi["mean_autonomy_support_score"])
            p_gap = _round1(sub_w26 - overall_w26)
            r_gap = _round1(sub_rec - overall_rec)
            a_gap = round(sub_aut - overall_aut, 2)
            flagged = (
                (p_gap < EQUITY_GAP_THRESHOLD_POINTS)
                or (r_gap < EQUITY_GAP_THRESHOLD_POINTS)
                or (a_gap < -0.5)
            )
            subgroups.append(
                {
                    "dimension": dimension,
                    "subgroup": subgroup,
                    "n": n,
                    "suppressed_k_anonymity": False,
                    "persistence_week12": sub_kpi["persistence_week12"],
                    "persistence_week26": sub_w26,
                    "lapse_recovery_rate14d": sub_rec,
                    "weekly_mvpa_minutes_mean": sub_kpi["weekly_mvpa_minutes_mean"],
                    "retention_week26": sub_kpi["retention_week26"],
                    "notification_opt_out_rate": sub_kpi["notification_opt_out_rate"],
                    "mean_autonomy_support_score": sub_aut,
                    "persistence_gap_points": p_gap,
                    "recovery_gap_points": r_gap,
                    "autonomy_gap_points": a_gap,
                    "equity_gap_flagged": flagged,
                }
            )

    return {
        "adaptive_outcomes": adaptive_kpi,
        "static_outcomes": static_kpi,
        "subgroups": subgroups,
    }
