"""Deterministic blame-free copy linter (F06, Principle III & SC-001)."""

from __future__ import annotations

import json
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

FORBIDDEN_EN_TERMS: tuple[str, ...] = (
    "fail",
    "failed",
    "failure",
    "lost",
    "lose",
    "broke",
    "broken",
    "behind",
    "should have",
    "ought to",
    "streak",
    "reset",
    "missed",
    "skipped",
    "lazy",
    "relapse",
    "penalty",
    "punish",
    "guilt",
    "shame",
    "disappoint",
    "warning",
    "danger",
    "alert",
)

FORBIDDEN_AR_TERMS: tuple[str, ...] = (
    "فشل",
    "فشلت",
    "إخفاق",
    "خسرت",
    "خسارة",
    "فقدت",
    "كسرت",
    "مكسور",
    "متأخر",
    "كان يجب",
    "ينبغي أن",
    "سلسلة",
    "إعادة ضبط",
    "صفر",
    "فاتك",
    "تجاهلت",
    "كسول",
    "انتكاسة",
    "عقوبة",
    "ذنب",
    "لوم",
    "خجل",
    "خيبة",
    "تحذير",
    "خطر",
)

FORBIDDEN_MULTILINGUAL_TERMS: tuple[str, ...] = (
    # Urdu (ur)
    "ناکامی",
    "ناکام",
    "سزا",
    "شرمندگی",
    "گناہ",
    "کاہل",
    "سلسلہ ٹوٹ",
    # Hindi (hi)
    "असफल",
    "असफलता",
    "दंड",
    "शर्म",
    "आलसी",
    "स्ट्रीक टूट",
    # Tagalog (tl)
    "bigo",
    "nabigo",
    "parusa",
    "tamad",
    "naputol ang streak",
    # Malayalam (ml)
    "പരാജയം",
    "പരാജയപ്പെട്ടു",
    "ശിക്ഷ",
    "മടി",
)

FORBIDDEN_EN_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = tuple(
    (term, re.compile(rf"\b{re.escape(term)}\b", re.IGNORECASE)) for term in FORBIDDEN_EN_TERMS
)

FORBIDDEN_AR_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = tuple(
    (term, re.compile(rf"(?<!\w){re.escape(term)}(?!\w)"))
    for term in (*FORBIDDEN_AR_TERMS, *FORBIDDEN_MULTILINGUAL_TERMS)
)


@dataclass(frozen=True, slots=True)
class CopyViolation:
    source: str
    field_path: str
    matched_term: str
    snippet: str


def lint_text(
    text: str,
    *,
    source: str = "<inline>",
    field_path: str = "root",
) -> list[CopyViolation]:
    """Scan a single EN or AR string for forbidden blame, guilt, streak-loss terms, or '!'."""
    violations: list[CopyViolation] = []
    if not text:
        return violations

    for term, pattern in FORBIDDEN_EN_PATTERNS:
        if pattern.search(text):
            violations.append(
                CopyViolation(
                    source=source,
                    field_path=field_path,
                    matched_term=term,
                    snippet=text,
                )
            )

    for term, pattern in FORBIDDEN_AR_PATTERNS:
        if pattern.search(text):
            violations.append(
                CopyViolation(
                    source=source,
                    field_path=field_path,
                    matched_term=term,
                    snippet=text,
                )
            )

    if "!" in text:
        violations.append(
            CopyViolation(
                source=source,
                field_path=field_path,
                matched_term="!",
                snippet=text,
            )
        )

    return violations


def count_words(text: str) -> int:
    """Count whitespace-delimited words in a string."""
    return len(text.split())


def lint_coach_reply(
    text: str,
    *,
    max_words: int = 60,
    source: str = "<coach>",
    field_path: str = "reply",
) -> list[CopyViolation]:
    """Validate a coach reply against blame-free copy rules and the 60-word maximum (FR-004)."""
    violations = lint_text(text, source=source, field_path=field_path)
    if count_words(text) > max_words:
        violations.append(
            CopyViolation(
                source=source,
                field_path=field_path,
                matched_term="max_words_exceeded",
                snippet=text,
            )
        )
    return violations


_NON_COPY_KEYS: frozenset[str] = frozenset(
    {
        "id",
        "version",
        "behaviour",
        "level",
        "bct_codes",
        "contraindications",
        "avoid_contexts",
        "avoid_context_tags",
        "pause_behaviours",
        "substitute_behaviours",
        "cue_strategy",
        "evidence_level",
        "locale",
        "pictogram_id",
        "$schema",
    }
)


_EXEMPT_FIELD_PATHS: frozenset[str] = frozenset(
    {
        "demoControls.reset",
    }
)


def _walk_values(
    node: Any,
    *,
    source: str,
    field_path: str,
    violations: list[CopyViolation],
) -> None:
    if field_path in _EXEMPT_FIELD_PATHS:
        return
    if isinstance(node, str):
        violations.extend(lint_text(node, source=source, field_path=field_path))
        return
    if isinstance(node, Mapping):
        for k, v in node.items():
            key_str = str(k)
            if key_str in _NON_COPY_KEYS:
                continue
            next_path = f"{field_path}.{key_str}" if field_path else key_str
            _walk_values(v, source=source, field_path=next_path, violations=violations)
        return
    if isinstance(node, list | tuple):
        for idx, item in enumerate(node):
            next_path = f"{field_path}[{idx}]"
            _walk_values(item, source=source, field_path=next_path, violations=violations)


def lint_files(paths: Iterable[Path]) -> list[CopyViolation]:
    """Recursively lint YAML and JSON files for forbidden blame-free violations."""
    violations: list[CopyViolation] = []
    for raw_path in paths:
        path = Path(raw_path)
        if path.is_dir():
            sub_files = sorted(
                p
                for p in path.rglob("*")
                if p.is_file() and p.suffix.lower() in {".yaml", ".yml", ".json"}
            )
            violations.extend(lint_files(sub_files))
            continue

        suffix = path.suffix.lower()
        text = path.read_text(encoding="utf-8")
        if suffix in {".yaml", ".yml"}:
            data = yaml.safe_load(text)
        elif suffix == ".json":
            data = json.loads(text)
        else:
            continue

        _walk_values(data, source=str(path), field_path="", violations=violations)

    return violations
