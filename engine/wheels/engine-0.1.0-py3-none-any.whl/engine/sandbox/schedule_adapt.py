"""Ramadan and night-shift adaptation as a thin diff over the audited planner (spec 023 US4).

There are no rules of its own here and no second copy of the fasting hours. The plan is rebuilt
with ``plan_builder`` under the new context, using the plan's own per-area seeds, so the same
actions are chosen and only their cues and times move. The old and new plans are then compared,
slot by slot, and every difference becomes a change with a reason (Constitution III and VI).

Slot ids are kept when an action stays, so today's check-ins stay attached and nothing looks reset.
"""

from __future__ import annotations

from typing import Any

from engine.sandbox.checkin import active_plan
from engine.sandbox.library import get_library
from engine.sandbox.planning import PlanContext, is_restricted, select_items
from engine.sandbox.state import State

RAMADAN_FASTING = "ramadan_fasting"
NIGHT_SHIFT = "night_shift"
NIGHT_SHIFT_FIRST_DAY = "night_shift_first_day"
RESTORE_REGULAR = "restore_regular"

Item = dict[str, Any]
Change = dict[str, Any]


def _ref(item: Item) -> dict[str, str]:
    return {
        "action_id": item["action_id"],
        "cue_id": item["cue_id"],
        "clock_time": item["clock_time"],
    }


def _by_area(items: list[Item]) -> dict[str, list[Item]]:
    grouped: dict[str, list[Item]] = {}
    for item in items:
        grouped.setdefault(item["area"], []).append(item)
    return grouped


def _reason(trigger: str, *, restricted: bool, kind: str) -> str:
    if trigger == "restore_regular":
        return RESTORE_REGULAR
    if kind == "removed":
        return NIGHT_SHIFT_FIRST_DAY
    if trigger == "ramadan":
        return RAMADAN_FASTING
    if trigger == "combined":
        return RAMADAN_FASTING if restricted else NIGHT_SHIFT
    return NIGHT_SHIFT


def _change(kind: str, area: str, before: Item | None, after: Item | None, trigger: str) -> Change:
    library = get_library()
    subject = after or before
    assert subject is not None
    return {
        "kind": kind,
        "area": area,
        "before": None if before is None else _ref(before),
        "after": None if after is None else _ref(after),
        "reason_code": _reason(
            trigger,
            restricted=is_restricted(area, subject["action_id"], library),
            kind=kind,
        ),
    }


def diff_items(
    areas: list[str], old_items: list[Item], new_items: list[Item], trigger: str
) -> tuple[list[Item], list[Change]]:
    """Compare two plans slot by slot. Returns the items to use and what changed, with reasons.

    An action that stays keeps its slot (and its decision), so check-ins stay attached.
    """
    old = _by_area(old_items)
    new = _by_area(new_items)
    after_items: list[Item] = []
    changes: list[Change] = []
    for area in areas:
        before_items, planned_items = old.get(area, []), new.get(area, [])
        for index in range(max(len(before_items), len(planned_items))):
            before = before_items[index] if index < len(before_items) else None
            after = planned_items[index] if index < len(planned_items) else None
            if after is None:
                changes.append(_change("removed", area, before, None, trigger))
            elif before is None:
                after_items.append(after)
                changes.append(_change("added", area, None, after, trigger))
            elif before["action_id"] != after["action_id"]:
                after_items.append(after)
                changes.append(_change("swapped", area, before, after, trigger))
            else:
                kept = {**after, "slot_id": before["slot_id"], "decision_id": before["decision_id"]}
                after_items.append(kept)
                if (before["cue_id"], before["clock_time"]) != (kept["cue_id"], kept["clock_time"]):
                    changes.append(_change("moved", area, before, kept, trigger))
    return after_items, changes


def adapt(
    state: State, *, target: PlanContext, trigger: str, new_version: int
) -> dict[str, Any] | None:
    """A proposal that moves the active plan to ``target``, or None when nothing would change."""
    plan = active_plan(state)
    selection = select_items(state, version=new_version, context=target, seeds=plan["seeds"])
    after_items, changes = diff_items(
        state["profile"]["areas"], plan["items"], selection.items, trigger
    )
    if not changes:
        return None
    return {
        "id": None,
        "trigger": trigger,
        "created_on": state["current_date"],
        "before_version": plan["version"],
        "after_items": after_items,
        "changes": changes,
        "decision_id": None,
        "status": "pending",
        "context": target.to_dict(),
        "seeds": dict(plan["seeds"]),
    }
