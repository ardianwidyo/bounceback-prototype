# ruff: noqa: RUF001
"""Outcome measurement, Micro-Randomised Trial (MRT) WCLS estimator, questionnaires & privacy (F16).

Pure, deterministic Python module with zero I/O, zero network, and zero database dependencies
(Constitution Principles I, II, IV, V, VII).

Implements:
- FR-001, FR-002: MRT decision-point observation schema with strict availability & propensity bounds
  (`0.05 <= propensity <= 0.95` when `available=True`, `propensity == 1.0` when `available=False`).
- FR-003, FR-004: Weighted Centred Least Squares (WCLS; Boruvka et al., 2018) proximal treatment
  effect estimator with person-clustered Liang-Zeger sandwich standard errors and context moderation
  (`in_lapse_window`, `shift_worker`).
- FR-005, FR-006, FR-007: Short validated bilingual (`en`/`ar`) questionnaires (`autonomy_support`
  HCCQ-short 6 items, `diet_screener` 4 items, `sleep_screener` 4 items) and notification-budget
  hard gate scheduler.
- FR-010, FR-011, SC-003: Keyed HMAC-SHA256 pseudonymisation (`psn_<24-hex>`), reproducible
  analytics export bundle builder, and automated zero-PII / zero-free-text privacy verifier.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import math
import random
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Literal

from engine.simulator import CohortSimulationResult

ENGINE_MRT_VERSION = "0.16.0"
MIN_PROPENSITY = 0.05
MAX_PROPENSITY = 0.95

PSEUDONYM_PATTERN = re.compile(r"^psn_[0-9a-f]{24}$")
RAW_UUID_PATTERN = re.compile(
    r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b"
)
EMAIL_PATTERN = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
PHONE_PATTERN = re.compile(r"(?:\+\d{7,15}|\b05\d{8}\b)")
FORBIDDEN_EXPORT_KEYS = frozenset(
    {
        "user_id",
        "raw_user_id",
        "email",
        "phone",
        "phone_number",
        "full_name",
        "display_name",
        "message",
        "free_text",
        "transcript",
        "chat_body",
        "clinician_note",
        "note_text",
    }
)

UnavailabilityReasonLiteral = Literal[
    "quiet_hours",
    "ramadan_fasting_window",
    "daily_budget_exhausted",
    "red_flag_hold",
    "notification_opted_out",
    "no_eligible_candidates",
]
QuestionnaireInstrumentIdLiteral = Literal[
    "autonomy_support",
    "diet_screener",
    "sleep_screener",
]


@dataclass(frozen=True, slots=True)
class MrtDecisionPointObservation:
    """Single MRT decision point (`t`) with availability, propensity, and proximal outcome."""

    pseudonym_id: str
    decision_index: int
    week: int
    available: bool
    unavailability_reason: UnavailabilityReasonLiteral | None
    candidate_count: int
    treatment: Literal[0, 1]
    propensity: float
    proximal_outcome: Literal[0, 1]
    in_lapse_window: bool
    shift_worker: bool
    prior_7d_completion_rate: float
    policy_version: str

    def __post_init__(self) -> None:
        if not PSEUDONYM_PATTERN.match(self.pseudonym_id):
            raise ValueError(
                f"pseudonym_id must match ^psn_[0-9a-f]{{24}}$, got {self.pseudonym_id!r}"
            )
        if self.decision_index < 1:
            raise ValueError("decision_index must be >= 1")
        if self.week < 1:
            raise ValueError("week must be >= 1")
        if self.treatment not in (0, 1):
            raise ValueError("treatment must be 0 or 1")
        if self.proximal_outcome not in (0, 1):
            raise ValueError("proximal_outcome must be 0 or 1")
        if not (0.0 <= self.prior_7d_completion_rate <= 1.0):
            raise ValueError("prior_7d_completion_rate must be in [0.0, 1.0]")

        if self.available:
            if self.unavailability_reason is not None:
                raise ValueError("unavailability_reason must be None when available=True")
            if self.candidate_count < 1:
                raise ValueError("candidate_count must be >= 1 when available=True")
            if not (MIN_PROPENSITY <= self.propensity <= MAX_PROPENSITY):
                raise ValueError(
                    f"propensity must be within [{MIN_PROPENSITY}, {MAX_PROPENSITY}] "
                    f"when available=True, got {self.propensity}"
                )
        else:
            if self.unavailability_reason is None:
                raise ValueError("unavailability_reason is required when available=False")
            if self.treatment != 0:
                raise ValueError("treatment must be 0 when available=False")
            if abs(self.propensity - 1.0) > 1e-9:
                raise ValueError(
                    f"propensity must be 1.0 when available=False, got {self.propensity}"
                )


@dataclass(frozen=True, slots=True)
class MrtEffectEstimate:
    """Weighted Centred Least Squares (WCLS) causal effect estimate with sandwich SE."""

    parameter: str
    contrast_label: str
    effect_estimate: float
    std_error: float
    ci_95_lower: float
    ci_95_upper: float
    p_value: float
    n_users: int
    available_decision_points: int


@dataclass(frozen=True, slots=True)
class MrtAnalysisReport:
    """Complete WCLS analysis report across all and moderated decision points."""

    estimator: Literal["weighted_centred_least_squares"]
    total_decision_points: int
    available_decision_points: int
    availability_rate: float
    mean_propensity: float
    propensity_min: float
    propensity_max: float
    estimates: tuple[MrtEffectEstimate, ...]


@dataclass(frozen=True, slots=True)
class QuestionnaireItem:
    """One bilingual rating-scale item in a short validated questionnaire."""

    id: str
    prompt_en: str
    prompt_ar: str
    min_label_en: str
    max_label_en: str
    min_label_ar: str
    max_label_ar: str


@dataclass(frozen=True, slots=True)
class QuestionnaireInstrument:
    """Bilingual short validated questionnaire definition."""

    instrument_id: QuestionnaireInstrumentIdLiteral
    title_en: str
    title_ar: str
    subtitle_en: str
    subtitle_ar: str
    citation_label: str
    cadence_weeks: int
    estimated_seconds: int
    scale_min: int
    scale_max: int
    items: tuple[QuestionnaireItem, ...]


@dataclass(frozen=True, slots=True)
class QuestionnaireScheduleEvaluation:
    """Result of checking whether a due questionnaire may use a notification slot."""

    can_notify: bool
    block_reason: UnavailabilityReasonLiteral | None
    remaining_daily_budget: int


@dataclass(frozen=True, slots=True)
class ReproducibilityManifest:
    """Deterministic manifest recorded with every pseudonymised analytics export & MRT analysis."""

    export_id: str
    dataset_digest: str
    seed: int
    engine_version: str
    policy_version: str
    key_id: str
    row_counts: dict[str, int]
    privacy_verified: bool


@dataclass(frozen=True, slots=True)
class PseudonymisedExportBundle:
    """In-memory pseudonymised analytics tables + reproducibility manifest."""

    manifest: ReproducibilityManifest
    decisions: list[dict[str, Any]]
    checkins: list[dict[str, Any]]
    signals: list[dict[str, Any]]
    questionnaires: list[dict[str, Any]]


QUESTIONNAIRE_CATALOGUE: dict[QuestionnaireInstrumentIdLiteral, QuestionnaireInstrument] = {
    "autonomy_support": QuestionnaireInstrument(
        instrument_id="autonomy_support",
        title_en="How supportive does BounceBack feel?",
        title_ar="ما مدى شعورك بأن باونس باك يدعم اختياراتك؟",
        subtitle_en=(
            "6 quick questions about choice and respect. You can skip any time with no penalty."
        ),
        subtitle_ar=(
            "٦ أسئلة قصيرة حول حرية الاختيار والاحترام. يمكنك التخطي في أي وقت دون أي أثر."
        ),
        citation_label="Adapted Health Care Climate Questionnaire (HCCQ-short, 6 items, 1–7)",
        cadence_weeks=4,
        estimated_seconds=35,
        scale_min=1,
        scale_max=7,
        items=(
            QuestionnaireItem(
                id="hccq_1",
                prompt_en="I feel that BounceBack provides me with choices and options.",
                prompt_ar="أشعر أن باونس باك يوفّر لي خيارات متعددة.",
                min_label_en="Strongly disagree",
                max_label_en="Strongly agree",
                min_label_ar="لا أوافق بشدة",
                max_label_ar="أوافق بشدة",
            ),
            QuestionnaireItem(
                id="hccq_2",
                prompt_en="I feel understood by my companion when life gets busy.",
                prompt_ar="أشعر بالتفهّم عندما تنشغل حياتي أو تتغير ظروفي.",
                min_label_en="Strongly disagree",
                max_label_en="Strongly agree",
                min_label_ar="لا أوافق بشدة",
                max_label_ar="أوافق بشدة",
            ),
            QuestionnaireItem(
                id="hccq_3",
                prompt_en="Suggestions are shared without pressuring or blaming me.",
                prompt_ar="تُقدَّم الاقتراحات دون ضغط أو لوم.",
                min_label_en="Strongly disagree",
                max_label_en="Strongly agree",
                min_label_ar="لا أوافق بشدة",
                max_label_ar="أوافق بشدة",
            ),
            QuestionnaireItem(
                id="hccq_4",
                prompt_en="BounceBack encourages me to adapt my Tiny Version in my own way.",
                prompt_ar="يشجعني التطبيق على تكييف الخطوة الصغيرة بطريقتي الخاصة.",
                min_label_en="Strongly disagree",
                max_label_en="Strongly agree",
                min_label_ar="لا أوافق بشدة",
                max_label_ar="أوافق بشدة",
            ),
            QuestionnaireItem(
                id="hccq_5",
                prompt_en="I feel confident I can pause and restart a habit without starting over.",
                prompt_ar="أشعر بالثقة بأنني أستطيع التوقف والعودة للعادة دون البدء من الصفر.",
                min_label_en="Strongly disagree",
                max_label_en="Strongly agree",
                min_label_ar="لا أوافق بشدة",
                max_label_ar="أوافق بشدة",
            ),
            QuestionnaireItem(
                id="hccq_6",
                prompt_en="The reasons behind each suggestion are clear before I decide.",
                prompt_ar="تكون أسباب كل اقتراح واضحة قبل أن أتخذ قراري.",
                min_label_en="Strongly disagree",
                max_label_en="Strongly agree",
                min_label_ar="لا أوافق بشدة",
                max_label_ar="أوافق بشدة",
            ),
        ),
    ),
    "diet_screener": QuestionnaireInstrument(
        instrument_id="diet_screener",
        title_en="Brief Nutrition Rhythm Check",
        title_ar="مراجعة قصيرة لنمط التغذية",
        subtitle_en=(
            "4 quick ratings on your recent meals and hydration. Optional and blame-free."
        ),
        subtitle_ar="٤ تقييمات سريعة لوجباتك وشرب الماء مؤخراً. اختيارية وخالية من اللوم.",
        citation_label="Brief Healthy Eating & Hydration Screener (4 items, 0–5)",
        cadence_weeks=4,
        estimated_seconds=25,
        scale_min=0,
        scale_max=5,
        items=(
            QuestionnaireItem(
                id="diet_1",
                prompt_en=(
                    "How many days this week did you include vegetables or fruit with a meal?"
                ),
                prompt_ar="كم يوماً هذا الأسبوع أضفت خضروات أو فاكهة مع إحدى وجباتك؟",
                min_label_en="0 days",
                max_label_en="5+ days",
                min_label_ar="٠ أيام",
                max_label_ar="٥+ أيام",
            ),
            QuestionnaireItem(
                id="diet_2",
                prompt_en="How many days did you choose water instead of a sugary drink?",
                prompt_ar="كم يوماً اخترت الماء بدلاً من المشروبات المحلّاة؟",
                min_label_en="0 days",
                max_label_en="5+ days",
                min_label_ar="٠ أيام",
                max_label_ar="٥+ أيام",
            ),
            QuestionnaireItem(
                id="diet_3",
                prompt_en=(
                    "How many days did your meal timing fit comfortably around "
                    "your work or family schedule?"
                ),
                prompt_ar="كم يوماً كان توقيت وجباتك مناسباً ومريحاً مع جدول عملك أو عائلتك؟",
                min_label_en="0 days",
                max_label_en="5+ days",
                min_label_ar="٠ أيام",
                max_label_ar="٥+ أيام",
            ),
            QuestionnaireItem(
                id="diet_4",
                prompt_en="How many days did you include a balanced protein or whole-grain option?",
                prompt_ar="كم يوماً تناولت خياراً متوازناً من البروتين أو الحبوب الكاملة؟",
                min_label_en="0 days",
                max_label_en="5+ days",
                min_label_ar="٠ أيام",
                max_label_ar="٥+ أيام",
            ),
        ),
    ),
    "sleep_screener": QuestionnaireInstrument(
        instrument_id="sleep_screener",
        title_en="Brief Sleep & Recovery Check",
        title_ar="مراجعة قصيرة للنوم والتعافي",
        subtitle_en=(
            "4 quick ratings on how rested you felt this week. Works for day or shift schedules."
        ),
        subtitle_ar="٤ تقييمات سريعة لمدى شعورك بالراحة هذا الأسبوع للعمل النهاري أو المناوبات.",
        citation_label="Brief Sleep Quality & Wind-Down Screener (4 items, 0–5)",
        cadence_weeks=4,
        estimated_seconds=25,
        scale_min=0,
        scale_max=5,
        items=(
            QuestionnaireItem(
                id="sleep_1",
                prompt_en="How many days this week did you wake up feeling reasonably rested?",
                prompt_ar="كم يوماً هذا الأسبوع استيقظت وأنت تشعر بقسط معقول من الراحة؟",
                min_label_en="0 days",
                max_label_en="5+ days",
                min_label_ar="٠ أيام",
                max_label_ar="٥+ أيام",
            ),
            QuestionnaireItem(
                id="sleep_2",
                prompt_en="How many days did you take a short wind-down pause before sleeping?",
                prompt_ar="كم يوماً أخذت فترة تهدئة قصيرة قبل النوم؟",
                min_label_en="0 days",
                max_label_en="5+ days",
                min_label_ar="٠ أيام",
                max_label_ar="٥+ أيام",
            ),
            QuestionnaireItem(
                id="sleep_3",
                prompt_en=(
                    "How many days was your sleep window relatively consistent "
                    "with your shift or routine?"
                ),
                prompt_ar="كم يوماً كانت نافذة نومك متسقة نسبياً مع مناوبتك أو روتينك؟",
                min_label_en="0 days",
                max_label_en="5+ days",
                min_label_ar="٠ أيام",
                max_label_ar="٥+ أيام",
            ),
            QuestionnaireItem(
                id="sleep_4",
                prompt_en=(
                    "How many days did you feel your daytime energy supported a Tiny Version?"
                ),
                prompt_ar="كم يوماً شعرت أن طاقتك اليومية ساعدتك على القيام بخطوة صغيرة؟",
                min_label_en="0 days",
                max_label_en="5+ days",
                min_label_ar="٠ أيام",
                max_label_ar="٥+ أيام",
            ),
        ),
    ),
}


def pseudonymise_user_id(user_id: str, secret_key: str) -> str:
    """Compute a deterministic keyed-HMAC pseudonym (`psn_<24-hex>`) from `user_id`."""
    if not user_id or not user_id.strip():
        raise ValueError("user_id must be non-empty")
    if not secret_key or not secret_key.strip():
        raise ValueError("secret_key must be non-empty")
    digest = hmac.new(
        secret_key.encode("utf-8"),
        user_id.strip().encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()[:24]
    return f"psn_{digest}"


def evaluate_questionnaire_schedule(
    *,
    daily_notification_budget: int,
    nudges_sent_today: int,
    is_in_quiet_hours: bool,
    ramadan_fasting_window_active: bool,
    notification_opted_out: bool,
    has_open_red_flag: bool,
) -> QuestionnaireScheduleEvaluation:
    """Evaluate hard notification-budget and safety gates before prompting a questionnaire."""
    remaining = max(0, int(daily_notification_budget) - int(nudges_sent_today))
    if has_open_red_flag:
        return QuestionnaireScheduleEvaluation(
            can_notify=False,
            block_reason="red_flag_hold",
            remaining_daily_budget=remaining,
        )
    if notification_opted_out:
        return QuestionnaireScheduleEvaluation(
            can_notify=False,
            block_reason="notification_opted_out",
            remaining_daily_budget=remaining,
        )
    if is_in_quiet_hours:
        return QuestionnaireScheduleEvaluation(
            can_notify=False,
            block_reason="quiet_hours",
            remaining_daily_budget=remaining,
        )
    if ramadan_fasting_window_active:
        return QuestionnaireScheduleEvaluation(
            can_notify=False,
            block_reason="ramadan_fasting_window",
            remaining_daily_budget=remaining,
        )
    if remaining <= 0:
        return QuestionnaireScheduleEvaluation(
            can_notify=False,
            block_reason="daily_budget_exhausted",
            remaining_daily_budget=0,
        )
    return QuestionnaireScheduleEvaluation(
        can_notify=True,
        block_reason=None,
        remaining_daily_budget=remaining,
    )


def score_questionnaire_submission(
    instrument_id: QuestionnaireInstrumentIdLiteral,
    answers: Mapping[str, int],
) -> tuple[float, float]:
    """Validate item ratings and return `(raw_score, normalized_score_0_to_100)`."""
    if instrument_id not in QUESTIONNAIRE_CATALOGUE:
        raise ValueError(f"Unknown questionnaire instrument: {instrument_id!r}")
    instrument = QUESTIONNAIRE_CATALOGUE[instrument_id]
    expected_ids = {item.id for item in instrument.items}
    provided_ids = set(answers.keys())
    if provided_ids != expected_ids:
        missing = sorted(expected_ids - provided_ids)
        extra = sorted(provided_ids - expected_ids)
        raise ValueError(
            f"Questionnaire answers must match items for {instrument_id}; "
            f"missing={missing}, extra={extra}"
        )

    values: list[int] = []
    for item in instrument.items:
        val = answers[item.id]
        if isinstance(val, bool) or not isinstance(val, int):
            raise ValueError(f"Item {item.id} rating must be an integer")
        if not (instrument.scale_min <= val <= instrument.scale_max):
            raise ValueError(
                f"Item {item.id} rating {val} outside scale "
                f"[{instrument.scale_min}, {instrument.scale_max}]"
            )
        values.append(val)

    raw_mean = sum(values) / len(values)
    scale_span = instrument.scale_max - instrument.scale_min
    normalized = ((raw_mean - instrument.scale_min) / scale_span) * 100.0 if scale_span > 0 else 0.0
    return round(raw_mean, 2), round(normalized, 1)


def extract_mrt_observations_from_simulation(
    sim: CohortSimulationResult,
    *,
    secret_key: str = "bounceback-pilot-hmac-key",
    policy_version: str = "selector-v1",
) -> tuple[MrtDecisionPointObservation, ...]:
    """Extract deterministic weekly MRT decision points from a seeded cohort simulation."""
    observations: list[MrtDecisionPointObservation] = []
    traj_by_user = {t.user_id: t for t in sim.adaptive_trajectories}

    for user_idx, persona in enumerate(sim.cohort):
        pseudonym = pseudonymise_user_id(persona.user_id, secret_key)
        traj = traj_by_user[persona.user_id]
        shift_worker = persona.work_pattern in ("night", "rotating_shifts")
        lapse_onset_weeks = {max(1, (ep.onset_day - 1) // 7 + 1) for ep in traj.lapse_episodes}

        prior_rate = round(min(0.95, max(0.15, persona.base_adherence_prob)), 3)
        for week in range(1, sim.horizon_weeks + 1):
            rng = random.Random(sim.seed * 100_003 + (user_idx + 1) * 1_009 + week * 37)
            in_lapse = week in lapse_onset_weeks or (
                week > 1
                and (week - 1) <= len(traj.weekly_active)
                and not traj.weekly_active[week - 2]
            )

            # Determine availability at decision point t (quiet hours, budget cap, opt-out)
            unavail_draw = rng.random()
            if traj.notification_opted_out and week > (sim.horizon_weeks // 2):
                available = False
                reason: UnavailabilityReasonLiteral | None = "notification_opted_out"
            elif unavail_draw < 0.07:
                available = False
                reason = "quiet_hours"
            elif unavail_draw < 0.11:
                available = False
                reason = "ramadan_fasting_window"
            elif unavail_draw < 0.15:
                available = False
                reason = "daily_budget_exhausted"
            else:
                available = True
                reason = None

            if not available:
                prox_prob = max(0.08, min(0.85, 0.32 * prior_rate))
                prox_outcome: Literal[0, 1] = 1 if rng.random() < prox_prob else 0
                observations.append(
                    MrtDecisionPointObservation(
                        pseudonym_id=pseudonym,
                        decision_index=week,
                        week=week,
                        available=False,
                        unavailability_reason=reason,
                        candidate_count=0,
                        treatment=0,
                        propensity=1.0,
                        proximal_outcome=prox_outcome,
                        in_lapse_window=in_lapse,
                        shift_worker=shift_worker,
                        prior_7d_completion_rate=prior_rate,
                        policy_version=policy_version,
                    )
                )
                prior_rate = round(0.75 * prior_rate + 0.25 * float(prox_outcome), 3)
                continue

            # Bounded MRT randomisation probability p_t in [0.05, 0.95]
            raw_p = 0.58 + (0.08 if in_lapse else 0.0) + (0.04 if shift_worker else 0.0)
            raw_p += (prior_rate - 0.5) * 0.10
            propensity = round(max(MIN_PROPENSITY, min(MAX_PROPENSITY, raw_p)), 4)
            treatment: Literal[0, 1] = 1 if rng.random() < propensity else 0
            candidate_count = 3 if len(persona.behaviours) == 1 else 4

            # Proximal causal generating process:
            # Base completion under A_t = 0 plus positive causal lift under A_t = 1
            base_prob = (
                0.28
                + 0.34 * prior_rate
                - (0.08 if in_lapse else 0.0)
                - (0.04 if shift_worker else 0.0)
            )
            causal_lift = 0.17 + (0.08 if in_lapse else 0.0) + (0.04 if shift_worker else 0.0)
            outcome_prob = max(0.05, min(0.95, base_prob + treatment * causal_lift))
            prox_outcome = 1 if rng.random() < outcome_prob else 0

            observations.append(
                MrtDecisionPointObservation(
                    pseudonym_id=pseudonym,
                    decision_index=week,
                    week=week,
                    available=True,
                    unavailability_reason=None,
                    candidate_count=candidate_count,
                    treatment=treatment,
                    propensity=propensity,
                    proximal_outcome=prox_outcome,
                    in_lapse_window=in_lapse,
                    shift_worker=shift_worker,
                    prior_7d_completion_rate=prior_rate,
                    policy_version=policy_version,
                )
            )
            prior_rate = round(0.75 * prior_rate + 0.25 * float(prox_outcome), 3)

    return tuple(observations)


def _normal_two_sided_p_value(z_stat: float) -> float:
    """Two-sided p-value under standard normal distribution using `math.erfc`."""
    return max(1e-12, min(1.0, math.erfc(abs(z_stat) / math.sqrt(2.0))))


def _wcls_stratum_estimate(
    parameter: str,
    contrast_label: str,
    obs_subset: Sequence[MrtDecisionPointObservation],
) -> MrtEffectEstimate:
    """Compute Boruvka et al. (2018) WCLS estimate with person-clustered Liang-Zeger sandwich SE.

    Within an availability-filtered stratum of decision points:
    - Stabilization probability: `p_tilde = mean(A_t)` bounded to `[0.05, 0.95]`.
    - Weight: `W_t = (p_tilde / p_t)^A_t * ((1 - p_tilde) / (1 - p_t))^(1 - A_t)`.
    - Control feature: centered `prior_7d_completion_rate` (`H_tilde_t = H_t - mean(H)`).
    - Centered treatment: `C_t = A_t - p_tilde`.
    - Regresses `Y_{t+1}` on `X_t = [1, H_tilde_t, C_t]` with weights `W_t` and computes the
      Liang-Zeger cluster-robust sandwich variance grouped by `pseudonym_id`.
    """
    avail = [o for o in obs_subset if o.available]
    n_avail = len(avail)
    unique_users = sorted({o.pseudonym_id for o in avail})
    n_users = len(unique_users)

    if n_avail < 4 or n_users < 2:
        return MrtEffectEstimate(
            parameter=parameter,
            contrast_label=contrast_label,
            effect_estimate=0.0,
            std_error=0.0,
            ci_95_lower=0.0,
            ci_95_upper=0.0,
            p_value=1.0,
            n_users=n_users,
            available_decision_points=n_avail,
        )

    p_tilde = max(
        MIN_PROPENSITY,
        min(MAX_PROPENSITY, sum(o.treatment for o in avail) / float(n_avail)),
    )
    h_mean = sum(o.prior_7d_completion_rate for o in avail) / float(n_avail)

    # 3x3 weighted normal equations for X_t = [1.0, H_tilde_t, C_t]
    xtwx = [[0.0, 0.0, 0.0] for _ in range(3)]
    xtwy = [0.0, 0.0, 0.0]

    records: list[tuple[str, float, tuple[float, float, float], float]] = []
    for o in avail:
        a = float(o.treatment)
        p = o.propensity
        w = (p_tilde / p) if o.treatment == 1 else ((1.0 - p_tilde) / (1.0 - p))
        x_vec = (1.0, o.prior_7d_completion_rate - h_mean, a - p_tilde)
        y = float(o.proximal_outcome)
        records.append((o.pseudonym_id, w, x_vec, y))
        for r in range(3):
            xtwy[r] += w * x_vec[r] * y
            for c in range(3):
                xtwx[r][c] += w * x_vec[r] * x_vec[c]

    inv_xtwx = _invert_3x3(xtwx)
    theta = [sum(inv_xtwx[r][c] * xtwy[c] for c in range(3)) for r in range(3)]
    beta_hat = theta[2]

    # Liang-Zeger person-clustered meat matrix: sum_i (u_i u_i^T) where u_i = sum_t w_it r_it x_it
    cluster_scores: dict[str, list[float]] = {u: [0.0, 0.0, 0.0] for u in unique_users}
    for uid, w, x_vec, y in records:
        y_hat = theta[0] * x_vec[0] + theta[1] * x_vec[1] + theta[2] * x_vec[2]
        resid = y - y_hat
        score = cluster_scores[uid]
        score[0] += w * resid * x_vec[0]
        score[1] += w * resid * x_vec[1]
        score[2] += w * resid * x_vec[2]

    # Small-sample cluster degrees-of-freedom adjustment G / (G - 1)
    dof_scale = float(n_users) / float(max(1, n_users - 1))
    meat = [[0.0, 0.0, 0.0] for _ in range(3)]
    for score in cluster_scores.values():
        for r in range(3):
            for c in range(3):
                meat[r][c] += dof_scale * score[r] * score[c]

    # Sandwich covariance = inv_xtwx @ meat @ inv_xtwx
    temp = [
        [sum(inv_xtwx[r][k] * meat[k][c] for k in range(3)) for c in range(3)] for r in range(3)
    ]
    cov = [[sum(temp[r][k] * inv_xtwx[c][k] for k in range(3)) for c in range(3)] for r in range(3)]
    var_beta = max(1e-10, cov[2][2])
    se_beta = math.sqrt(var_beta)
    ci_low = beta_hat - 1.96 * se_beta
    ci_high = beta_hat + 1.96 * se_beta
    z_stat = beta_hat / se_beta if se_beta > 0 else 0.0
    p_val = _normal_two_sided_p_value(z_stat)

    return MrtEffectEstimate(
        parameter=parameter,
        contrast_label=contrast_label,
        effect_estimate=round(beta_hat, 4),
        std_error=round(se_beta, 4),
        ci_95_lower=round(ci_low, 4),
        ci_95_upper=round(ci_high, 4),
        p_value=round(p_val, 6),
        n_users=n_users,
        available_decision_points=n_avail,
    )


def _invert_3x3(mat: list[list[float]]) -> list[list[float]]:
    """Invert a 3x3 matrix with tiny ridge regularization if near-singular."""
    m = [row[:] for row in mat]
    for diag_idx in range(3):
        m[diag_idx][diag_idx] += 1e-8
    a, b, c = m[0]
    d, e, f = m[1]
    g, h, i = m[2]
    det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    if abs(det) < 1e-12:
        det = 1e-12 if det >= 0 else -1e-12
    inv_det = 1.0 / det
    return [
        [
            (e * i - f * h) * inv_det,
            (c * h - b * i) * inv_det,
            (b * f - c * e) * inv_det,
        ],
        [
            (f * g - d * i) * inv_det,
            (a * i - c * g) * inv_det,
            (c * d - a * f) * inv_det,
        ],
        [
            (d * h - e * g) * inv_det,
            (b * g - a * h) * inv_det,
            (a * e - b * d) * inv_det,
        ],
    ]


def estimate_mrt_proximal_effect(
    observations: Sequence[MrtDecisionPointObservation],
) -> MrtAnalysisReport:
    """Compute overall and context-moderated proximal causal effects via WCLS (FR-003, FR-004)."""
    total_pts = len(observations)
    avail_obs = [o for o in observations if o.available]
    n_avail = len(avail_obs)
    avail_rate = round((n_avail / float(total_pts)) * 100.0, 1) if total_pts > 0 else 0.0

    if n_avail > 0:
        propensities = [o.propensity for o in avail_obs]
        mean_prop = round(sum(propensities) / float(n_avail), 4)
        min_prop = round(min(propensities), 4)
        max_prop = round(max(propensities), 4)
    else:
        mean_prop = 0.0
        min_prop = 0.0
        max_prop = 0.0

    overall_est = _wcls_stratum_estimate(
        "overall_proximal_effect",
        "Suggestion sent (A_t=1) vs not sent (A_t=0) across all available decision points",
        avail_obs,
    )
    lapse_est = _wcls_stratum_estimate(
        "lapse_window_effect",
        "Proximal effect of suggestion during a lapse / recovery window (in_lapse_window=True)",
        [o for o in avail_obs if o.in_lapse_window],
    )
    steady_est = _wcls_stratum_estimate(
        "steady_state_effect",
        "Proximal effect of suggestion during steady routine weeks (in_lapse_window=False)",
        [o for o in avail_obs if not o.in_lapse_window],
    )
    shift_est = _wcls_stratum_estimate(
        "shift_worker_effect",
        "Proximal effect of suggestion for rotating/night shift workers (shift_worker=True)",
        [o for o in avail_obs if o.shift_worker],
    )
    day_est = _wcls_stratum_estimate(
        "day_worker_effect",
        "Proximal effect of suggestion for daytime/non-shift schedules (shift_worker=False)",
        [o for o in avail_obs if not o.shift_worker],
    )

    return MrtAnalysisReport(
        estimator="weighted_centred_least_squares",
        total_decision_points=total_pts,
        available_decision_points=n_avail,
        availability_rate=avail_rate,
        mean_propensity=mean_prop,
        propensity_min=min_prop,
        propensity_max=max_prop,
        estimates=(overall_est, lapse_est, steady_est, shift_est, day_est),
    )


def build_pseudonymised_export_bundle(
    sim: CohortSimulationResult,
    *,
    secret_key: str = "bounceback-pilot-hmac-key",
    key_id: str = "kv-bounceback-mrt-hmac-v1",
    policy_version: str = "selector-v1",
    extra_questionnaires: Sequence[Mapping[str, Any]] = (),
) -> PseudonymisedExportBundle:
    """Build pseudonymised `decisions`, `checkins`, `signals`, and `questionnaires` tables."""
    obs = extract_mrt_observations_from_simulation(
        sim,
        secret_key=secret_key,
        policy_version=policy_version,
    )
    decisions: list[dict[str, Any]] = [
        {
            "pseudonym_id": o.pseudonym_id,
            "decision_index": o.decision_index,
            "week": o.week,
            "available": o.available,
            "unavailability_reason": o.unavailability_reason,
            "candidate_count": o.candidate_count,
            "treatment": o.treatment,
            "propensity": o.propensity,
            "proximal_outcome": o.proximal_outcome,
            "in_lapse_window": o.in_lapse_window,
            "shift_worker": o.shift_worker,
            "prior_7d_completion_rate": o.prior_7d_completion_rate,
            "policy_version": o.policy_version,
        }
        for o in obs
    ]

    checkins: list[dict[str, Any]] = []
    signals: list[dict[str, Any]] = []
    questionnaires: list[dict[str, Any]] = []

    traj_by_user = {t.user_id: t for t in sim.adaptive_trajectories}
    for user_idx, persona in enumerate(sim.cohort):
        pseudonym = pseudonymise_user_id(persona.user_id, secret_key)
        traj = traj_by_user[persona.user_id]
        shift_worker = persona.work_pattern in ("night", "rotating_shifts")

        for week_idx, is_active in enumerate(traj.weekly_active):
            week_num = week_idx + 1
            rng = random.Random(sim.seed * 70_001 + (user_idx + 1) * 503 + week_num * 19)
            active_days_week = rng.randint(3, 6) if is_active else rng.randint(0, 2)
            mvpa_minutes = (
                active_days_week * rng.randint(24, 34)
                if is_active
                else active_days_week * rng.randint(10, 18)
            )
            checkins.append(
                {
                    "pseudonym_id": pseudonym,
                    "week": week_num,
                    "arm": "adaptive",
                    "active_week": bool(is_active),
                    "active_days_in_week": active_days_week,
                    "barrier_code": persona.primary_barrier if not is_active else None,
                }
            )
            signals.append(
                {
                    "pseudonym_id": pseudonym,
                    "week": week_num,
                    "weekly_mvpa_minutes": mvpa_minutes,
                    "sleep_regularity_index": round(
                        rng.uniform(62.0, 88.0) if is_active else rng.uniform(45.0, 70.0), 1
                    ),
                    "shift_worker": shift_worker,
                }
            )

        # Synthetic validated questionnaire responses at Week 4 and Week 12
        rng_q = random.Random(sim.seed * 90_007 + (user_idx + 1) * 911)
        base_autonomy = 6.1 if traj.retained_at_w12 else 5.5
        if persona.disability == "self_identified":
            base_autonomy -= 0.15
        autonomy_score = round(
            max(1.0, min(7.0, base_autonomy + rng_q.uniform(-0.35, 0.45))),
            2,
        )
        questionnaires.append(
            {
                "pseudonym_id": pseudonym,
                "instrument_id": "autonomy_support",
                "week": min(12, sim.horizon_weeks),
                "status": "completed",
                "raw_score": autonomy_score,
                "normalized_score": round(((autonomy_score - 1.0) / 6.0) * 100.0, 1),
            }
        )

    for extra in extra_questionnaires:
        row = dict(extra)
        if "user_id" in row:
            raw_uid = str(row.pop("user_id"))
            row["pseudonym_id"] = pseudonymise_user_id(raw_uid, secret_key)
        questionnaires.append(row)

    canonical_payload = json.dumps(
        {
            "seed": sim.seed,
            "engine_version": ENGINE_MRT_VERSION,
            "policy_version": policy_version,
            "key_id": key_id,
            "decisions_count": len(decisions),
            "checkins_count": len(checkins),
            "signals_count": len(signals),
            "questionnaires_count": len(questionnaires),
            "first_decision": decisions[0] if decisions else None,
            "last_decision": decisions[-1] if decisions else None,
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    digest = hashlib.sha256(canonical_payload).hexdigest()
    export_id = f"mrt-exp-{sim.seed}-{digest[:12]}"

    manifest = ReproducibilityManifest(
        export_id=export_id,
        dataset_digest=digest,
        seed=sim.seed,
        engine_version=ENGINE_MRT_VERSION,
        policy_version=policy_version,
        key_id=key_id,
        row_counts={
            "decisions": len(decisions),
            "checkins": len(checkins),
            "signals": len(signals),
            "questionnaires": len(questionnaires),
        },
        privacy_verified=True,
    )
    bundle = PseudonymisedExportBundle(
        manifest=manifest,
        decisions=decisions,
        checkins=checkins,
        signals=signals,
        questionnaires=questionnaires,
    )
    verify_export_privacy(bundle)
    return bundle


def verify_export_privacy(bundle: PseudonymisedExportBundle) -> bool:
    """Verify every exported record contains only pseudonymised IDs and zero PII or free text."""
    tables: tuple[tuple[str, Sequence[Mapping[str, Any]]], ...] = (
        ("decisions", bundle.decisions),
        ("checkins", bundle.checkins),
        ("signals", bundle.signals),
        ("questionnaires", bundle.questionnaires),
    )
    for table_name, rows in tables:
        for idx, row in enumerate(rows):
            for key, value in row.items():
                if key in FORBIDDEN_EXPORT_KEYS:
                    raise ValueError(
                        f"Export privacy violation in {table_name}[{idx}]: forbidden column {key!r}"
                    )
                if isinstance(value, str):
                    if RAW_UUID_PATTERN.search(value):
                        raise ValueError(
                            f"Export privacy violation in {table_name}[{idx}].{key}: "
                            "raw UUID detected"
                        )
                    if EMAIL_PATTERN.search(value) or PHONE_PATTERN.search(value):
                        raise ValueError(
                            f"Export privacy violation in {table_name}[{idx}].{key}: "
                            "contact PII detected"
                        )
            pseudonym = row.get("pseudonym_id")
            if not isinstance(pseudonym, str) or not PSEUDONYM_PATTERN.match(pseudonym):
                raise ValueError(
                    f"Export privacy violation in {table_name}[{idx}]: "
                    f"invalid pseudonym_id {pseudonym!r}"
                )
    return True
