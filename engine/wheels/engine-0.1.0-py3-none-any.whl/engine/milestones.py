"""Blame-free streaks and milestones (spec 023 US2; Constitution II).

* The "streak" is a **consistency count**: active days in the last 7, never a chain that can break.
* Cumulative active days and earned milestones only ever grow; nothing here can remove progress.
* ``first_comeback`` celebrates returning after a gap, and a gap never resets anything.

All functions are pure and work on the JSON check-in records of a SandboxState
(``{"date": "YYYY-MM-DD", "status": ..., "area": ...}``).
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import date, timedelta
from itertools import pairwise
from typing import Any

from engine.progress import ACTIVE_STATUSES

CONSISTENCY_WINDOW_DAYS = 7
# Quiet days in a row after which the next active day counts as a comeback (matches "lapsed").
COMEBACK_GAP_DAYS = 3
ALL_AREAS: frozenset[str] = frozenset({"movement", "nutrition", "sleep"})

# (cumulative active days needed, milestone id)
CUMULATIVE_MILESTONES: tuple[tuple[int, str], ...] = (
    (1, "first_day"),
    (7, "days_7"),
    (14, "days_14"),
    (30, "days_30"),
    (60, "days_60"),
)

Milestone = dict[str, Any]


def _is_active(entry: Mapping[str, Any], area: str | None) -> bool:
    return entry["status"] in ACTIVE_STATUSES and (area is None or entry["area"] == area)


def active_dates(checkins: Sequence[Mapping[str, Any]], area: str | None = None) -> set[str]:
    """Dates with at least one done or partial mark (optionally for one area)."""
    return {entry["date"] for entry in checkins if _is_active(entry, area)}


def consistency_7d(
    checkins: Sequence[Mapping[str, Any]], current_date: str, area: str | None = None
) -> int:
    """Active days among the last seven (including ``current_date``), from 0 to 7."""
    today = date.fromisoformat(current_date)
    first = (today - timedelta(days=CONSISTENCY_WINDOW_DAYS - 1)).isoformat()
    return sum(1 for day in active_dates(checkins, area) if first <= day <= current_date)


def _all_areas_day(checkins: Sequence[Mapping[str, Any]]) -> str | None:
    areas_by_day: dict[str, set[str]] = {}
    for entry in checkins:
        if _is_active(entry, None):
            areas_by_day.setdefault(entry["date"], set()).add(entry["area"])
    days = sorted(day for day, areas in areas_by_day.items() if areas >= ALL_AREAS)
    return days[0] if days else None


def _first_comeback(days: Sequence[str]) -> str | None:
    """The first active day that follows at least ``COMEBACK_GAP_DAYS`` quiet days."""
    for before, after in pairwise(days):
        quiet_days = (date.fromisoformat(after) - date.fromisoformat(before)).days - 1
        if quiet_days >= COMEBACK_GAP_DAYS:
            return after
    return None


def earned_milestones(
    checkins: Sequence[Mapping[str, Any]], previous: Sequence[Mapping[str, Any]]
) -> list[Milestone]:
    """Every milestone earned so far: ``previous`` is kept, and new ones are added.

    A milestone keeps its earliest earned date, and none is ever dropped, even if the
    check-ins it came from are no longer present.
    """
    earned: dict[str, str] = {m["id"]: m["earned_on"] for m in previous}

    def award(milestone_id: str, on: str | None) -> None:
        if on is not None:
            earned[milestone_id] = min(on, earned.get(milestone_id, on))

    days = sorted(active_dates(checkins))
    for needed, milestone_id in CUMULATIVE_MILESTONES:
        if len(days) >= needed:
            award(milestone_id, days[needed - 1])
    award("all_three_areas_day", _all_areas_day(checkins))
    award("first_comeback", _first_comeback(days))
    return [
        {"id": milestone_id, "earned_on": on}
        for milestone_id, on in sorted(earned.items(), key=lambda item: (item[1], item[0]))
    ]


def next_milestone(cumulative_active_days: int) -> dict[str, Any] | None:
    """The next cumulative milestone and how many more active days it needs, or None at the end."""
    for needed, milestone_id in CUMULATIVE_MILESTONES:
        if needed > cumulative_active_days:
            return {"id": milestone_id, "remaining_active_days": needed - cumulative_active_days}
    return None
