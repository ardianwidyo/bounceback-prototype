"""Pure security, federated identity/MFA, SHA-256 audit hash-chain & ADHICS posture engine (F17).

All functions in this module are pure and deterministic given their explicit inputs.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import re
import uuid
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any, Literal

IdentityProviderLiteral = Literal[
    "entra_external_id",
    "uae_pass",
    "entra_staff_sso",
    "session_secret",
]
FederatedIdentityProviderLiteral = Literal["entra_external_id", "uae_pass"]
IdentityAssuranceLevelLiteral = Literal["sop1", "sop2", "sop3", "enterprise_mfa"]
SecurityRoleLiteral = Literal[
    "participant",
    "coach",
    "clinician",
    "analyst",
    "auditor",
    "admin",
]
AuditActorRoleLiteral = Literal[
    "participant",
    "coach",
    "clinician",
    "analyst",
    "auditor",
    "admin",
    "system",
]
AuditAuthProviderLiteral = Literal[
    "entra_external_id",
    "uae_pass",
    "entra_staff_sso",
    "session_secret",
    "system",
]
AuditEventCategoryLiteral = Literal[
    "personal_data_access",
    "automated_decision",
    "consent_change",
    "auth_event",
    "security_alert",
]
AuditOutcomeLiteral = Literal["allowed", "denied", "error"]

GENESIS_AUDIT_HASH: str = "0" * 64
PILOT_AUDIENCE: str = "bounceback-pilot-uaenorth"

TRUSTED_ISSUERS: dict[str, str] = {
    "entra_external_id": "https://bouncebackuae.ciamlogin.com/uaenorth/v2.0",
    "uae_pass": "https://id.uaepass.ae/idshub",
    "entra_staff_sso": "https://login.microsoftonline.com/uaenorth-doh-staff/v2.0",
}

ROLE_ALLOWED_SCOPES: dict[SecurityRoleLiteral, tuple[str, ...]] = {
    "participant": (
        "self:profile:read",
        "self:profile:write",
        "self:consents:write",
        "self:plans:read_write",
        "self:checkins:read_write",
        "self:export_delete:execute",
    ),
    "coach": (
        "portal:escalation:read",
        "portal:escalation:acknowledge",
        "portal:user_summary:read",
        "portal:message:send",
        "portal:plan_suggestion:create",
    ),
    "clinician": (
        "portal:escalation:read",
        "portal:escalation:acknowledge",
        "portal:escalation:close",
        "portal:user_summary:read",
        "portal:message:send",
        "portal:plan_suggestion:create",
    ),
    "analyst": (
        "analytics:cohort:read",
        "analytics:mrt_report:read",
        "analytics:mrt_export:create",
        "security:posture:read",
    ),
    "auditor": (
        "security:audit:read",
        "security:audit:verify",
        "security:posture:read",
        "portal:audit:read",
    ),
    "admin": (
        "portal:escalation:read",
        "portal:escalation:acknowledge",
        "portal:escalation:close",
        "portal:user_summary:read",
        "portal:message:send",
        "portal:plan_suggestion:create",
        "portal:audit:read",
        "analytics:cohort:read",
        "analytics:mrt_report:read",
        "analytics:mrt_export:create",
        "security:audit:read",
        "security:audit:verify",
        "security:posture:read",
    ),
}

_PSEUDONYM_RE = re.compile(r"^psn_[0-9a-f]{24}$")
_RAW_UUID_RE = re.compile(
    r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b"
)
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_PHONE_RE = re.compile(r"(?:\+\d[\d\s\-]{6,14}\d|\b05\d[\d\s\-]{6,8}\d\b)")
_FORBIDDEN_METADATA_KEYS = frozenset(
    {
        "email",
        "phone",
        "phone_number",
        "full_name",
        "emirates_id",
        "note",
        "trigger_excerpt",
        "raw_user_id",
    }
)


class IdentityVerificationError(ValueError):
    """Raised when an external identity or staff SSO assertion fails validation."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


class AuditPrivacyViolationError(ValueError):
    """Raised when an immutable audit log entry contains cleartext PII or unpseudonymised IDs."""


@dataclass(frozen=True, slots=True)
class VerifiedIdentityClaims:
    provider: Literal["entra_external_id", "uae_pass", "entra_staff_sso"]
    external_subject_id: str
    issuer: str
    audience: str
    role: SecurityRoleLiteral
    assurance_level: IdentityAssuranceLevelLiteral
    mfa_verified: bool
    display_name: str
    token_id: str
    issued_at: datetime
    expires_at: datetime


@dataclass(frozen=True, slots=True)
class RetentionPolicyRule:
    event_category: AuditEventCategoryLiteral
    retention_days: int
    immutable: bool
    regulatory_basis: str


RETENTION_POLICIES: dict[AuditEventCategoryLiteral, RetentionPolicyRule] = {
    "personal_data_access": RetentionPolicyRule(
        event_category="personal_data_access",
        retention_days=1825,
        immutable=True,
        regulatory_basis=(
            "UAE Federal Law No. 2 of 2019 (Art. 13/20) & DoH ADHICS v2 AU-04 (5 years)"
        ),
    ),
    "automated_decision": RetentionPolicyRule(
        event_category="automated_decision",
        retention_days=1825,
        immutable=True,
        regulatory_basis=(
            "BounceBack Constitution Principle III & DoH Abu Dhabi AI Policy (5 years)"
        ),
    ),
    "consent_change": RetentionPolicyRule(
        event_category="consent_change",
        retention_days=1825,
        immutable=True,
        regulatory_basis=(
            "UAE PDPL (Federal Decree-Law No. 45/2021) & DoH ADHICS v2 DP-02 (5 years)"
        ),
    ),
    "auth_event": RetentionPolicyRule(
        event_category="auth_event",
        retention_days=730,
        immutable=True,
        regulatory_basis="DoH ADHICS v2 AC-02 / AU-02 Authentication & Access Trail (2 years)",
    ),
    "security_alert": RetentionPolicyRule(
        event_category="security_alert",
        retention_days=730,
        immutable=True,
        regulatory_basis=(
            "DoH ADHICS v2 IR-02 / OPS-04 SIEM & Security Incident Retention (2 years)"
        ),
    ),
}


@dataclass(frozen=True, slots=True)
class ImmutableAuditEntry:
    sequence_number: int
    recorded_at: datetime
    event_category: AuditEventCategoryLiteral
    action: str
    actor_id_digest: str
    actor_role: AuditActorRoleLiteral
    auth_provider: AuditAuthProviderLiteral
    mfa_verified: bool
    subject_id_digest: str | None
    resource_type: str
    resource_id: str | None
    outcome: AuditOutcomeLiteral
    retention_days: int
    retention_expires_at: datetime
    metadata_json: dict[str, Any]
    previous_hash: str
    entry_hash: str


@dataclass(frozen=True, slots=True)
class AuditChainVerificationResult:
    valid: bool
    checked_entries: int
    genesis_hash: str
    head_hash: str
    first_broken_sequence: int | None
    failure_reason: str | None


@dataclass(frozen=True, slots=True)
class AdhicsControlCheck:
    control_id: str
    domain: str
    title_en: str
    title_ar: str
    status: Literal["verified", "failed"]
    evidence_ref: str


@dataclass(frozen=True, slots=True)
class SecurityPostureReport:
    pilot_ready: bool
    azure_region: str
    data_residency_compliant: bool
    cmk_encryption_at_rest: bool
    cmk_key_id: str
    min_tls_version: Literal["1.2", "1.3"]
    tls_in_transit_compliant: bool
    key_vault_uri: str
    key_vault_secrets_verified: bool
    defender_for_cloud_enabled: bool
    sentinel_siem_enabled: bool
    ci_sast_codeql_configured: bool
    ci_dependency_audit_configured: bool
    threat_model_documented: bool
    dpia_documented: bool
    adhics_mapping_documented: bool
    audit_chain_verification: AuditChainVerificationResult
    adhics_controls: tuple[AdhicsControlCheck, ...]
    pentest_critical_findings: int
    pentest_high_findings: int
    pentest_medium_findings: int
    pentest_low_findings: int
    zero_critical_gate_passed: bool


ADHICS_CONTROL_CATALOGUE: tuple[tuple[str, str, str, str, str], ...] = (
    (
        "ADHICS-IA-01",
        "Identity & Authentication",
        "Participant Federated Sign-In (Microsoft Entra External ID & UAE PASS SOP1-SOP3)",
        "تسجيل دخول المشاركين الموحد عبر الهوية الرقمية UAE PASS وMicrosoft Entra",
        "packages/engine/src/engine/security_compliance.py::verify_identity_assertion",
    ),
    (
        "ADHICS-AC-02",
        "Access Control & MFA",
        "Enterprise Staff SSO with Mandatory Multi-Factor Authentication & 5-Role RBAC",
        "الدخول الموحد للموظفين مع المصادقة متعددة العوامل الإلزامية والتحكم بالأدوار",
        "services/api/src/api/routes/security.py::verify_staff_sso_session",
    ),
    (
        "ADHICS-DP-01",
        "Data Residency (UAE Federal Law No. 2/2019)",
        "Strict Health & Behaviour Data Residency in Azure UAE North (uaenorth)",
        "إقامة البيانات الصحية والسلوكية حصرياً داخل دولة الإمارات (uaenorth)",
        "infra/bicep/main.bicep::location",
    ),
    (
        "ADHICS-CR-01",
        "Cryptography At Rest",
        "Encryption at Rest with Customer-Managed Keys (CMK) in Azure Key Vault",
        "تشفير البيانات المخزنة باستخدام مفاتيح يديرها العميل (CMK) في Key Vault",
        "infra/bicep/main.bicep::cmkKey",
    ),
    (
        "ADHICS-CR-02",
        "Cryptography In Transit",
        "TLS 1.2+ Enforcement & Strict Transport Security Headers",
        "فرض بروتوكول TLS 1.2+ وترويسات أمان النقل الصارمة",
        "services/api/src/api/security_headers.py::SecurityHeadersMiddleware",
    ),
    (
        "ADHICS-CR-03",
        "Key & Secret Management",
        "Centralised Secret Storage in Azure Key Vault with Purge Protection",
        "إدارة الأسرار والمفاتيح مركزياً في Key Vault مع الحماية من الحذف النهائي",
        "services/api/src/api/key_vault.py::KeyVaultSecretProvider",
    ),
    (
        "ADHICS-AU-01",
        "Audit & Accountability",
        "Immutable SHA-256 Hash-Chained Audit Log for Data Access & Automated Decisions",
        "سجل تدقيق غير قابل للتعديل مرتبط بسلسلة تجزئة SHA-256 للبيانات والقرارات الآلية",
        "packages/engine/src/engine/security_compliance.py::verify_audit_hash_chain",
    ),
    (
        "ADHICS-AU-04",
        "Audit Retention Governance",
        "5-Year (1,825 Days) Statutory Retention for Health Data & Decision Logs",
        "الاحتفاظ القانوني بسجلات التدقيق لمدة 5 سنوات (1825 يوماً)",
        "packages/engine/src/engine/security_compliance.py::RETENTION_POLICIES",
    ),
    (
        "ADHICS-OPS-04",
        "Cloud Security Posture & SIEM",
        "Microsoft Defender for Cloud & Microsoft Sentinel Monitoring in UAE North",
        "مراقبة السحابة والحوادث الأمنية عبر Defender for Cloud وMicrosoft Sentinel",
        "infra/bicep/main.bicep::sentinelSolution",
    ),
    (
        "ADHICS-SD-03",
        "Secure Development & Vulnerability Management",
        (
            "Automated SAST (CodeQL), Dependency Auditing (pip-audit, pnpm audit) "
            "& Zero-Critical Pen-Test Gate"
        ),
        "الفحص الأمني الآلي للكود والاعتماديات وبوابة عدم وجود ثغرات حرجة قبل الإطلاق",
        ".github/workflows/security.yml",
    ),
)


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64url_decode(segment: str) -> bytes:
    padding = "=" * (-len(segment) % 4)
    return base64.urlsafe_b64decode(segment + padding)


def resolve_allowed_scopes_for_role(role: SecurityRoleLiteral) -> tuple[str, ...]:
    """Return the deterministic permission scopes granted to ``role``."""
    return ROLE_ALLOWED_SCOPES[role]


def mint_signed_identity_assertion(
    *,
    provider: Literal["entra_external_id", "uae_pass", "entra_staff_sso"],
    external_subject_id: str,
    role: SecurityRoleLiteral,
    assurance_level: IdentityAssuranceLevelLiteral,
    mfa_verified: bool,
    display_name: str,
    signing_key: str,
    issued_at: datetime | None = None,
    ttl_seconds: int = 3600,
    issuer: str | None = None,
    audience: str = PILOT_AUDIENCE,
    token_id: str | None = None,
) -> str:
    """Create a compact HMAC-SHA256 signed assertion for Entra, UAE PASS, or Staff SSO."""
    now = (issued_at or datetime.now(UTC)).astimezone(UTC)
    exp = now + timedelta(seconds=ttl_seconds)
    resolved_issuer = issuer or TRUSTED_ISSUERS[provider]
    jti = token_id or f"jti-{uuid.uuid4().hex[:16]}"
    header = {"alg": "HS256", "typ": "JWT", "prv": provider}
    payload = {
        "iss": resolved_issuer,
        "aud": audience,
        "sub": external_subject_id,
        "prv": provider,
        "role": role,
        "acr": assurance_level,
        "amr": ["pwd", "mfa"] if mfa_verified else ["pwd"],
        "mfa_verified": bool(mfa_verified),
        "name": display_name,
        "jti": jti,
        "iat": int(now.timestamp()),
        "exp": int(exp.timestamp()),
    }
    header_b64 = _b64url_encode(
        json.dumps(header, separators=(",", ":"), sort_keys=True).encode("utf-8")
    )
    payload_b64 = _b64url_encode(
        json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    )
    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    sig = hmac.new(signing_key.encode("utf-8"), signing_input, hashlib.sha256).digest()
    sig_b64 = _b64url_encode(sig)
    return f"{header_b64}.{payload_b64}.{sig_b64}"


def verify_identity_assertion(
    assertion: str,
    *,
    expected_provider: Literal["entra_external_id", "uae_pass", "entra_staff_sso"] | None = None,
    signing_key: str,
    now: datetime | None = None,
    require_mfa: bool = False,
    expected_audience: str = PILOT_AUDIENCE,
    seen_token_ids: set[str] | frozenset[str] | None = None,
) -> VerifiedIdentityClaims:
    """Verify signature, issuer, audience, expiry, replay token ID, and MFA claim."""
    parts = assertion.strip().split(".")
    if len(parts) != 3:
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Malformed identity assertion.",
        )
    header_b64, payload_b64, sig_b64 = parts
    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    expected_sig = _b64url_encode(
        hmac.new(signing_key.encode("utf-8"), signing_input, hashlib.sha256).digest()
    )
    if not hmac.compare_digest(expected_sig, sig_b64):
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Invalid identity assertion signature.",
        )
    try:
        payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
    except Exception as exc:
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Invalid identity assertion payload.",
        ) from exc

    if not isinstance(payload, dict):
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Identity assertion payload must be a JSON object.",
        )

    provider = str(payload.get("prv") or "")
    if provider not in TRUSTED_ISSUERS:
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Unsupported identity provider.",
        )
    if expected_provider is not None and provider != expected_provider:
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Assertion provider does not match requested provider.",
        )

    issuer = str(payload.get("iss") or "")
    if issuer != TRUSTED_ISSUERS[provider]:
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Untrusted identity issuer.",
        )

    audience = str(payload.get("aud") or "")
    if audience != expected_audience:
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Invalid identity audience.",
        )

    token_id = str(payload.get("jti") or "").strip()
    if not token_id or (seen_token_ids is not None and token_id in seen_token_ids):
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Replayed or missing token identifier.",
        )

    effective_now = (now or datetime.now(UTC)).astimezone(UTC)
    iat_ts = int(payload.get("iat") or 0)
    exp_ts = int(payload.get("exp") or 0)
    if exp_ts <= int(effective_now.timestamp()):
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Identity assertion has expired.",
        )

    subject_id = str(payload.get("sub") or "").strip()
    if not subject_id or len(subject_id) > 128:
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Missing or invalid subject identifier.",
        )

    role_raw = str(payload.get("role") or "")
    if role_raw not in ROLE_ALLOWED_SCOPES:
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Unrecognised security role in assertion.",
        )
    role: SecurityRoleLiteral = role_raw

    acr_raw = str(payload.get("acr") or "sop2")
    if acr_raw not in ("sop1", "sop2", "sop3", "enterprise_mfa"):
        raise IdentityVerificationError(
            "invalid_identity_token",
            "Unsupported assurance level.",
        )
    assurance_level: IdentityAssuranceLevelLiteral = acr_raw  # type: ignore[assignment]

    amr = payload.get("amr")
    mfa_claim = bool(payload.get("mfa_verified")) or (isinstance(amr, list) and "mfa" in amr)
    if require_mfa and not mfa_claim:
        raise IdentityVerificationError(
            "mfa_required",
            "Multi-factor authentication (MFA) is required for staff access.",
        )

    display_name = str(payload.get("name") or "Verified User").strip() or "Verified User"
    typed_provider: Literal["entra_external_id", "uae_pass", "entra_staff_sso"] = provider  # type: ignore[assignment]
    return VerifiedIdentityClaims(
        provider=typed_provider,
        external_subject_id=subject_id,
        issuer=issuer,
        audience=audience,
        role=role,
        assurance_level=assurance_level,
        mfa_verified=mfa_claim,
        display_name=display_name,
        token_id=token_id,
        issued_at=datetime.fromtimestamp(iat_ts, tz=UTC),
        expires_at=datetime.fromtimestamp(exp_ts, tz=UTC),
    )


def _validate_audit_privacy(
    subject_id_digest: str | None,
    metadata_json: Mapping[str, Any],
) -> None:
    if subject_id_digest is not None and not _PSEUDONYM_RE.fullmatch(subject_id_digest):
        raise AuditPrivacyViolationError(
            "subject_id_digest must be None or a keyed pseudonym matching ^psn_[0-9a-f]{24}$."
        )
    for key in metadata_json:
        if str(key).lower() in _FORBIDDEN_METADATA_KEYS:
            raise AuditPrivacyViolationError(
                f"Forbidden PII metadata key '{key}' in immutable audit log."
            )
    serialized = json.dumps(dict(metadata_json), sort_keys=True, default=str)
    if _RAW_UUID_RE.search(serialized):
        raise AuditPrivacyViolationError("Raw UUID detected in immutable audit metadata.")
    if _EMAIL_RE.search(serialized):
        raise AuditPrivacyViolationError("Email address detected in immutable audit metadata.")
    if _PHONE_RE.search(serialized):
        raise AuditPrivacyViolationError("Phone number detected in immutable audit metadata.")


def compute_audit_entry_hash(
    *,
    sequence_number: int,
    recorded_at: datetime,
    event_category: AuditEventCategoryLiteral,
    action: str,
    actor_id_digest: str,
    actor_role: AuditActorRoleLiteral,
    auth_provider: AuditAuthProviderLiteral,
    mfa_verified: bool,
    subject_id_digest: str | None,
    resource_type: str,
    resource_id: str | None,
    outcome: AuditOutcomeLiteral,
    retention_days: int,
    metadata_json: Mapping[str, Any],
    previous_hash: str,
) -> str:
    """Compute canonical SHA-256 hex digest chaining ``previous_hash`` and entry fields."""
    recorded_utc = recorded_at.astimezone(UTC).isoformat()
    canonical = {
        "sequence_number": int(sequence_number),
        "recorded_at": recorded_utc,
        "event_category": event_category,
        "action": action,
        "actor_id_digest": actor_id_digest,
        "actor_role": actor_role,
        "auth_provider": auth_provider,
        "mfa_verified": bool(mfa_verified),
        "subject_id_digest": subject_id_digest,
        "resource_type": resource_type,
        "resource_id": resource_id,
        "outcome": outcome,
        "retention_days": int(retention_days),
        "metadata_json": dict(metadata_json),
        "previous_hash": previous_hash,
    }
    raw = json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def build_immutable_audit_entry(
    *,
    sequence_number: int,
    recorded_at: datetime,
    event_category: AuditEventCategoryLiteral,
    action: str,
    actor_id_digest: str,
    actor_role: AuditActorRoleLiteral,
    auth_provider: AuditAuthProviderLiteral,
    mfa_verified: bool,
    subject_id_digest: str | None,
    resource_type: str,
    resource_id: str | None,
    outcome: AuditOutcomeLiteral,
    metadata_json: Mapping[str, Any] | None = None,
    previous_hash: str = GENESIS_AUDIT_HASH,
) -> ImmutableAuditEntry:
    """Construct a PII-validated, SHA-256 hash-chained immutable audit entry."""
    if sequence_number < 1:
        raise ValueError("sequence_number must be >= 1.")
    clean_meta = dict(metadata_json or {})
    _validate_audit_privacy(subject_id_digest, clean_meta)
    rule = RETENTION_POLICIES[event_category]
    rec_utc = recorded_at.astimezone(UTC)
    expires_at = rec_utc + timedelta(days=rule.retention_days)
    entry_hash = compute_audit_entry_hash(
        sequence_number=sequence_number,
        recorded_at=rec_utc,
        event_category=event_category,
        action=action,
        actor_id_digest=actor_id_digest,
        actor_role=actor_role,
        auth_provider=auth_provider,
        mfa_verified=mfa_verified,
        subject_id_digest=subject_id_digest,
        resource_type=resource_type,
        resource_id=resource_id,
        outcome=outcome,
        retention_days=rule.retention_days,
        metadata_json=clean_meta,
        previous_hash=previous_hash,
    )
    return ImmutableAuditEntry(
        sequence_number=sequence_number,
        recorded_at=rec_utc,
        event_category=event_category,
        action=action,
        actor_id_digest=actor_id_digest,
        actor_role=actor_role,
        auth_provider=auth_provider,
        mfa_verified=mfa_verified,
        subject_id_digest=subject_id_digest,
        resource_type=resource_type,
        resource_id=resource_id,
        outcome=outcome,
        retention_days=rule.retention_days,
        retention_expires_at=expires_at,
        metadata_json=clean_meta,
        previous_hash=previous_hash,
        entry_hash=entry_hash,
    )


def verify_audit_hash_chain(
    entries: Sequence[ImmutableAuditEntry],
) -> AuditChainVerificationResult:
    """Recompute and verify cryptographic hash continuity across ordered ``entries``."""
    if not entries:
        return AuditChainVerificationResult(
            valid=True,
            checked_entries=0,
            genesis_hash=GENESIS_AUDIT_HASH,
            head_hash=GENESIS_AUDIT_HASH,
            first_broken_sequence=None,
            failure_reason=None,
        )

    expected_prev = GENESIS_AUDIT_HASH
    for idx, entry in enumerate(entries, start=1):
        if entry.sequence_number != idx:
            return AuditChainVerificationResult(
                valid=False,
                checked_entries=idx - 1,
                genesis_hash=GENESIS_AUDIT_HASH,
                head_hash=expected_prev,
                first_broken_sequence=entry.sequence_number,
                failure_reason=(
                    f"Sequence gap or out-of-order entry: expected {idx}, "
                    f"got {entry.sequence_number}."
                ),
            )
        if not hmac.compare_digest(entry.previous_hash, expected_prev):
            return AuditChainVerificationResult(
                valid=False,
                checked_entries=idx - 1,
                genesis_hash=GENESIS_AUDIT_HASH,
                head_hash=expected_prev,
                first_broken_sequence=entry.sequence_number,
                failure_reason=(f"Broken previous_hash link at sequence {entry.sequence_number}."),
            )
        recomputed = compute_audit_entry_hash(
            sequence_number=entry.sequence_number,
            recorded_at=entry.recorded_at,
            event_category=entry.event_category,
            action=entry.action,
            actor_id_digest=entry.actor_id_digest,
            actor_role=entry.actor_role,
            auth_provider=entry.auth_provider,
            mfa_verified=entry.mfa_verified,
            subject_id_digest=entry.subject_id_digest,
            resource_type=entry.resource_type,
            resource_id=entry.resource_id,
            outcome=entry.outcome,
            retention_days=entry.retention_days,
            metadata_json=entry.metadata_json,
            previous_hash=entry.previous_hash,
        )
        if not hmac.compare_digest(recomputed, entry.entry_hash):
            return AuditChainVerificationResult(
                valid=False,
                checked_entries=idx - 1,
                genesis_hash=GENESIS_AUDIT_HASH,
                head_hash=expected_prev,
                first_broken_sequence=entry.sequence_number,
                failure_reason=(
                    f"Tampered entry_hash mismatch at sequence {entry.sequence_number}."
                ),
            )
        expected_prev = entry.entry_hash

    return AuditChainVerificationResult(
        valid=True,
        checked_entries=len(entries),
        genesis_hash=GENESIS_AUDIT_HASH,
        head_hash=expected_prev,
        first_broken_sequence=None,
        failure_reason=None,
    )


def evaluate_security_posture(
    *,
    azure_region: str,
    cmk_key_id: str,
    min_tls_version: str,
    key_vault_uri: str,
    key_vault_secrets_verified: bool,
    defender_for_cloud_enabled: bool,
    sentinel_siem_enabled: bool,
    ci_sast_codeql_configured: bool,
    ci_dependency_audit_configured: bool,
    threat_model_documented: bool,
    dpia_documented: bool,
    adhics_mapping_documented: bool,
    audit_chain_verification: AuditChainVerificationResult,
    pentest_critical_findings: int = 0,
    pentest_high_findings: int = 0,
    pentest_medium_findings: int = 0,
    pentest_low_findings: int = 0,
) -> SecurityPostureReport:
    """Evaluate UAE North residency, CMK, TLS 1.2+, Key Vault, ADHICS & zero-critical gate."""
    residency_ok = azure_region.strip().lower() == "uaenorth"
    cmk_ok = (
        bool(cmk_key_id.strip()) and cmk_key_id.startswith("https://") and "/keys/" in cmk_key_id
    )
    tls_ok = min_tls_version in ("1.2", "1.3")
    typed_tls: Literal["1.2", "1.3"] = "1.3" if min_tls_version == "1.3" else "1.2"
    kv_ok = (
        bool(key_vault_uri.strip())
        and key_vault_uri.startswith("https://")
        and key_vault_secrets_verified
    )
    zero_crit_ok = pentest_critical_findings == 0 and pentest_high_findings == 0

    control_status_map: dict[str, bool] = {
        "ADHICS-IA-01": True,
        "ADHICS-AC-02": True,
        "ADHICS-DP-01": residency_ok,
        "ADHICS-CR-01": cmk_ok,
        "ADHICS-CR-02": tls_ok,
        "ADHICS-CR-03": kv_ok,
        "ADHICS-AU-01": audit_chain_verification.valid,
        "ADHICS-AU-04": True,
        "ADHICS-OPS-04": defender_for_cloud_enabled and sentinel_siem_enabled,
        "ADHICS-SD-03": (
            ci_sast_codeql_configured
            and ci_dependency_audit_configured
            and zero_crit_ok
            and threat_model_documented
            and dpia_documented
            and adhics_mapping_documented
        ),
    }

    controls = tuple(
        AdhicsControlCheck(
            control_id=cid,
            domain=domain,
            title_en=title_en,
            title_ar=title_ar,
            status="verified" if control_status_map.get(cid, False) else "failed",
            evidence_ref=evidence_ref,
        )
        for cid, domain, title_en, title_ar, evidence_ref in ADHICS_CONTROL_CATALOGUE
    )

    pilot_ready = (
        residency_ok
        and cmk_ok
        and tls_ok
        and kv_ok
        and defender_for_cloud_enabled
        and sentinel_siem_enabled
        and ci_sast_codeql_configured
        and ci_dependency_audit_configured
        and threat_model_documented
        and dpia_documented
        and adhics_mapping_documented
        and audit_chain_verification.valid
        and zero_crit_ok
        and all(c.status == "verified" for c in controls)
    )

    return SecurityPostureReport(
        pilot_ready=pilot_ready,
        azure_region=azure_region,
        data_residency_compliant=residency_ok,
        cmk_encryption_at_rest=cmk_ok,
        cmk_key_id=cmk_key_id,
        min_tls_version=typed_tls,
        tls_in_transit_compliant=tls_ok,
        key_vault_uri=key_vault_uri,
        key_vault_secrets_verified=kv_ok,
        defender_for_cloud_enabled=defender_for_cloud_enabled,
        sentinel_siem_enabled=sentinel_siem_enabled,
        ci_sast_codeql_configured=ci_sast_codeql_configured,
        ci_dependency_audit_configured=ci_dependency_audit_configured,
        threat_model_documented=threat_model_documented,
        dpia_documented=dpia_documented,
        adhics_mapping_documented=adhics_mapping_documented,
        audit_chain_verification=audit_chain_verification,
        adhics_controls=controls,
        pentest_critical_findings=pentest_critical_findings,
        pentest_high_findings=pentest_high_findings,
        pentest_medium_findings=pentest_medium_findings,
        pentest_low_findings=pentest_low_findings,
        zero_critical_gate_passed=zero_crit_ok,
    )
