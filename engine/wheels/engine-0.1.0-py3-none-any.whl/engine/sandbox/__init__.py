"""Pure session layer for the on-device interactive prototype (spec 023).

``apply(state, command)`` takes a SandboxState dict and one command and returns a new state plus
events. It never mutates its input, never reads the wall clock and never uses global randomness.
"""

from engine.sandbox import (
    checkin,
    commands,
    consent,
    proposals,
    recovery_flow,
    setup,
    timeline,
    walkthrough,
)
from engine.sandbox.commands import apply
from engine.sandbox.library import configure
from engine.sandbox.state import SandboxError

# Each module owns the handlers for its commands; registering them here keeps `apply` complete.
commands.HANDLERS.update(setup.HANDLERS)
commands.HANDLERS.update(checkin.HANDLERS)
commands.HANDLERS.update(timeline.HANDLERS)
commands.HANDLERS.update(recovery_flow.HANDLERS)
commands.HANDLERS.update(proposals.HANDLERS)
commands.HANDLERS.update(consent.HANDLERS)
commands.HANDLERS.update(walkthrough.HANDLERS)

__all__ = ["SandboxError", "apply", "configure"]
