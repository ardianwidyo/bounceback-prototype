"""Embedded two-sided 95 % Student t critical values (F21 research R5; no scipy dependency).

k ≥ 20 guarantees df ≥ 19. A df between table rows uses the next-lower row, which gives a
slightly wider (conservative) interval and stays deterministic.
"""

from __future__ import annotations

import math
from typing import Final

_T_TABLE_95: Final = (
    (19, 2.093),
    (20, 2.086),
    (21, 2.080),
    (22, 2.074),
    (23, 2.069),
    (24, 2.064),
    (25, 2.060),
    (26, 2.056),
    (27, 2.052),
    (28, 2.048),
    (29, 2.045),
    (30, 2.042),
    (40, 2.021),
    (60, 2.000),
    (120, 1.980),
)
_T_INFINITY: Final = 1.960
_INFINITY_DF: Final = 1_000_000


def t_critical_95(df: int) -> float:
    if df < _T_TABLE_95[0][0]:
        raise ValueError("df below 19 is never used: cells with fewer than 20 are suppressed")
    if df >= _INFINITY_DF:
        return _T_INFINITY
    return [value for row_df, value in _T_TABLE_95 if row_df <= df][-1]


def mean_and_ci95(values: list[float]) -> tuple[float, float, float]:
    """Sample mean with a 95 % t interval; requires at least 20 values."""
    n = len(values)
    mean = math.fsum(values) / n
    variance = math.fsum((v - mean) ** 2 for v in values) / (n - 1)
    half = t_critical_95(n - 1) * math.sqrt(variance / n)
    return mean, mean - half, mean + half
