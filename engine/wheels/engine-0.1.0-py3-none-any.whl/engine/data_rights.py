"""Pure, deterministic engine for F19 Self-Service Data Rights (`019-data-rights`).

Provides:
- Canonical 18-category Personal Data Inventory Registry across `primary_db`,
  `analytics_store`, and `audit_logs`
- Chronological consent history builder across data-source and human-support consents
- Human- and machine-readable JSON export (`data-export-v2` with data dictionary)
  and unified UTF-8 CSV export
- Short-lived HMAC-SHA256 signed download token generation and constant-time
  verification (`15-minute` TTL)
- Post-deletion zero-residual verification evaluator and structured
  `DeletionConfirmationReceipt` builder
"""

from __future__ import annotations

import csv
import hashlib
import hmac
import io
import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from engine.biomarkers.export import write_biomarker_csv_rows

DataStoreLiteral = Literal["primary_db", "analytics_store", "audit_logs"]
DeletionModeLiteral = Literal["hard_delete", "irreversible_anonymise"]
ExportFormatLiteral = Literal["json", "csv"]

EXPORT_SCHEMA_VERSION = "data-export-v2"
EXPORT_SIGNED_URL_TTL_SECONDS = 900  # 15 minutes
EXPORT_COMPLETION_SLA_SECONDS = 300  # < 5 minutes SLA

PRIMARY_RETENTION_EN = (
    "Kept while your account is active and permanently removed immediately "
    "when you delete your account."
)
PRIMARY_RETENTION_AR = "يُحتفظ بها طالما أن حسابك نشط، وتُحذف نهائياً وفوراً عند طلب حذف حسابك."

CONFIRMATION_MESSAGE_EN = (
    "Your BounceBack account and personal records have been removed. "
    "Statutory security and research audit entries have been irreversibly anonymised "
    "according to UAE health-data retention rules."
)
CONFIRMATION_MESSAGE_AR = (
    "تم حذف حسابك وسجلاتك الشخصية في BounceBack بالكامل. "
    "وتم إخفاء هوية سجلات التدقيق والأبحاث الإلزامية بشكل غير قابل للعكس "
    "وفقاً لقواعد حفظ البيانات الصحية في دولة الإمارات."
)

RETENTION_POLICY_SUMMARY_EN = (
    "All 15 personal data categories in the primary database are permanently deleted "
    "immediately. Analytics research records are suppressed via an irreversible "
    "pseudonymous digest (psn_<hash>), and statutory security audit logs retain only "
    "non-identifiable digests for 1,825 days (5 years) under UAE Federal Law No. 2 of 2019 "
    "and DoH ADHICS v2."
)
RETENTION_POLICY_SUMMARY_AR = (
    "يتم حذف جميع فئات البيانات الشخصية الخمس عشرة في قاعدة البيانات الأساسية نهائياً وفوراً. "
    "وتُستبعد سجلات تحليلات الأبحاث عبر معرّف مستعار غير قابل للعكس (psn_<hash>)، "
    "بينما تحتفظ سجلات التدقيق الأمني القانونية بالمعرّفات غير القابلة للتعريف فقط "
    "لمدة 1825 يوماً (5 سنوات) وفقاً للقانون الاتحادي الإماراتي رقم 2 لسنة 2019 ومعايير ADHICS v2."
)


class ExportTokenError(ValueError):
    """Base error for signed export download tokens."""


class ExportTokenInvalidError(ExportTokenError):
    """Raised when a signed export download token is malformed or fails HMAC verification."""


class ExportTokenExpiredError(ExportTokenError):
    """Raised when a signed export download token is past its expiration timestamp."""


@dataclass(frozen=True)
class DataInventoryCategory:
    """Single category entry in the Personal Data Inventory Registry."""

    category_id: str
    store: DataStoreLiteral
    table_names: tuple[str, ...]
    title_en: str
    title_ar: str
    purpose_en: str
    purpose_ar: str
    personal_fields: tuple[str, ...]
    deletion_mode: DeletionModeLiteral
    retention_days: int | None
    retention_policy_en: str
    retention_policy_ar: str


PERSONAL_DATA_INVENTORY_REGISTRY: tuple[DataInventoryCategory, ...] = (
    DataInventoryCategory(
        category_id="user_profile",
        store="primary_db",
        table_names=("users",),
        title_en="Profile & Accessibility Preferences",
        title_ar="الملف الشخصي وتفضيلات إمكانية الوصول",
        purpose_en=(
            "Stores your chosen language, timezone, text size, high contrast, "
            "and voice-friendly preferences."
        ),
        purpose_ar=(
            "يحفظ اللغة المختارة والمنطقة الزمنية وحجم النص والتباين العالي والوضع الصوتي المريح."
        ),
        personal_fields=(
            "id",
            "locale",
            "timezone",
            "text_scale",
            "high_contrast",
            "voice_friendly",
            "onboarding_step",
            "onboarding_completed_at",
            "created_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="weekly_context",
        store="primary_db",
        table_names=("user_contexts",),
        title_en="Weekly Schedule, Context & Notification Preferences",
        title_ar="الجدول الأسبوعي والسياق وتفضيلات الإشعارات",
        purpose_en=(
            "Fits suggestions around your work shifts, days off, Ramadan mode, "
            "quiet hours, preferred channel, and pause window."
        ),
        purpose_ar=(
            "يوائم الاقتراحات مع نوبات العمل وأيام الراحة ووضع رمضان وساعات الهدوء "
            "والقناة المفضلة وفترة التوقف المؤقت."
        ),
        personal_fields=(
            "user_id",
            "work_pattern",
            "days_off",
            "days_off_varies",
            "barriers",
            "ramadan_mode",
            "preferred_channel",
            "quiet_start",
            "quiet_end",
            "daily_notification_budget",
            "paused_until",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="consent_history",
        store="primary_db",
        table_names=("consent_records",),
        title_en="Consent Decisions & Full Chronological History",
        title_ar="قرارات الموافقة والسجل الزمني الكامل",
        purpose_en=(
            "Records every permission you grant or withdraw per data source and purpose "
            "with the exact wording version shown."
        ),
        purpose_ar=(
            "يوثّق كل موافقة تمنحها أو تسحبها لكل مصدر بيانات وغرض مع إصدار النص المعروض وقت القرار."
        ),
        personal_fields=(
            "user_id",
            "source",
            "purpose",
            "allowed",
            "wording_version",
            "decided_at",
            "recorded_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="goals_and_readiness",
        store="primary_db",
        table_names=("user_goals",),
        title_en="Selected Goals, Personal Why & Readiness",
        title_ar="الأهداف المختارة والدافع الشخصي ومستوى الاستعداد",
        purpose_en=(
            "Stores up to two chosen health areas, your personal reason, and "
            "capability/opportunity/motivation readiness ratings."
        ),
        purpose_ar=(
            "يحفظ ما يصل إلى مجالين صحيين مختارين وسببك الشخصي وتقييم الاستعداد لبناء خطة مناسبة."
        ),
        personal_fields=(
            "user_id",
            "behaviours",
            "why",
            "comb_capability",
            "comb_opportunity",
            "comb_motivation",
            "start_level",
            "updated_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="habit_plans",
        store="primary_db",
        table_names=("plans", "plan_versions", "planned_actions"),
        title_en="If-Then Habit Plans & Version History",
        title_ar="خطط العادات اليومية وسجل الإصدارات",
        purpose_en=(
            "Keeps your active 2 to 10 minute if-then micro-actions and previous plan versions."
        ),
        purpose_ar="يحفظ خطواتك اليومية القصيرة بصيغة إذا-فإن وسجل إصدارات خطتك.",
        personal_fields=(
            "user_id",
            "plan_id",
            "version",
            "created_by",
            "source",
            "reason",
            "action_id",
            "cue_en",
            "cue_ar",
            "if_then_en",
            "if_then_ar",
            "created_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="daily_checkins",
        store="primary_db",
        table_names=("checkins",),
        title_en="Daily Check-Ins, Effort & Cumulative Active Days",
        title_ar="المتابعات اليومية ومستوى الجهد والأيام النشطة التراكمية",
        purpose_en=(
            "Tracks completed, partial, or skipped micro-actions, optional effort ratings, "
            "and notes to protect your cumulative active days."
        ),
        purpose_ar=(
            "يتابع الخطوات المنجزة أو الجزئية أو المتخطاة وتقييم الجهد الاختياري والملاحظات "
            "لحفظ أيامك النشطة التراكمية."
        ),
        personal_fields=(
            "id",
            "user_id",
            "slot_id",
            "action_id",
            "local_date",
            "status",
            "effort",
            "note",
            "decided_at",
            "recorded_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="passive_signals",
        store="primary_db",
        table_names=("user_signals",),
        title_en="Consented Passive Activity Signals",
        title_ar="إشارات النشاط التلقائية المصرّح بها",
        purpose_en=(
            "Stores daily step counts or wearable signals only when you have explicitly "
            "turned on that data source."
        ),
        purpose_ar=(
            "يحفظ عدد الخطوات اليومية أو إشارات الأجهزة القابلة للارتداء فقط عند تفعيل الموافقة "
            "على هذا المصدر."
        ),
        personal_fields=(
            "id",
            "user_id",
            "local_date",
            "signal_type",
            "value_int",
            "source",
            "recorded_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="adaptive_decisions",
        store="primary_db",
        table_names=("engine_decision_logs", "selector_decision_states", "arm_stats"),
        title_en="Adaptive Suggestion Decisions & Timing Preferences",
        title_ar="قرارات الاقتراحات التكيفية وتفضيلات التوقيت",
        purpose_en=(
            "Logs why each micro-action, time window, and channel was selected so every "
            "suggestion is explainable."
        ),
        purpose_ar=(
            "يسجل سبب اختيار كل خطوة وفترة زمنية وقناة تواصل ليكون كل اقتراح واضحاً وقابلاً للتفسير."
        ),
        personal_fields=(
            "id",
            "user_id",
            "policy_version",
            "decision_type",
            "inputs_used",
            "chosen_actions",
            "propensities",
            "created_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="lapse_and_recovery",
        store="primary_db",
        table_names=("lapse_event",),
        title_en="Quiet-Period Recovery Episodes",
        title_ar="فترات التوقف المؤقت وخطط العودة الميسّرة",
        purpose_en=(
            "Helps offer a lighter, smaller step when life gets busy without ever "
            "resetting your progress."
        ),
        purpose_ar="يساعد على تقديم خطوة أخف وأصغر عند انشغال يومك دون إعادة تقدمك إلى الصفر أبداً.",
        personal_fields=(
            "id",
            "user_id",
            "local_date",
            "state",
            "reasons",
            "barrier",
            "recovery_plan_version",
            "resolved_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="coach_conversations",
        store="primary_db",
        table_names=("messages",),
        title_en="Conversational Coach Messages",
        title_ar="رسائل المحادثة مع المرافق الذكي",
        purpose_en=(
            "Stores messages exchanged with the BounceBack coach so you can review "
            "past support conversations."
        ),
        purpose_ar=(
            "يحفظ الرسائل المتبادلة مع المرافق الذكي لتتمكن من مراجعة محادثات الدعم السابقة."
        ),
        personal_fields=(
            "id",
            "user_id",
            "role",
            "channel",
            "locale",
            "content",
            "suggested_barrier",
            "created_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="policy_and_safety",
        store="primary_db",
        table_names=("policy_audit_logs", "red_flag_escalations"),
        title_en="Safety Guardrail & Red-Flag Escalation Records",
        title_ar="سجلات ضوابط السلامة وطلبات المساندة الصحية",
        purpose_en=(
            "Records heat/fasting safety adjustments and urgent human-support escalations "
            "when health red flags appear."
        ),
        purpose_ar=(
            "يسجل تعديلات السلامة الخاصة بالحرارة أو الصيام وطلبات المساندة البشرية العاجلة "
            "عند ظهور مؤشرات صحية طارئة."
        ),
        personal_fields=(
            "id",
            "user_id",
            "scope",
            "verdict",
            "rule_ids",
            "category",
            "status",
            "created_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="social_and_points",
        store="primary_db",
        table_names=(
            "pod_member",
            "buddy_link",
            "team_member",
            "points_ledger",
            "workplace_employee_enrollment",
        ),
        title_en="Peer Pod, Buddy Link, Workplace Team & Recognition Points",
        title_ar="مجموعات المساندة والرفيق وفريق العمل ونقاط التقدير",
        purpose_en=(
            "Manages opt-in peer pods, family/friend buddy sharing, anonymous workplace "
            "team participation, and positive recognition points."
        ),
        purpose_ar=(
            "يدير المشاركة الاختيارية في مجموعات المساندة ومشاركة الرفيق وتحديات فريق العمل "
            "ونقاط التقدير الإيجابية."
        ),
        personal_fields=(
            "user_id",
            "pod_id",
            "buddy_display_name",
            "relationship_label",
            "scopes",
            "team_id",
            "event_type",
            "points_delta",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="human_support_and_suggestions",
        store="primary_db",
        table_names=("human_support_consents", "plan_suggestions"),
        title_en="Human Coach Support Consent & Plan Suggestions",
        title_ar="موافقة مساندة المدرب البشري ومقترحات الخطة",
        purpose_en=(
            "Controls whether a human coach or clinician can view your summary and "
            "propose optional plan adjustments."
        ),
        purpose_ar=(
            "يتحكم في السماح للمدرب البشري أو المختص بالاطلاع على ملخصك واقتراح تعديلات "
            "اختيارية على خطتك."
        ),
        personal_fields=(
            "user_id",
            "allowed",
            "decided_at",
            "proposer_role",
            "target_action_id",
            "approved_level",
            "status",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="questionnaires",
        store="primary_db",
        table_names=("questionnaire_responses",),
        title_en="Short Wellness Check-In Questionnaires",
        title_ar="الاستبيانات الصحية القصيرة",
        purpose_en=(
            "Stores optional milestone check-in responses for sleep, nutrition, "
            "and autonomy support."
        ),
        purpose_ar="يحفظ إجابات الاستبيانات المرحلية الاختيارية للنوم والتغذية ودعم الاستقلالية.",
        personal_fields=(
            "id",
            "user_id",
            "instrument_id",
            "milestone",
            "status",
            "answers",
            "raw_score",
            "normalized_score",
            "responded_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="identity_bindings",
        store="primary_db",
        table_names=("external_identity_bindings",),
        title_en="Linked Digital Identity Providers (UAE PASS / Entra External ID)",
        title_ar="روابط الهوية الرقمية (الهوية الرقمية UAE PASS / Entra)",
        purpose_en=(
            "Links your verified sign-in provider to your BounceBack profile across devices."
        ),
        purpose_ar="يربط مزود تسجيل الدخول الموثّق بملفك الشخصي في BounceBack عبر أجهزتك.",
        personal_fields=(
            "id",
            "user_id",
            "provider",
            "external_subject_id",
            "assurance_level",
            "last_authenticated_at",
        ),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=PRIMARY_RETENTION_EN,
        retention_policy_ar=PRIMARY_RETENTION_AR,
    ),
    DataInventoryCategory(
        category_id="clinical_biomarkers",
        store="primary_db",
        table_names=("biomarker_preferences", "biomarker_windows", "biomarker_results"),
        title_en="Your results from Malaffi",
        title_ar="نتائجك من ملفي",
        purpose_en=(
            "Keeps a few test results (HbA1c, blood pressure, lipids, BMI, waist) at the start, "
            "6 months and 12 months, only while you allow it, to show your change over time."
        ),
        purpose_ar=(
            "يحفظ عدداً قليلاً من نتائج الفحوص (السكر التراكمي، ضغط الدم، الدهون، مؤشر كتلة الجسم، "
            "محيط الخصر) في البداية وبعد 6 و12 شهراً، فقط ما دمت تسمح بذلك، لعرض التغيّر مع الوقت."
        ),
        personal_fields=("value", "unit", "result_date", "body_measures_excluded"),
        deletion_mode="hard_delete",
        retention_days=None,
        retention_policy_en=(
            "Kept while your consent is active. Deleted at once when you withdraw consent or "
            "delete your account, and 90 days after your 12-month window closes."
        ),
        retention_policy_ar=(
            "تُحفظ ما دامت موافقتك سارية، وتُحذف فوراً عند سحب الموافقة أو حذف حسابك، "
            "وبعد 90 يوماً من انتهاء فترة الأشهر الاثني عشر."
        ),
    ),
    DataInventoryCategory(
        category_id="analytics_research_store",
        store="analytics_store",
        table_names=("mrt_export_runs",),
        title_en="De-Identified Programme Evaluation & Research Store",
        title_ar="مستودع أبحاث وتقييم البرنامج منزوع الهوية",
        purpose_en=(
            "Holds aggregate, de-identified micro-randomised trial statistics with no "
            "direct identifiers."
        ),
        purpose_ar=(
            "يحفظ إحصاءات أبحاث وتقييم البرنامج بشكل مجمّع ومنزوع الهوية دون أي معرّفات شخصية مباشرة."
        ),
        personal_fields=("pseudonym_id",),
        deletion_mode="irreversible_anonymise",
        retention_days=9125,
        retention_policy_en=(
            "Upon account deletion, your pseudonymous research digest (psn_<hash>) is added "
            "to the permanent suppression list so your observations are excluded from future "
            "research exports."
        ),
        retention_policy_ar=(
            "عند حذف الحساب، يُضاف المعرّف المستعار (psn_<hash>) إلى قائمة الاستبعاد الدائمة "
            "بحيث لا تُدرج بياناتك في أي صادرات بحثية مستقبلية."
        ),
    ),
    DataInventoryCategory(
        category_id="statutory_audit_logs",
        store="audit_logs",
        table_names=("immutable_audit_logs", "audit_log"),
        title_en="Statutory Security & Access Audit Trail",
        title_ar="سجل التدقيق الأمني والوصول القانوني",
        purpose_en=(
            "Maintains a tamper-evident security log of system access and automated decisions "
            "as required by UAE health-data law."
        ),
        purpose_ar=(
            "يحفظ سجلاً أمنياً غير قابل للتلاعب لعمليات الوصول والقرارات الآلية وفقاً لقوانين "
            "البيانات الصحية في الإمارات."
        ),
        personal_fields=("subject_id_digest", "target_user_id"),
        deletion_mode="irreversible_anonymise",
        retention_days=1825,
        retention_policy_en=(
            "Direct user links (target_user_id) are set to NULL on deletion, and immutable "
            "security audit entries retain only a non-reversible cryptographic digest "
            "(psn_<hash>) with zero cleartext personal data for 1,825 days (5 years) under "
            "UAE Federal Law No. 2 of 2019 and ADHICS v2."
        ),
        retention_policy_ar=(
            "يتم فصل الروابط المباشرة (target_user_id = NULL) عند الحذف، وتحتفظ سجلات التدقيق "
            "الأمني ببصمة مشفرة غير قابلة للعكس فقط (psn_<hash>) دون أي بيانات شخصية نصية لمدة "
            "1825 يوماً (5 سنوات) وفقاً للقانون الاتحادي رقم 2 لسنة 2019 ومعايير ADHICS v2."
        ),
    ),
)

_SOURCE_LABELS_EN: dict[str, str] = {
    "self_report": "What you tell us (self-report)",
    "phone_steps": "Phone step count",
    "wearable": "Wearable (sleep, heart rate)",
    "health_age": "Health Age / screening result",
    "human_support": "Human coach & clinician support",
}
_SOURCE_LABELS_AR: dict[str, str] = {
    "self_report": "ما تشاركه معنا (الإدخال الذاتي)",
    "phone_steps": "عدد خطوات الهاتف",
    "wearable": "الجهاز القابل للارتداء (النوم ونبض القلب)",
    "health_age": "العمر الصحي / نتيجة الفحص",
    "human_support": "مساندة المدرب البشري والمختص الصحي",
}


def build_data_rights_inventory_counts(
    category_counts: Mapping[str, int],
) -> tuple[list[dict[str, Any]], int]:
    """Assemble the 18 inventory category items with live record counts and total primary count."""
    items: list[dict[str, Any]] = []
    total_primary = 0
    for cat in PERSONAL_DATA_INVENTORY_REGISTRY:
        count = max(0, int(category_counts.get(cat.category_id, 0)))
        if cat.store == "primary_db":
            total_primary += count
        items.append(
            {
                "category_id": cat.category_id,
                "store": cat.store,
                "table_names": list(cat.table_names),
                "title_en": cat.title_en,
                "title_ar": cat.title_ar,
                "purpose_en": cat.purpose_en,
                "purpose_ar": cat.purpose_ar,
                "personal_fields": list(cat.personal_fields),
                "deletion_mode": cat.deletion_mode,
                "retention_days": cat.retention_days,
                "retention_policy_en": cat.retention_policy_en,
                "retention_policy_ar": cat.retention_policy_ar,
                "record_count": count,
            }
        )
    return items, total_primary


def build_unified_consent_history(
    *,
    consent_decisions: Sequence[Mapping[str, Any]],
    human_support_consent: Mapping[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Build a complete chronological consent history (newest first) across all sources."""
    entries: list[dict[str, Any]] = []
    for row in consent_decisions:
        source = str(row["source"])
        allowed = bool(row["allowed"])
        entries.append(
            {
                "source": source,
                "source_label_en": _SOURCE_LABELS_EN.get(source, source),
                "source_label_ar": _SOURCE_LABELS_AR.get(source, source),
                "purpose": str(row["purpose"]),
                "allowed": allowed,
                "status_label_en": "Allowed" if allowed else "Withdrawn",
                "status_label_ar": "مسموح" if allowed else "تم سحب الموافقة",
                "wording_version": str(row["wording_version"]),
                "decided_at": row["decided_at"],
                "recorded_at": row["recorded_at"],
            }
        )

    if human_support_consent is not None:
        hs_allowed = bool(human_support_consent["allowed"])
        decided_at = human_support_consent["decided_at"]
        recorded_at = human_support_consent.get("updated_at", decided_at)
        entries.append(
            {
                "source": "human_support",
                "source_label_en": _SOURCE_LABELS_EN["human_support"],
                "source_label_ar": _SOURCE_LABELS_AR["human_support"],
                "purpose": "human_coach_and_clinician_support",
                "allowed": hs_allowed,
                "status_label_en": "Allowed" if hs_allowed else "Withdrawn",
                "status_label_ar": "مسموح" if hs_allowed else "تم سحب الموافقة",
                "wording_version": "f15-v1",
                "decided_at": decided_at,
                "recorded_at": recorded_at,
            }
        )

    entries.sort(
        key=lambda item: (
            item["recorded_at"].isoformat()
            if isinstance(item["recorded_at"], datetime)
            else str(item["recorded_at"]),
            item["decided_at"].isoformat()
            if isinstance(item["decided_at"], datetime)
            else str(item["decided_at"]),
        ),
        reverse=True,
    )
    return entries


def generate_signed_export_token(
    *,
    user_id: UUID | str,
    export_format: ExportFormatLiteral,
    expires_at: int,
    secret_key: str,
) -> str:
    """Compute a deterministic HMAC-SHA256 signature for a short-lived export download link."""
    canonical = f"bounceback-export-v1|{user_id}|{export_format}|{int(expires_at)}"
    return hmac.new(
        secret_key.encode("utf-8"),
        canonical.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def verify_signed_export_token(
    *,
    token: str,
    user_id: UUID | str,
    export_format: ExportFormatLiteral,
    expires_at: int,
    now: datetime,
    secret_key: str,
) -> None:
    """Verify a short-lived export download token in constant time and check expiration."""
    if not token or len(token) != 64:
        raise ExportTokenInvalidError("Export download token is invalid.")
    expected = generate_signed_export_token(
        user_id=user_id,
        export_format=export_format,
        expires_at=expires_at,
        secret_key=secret_key,
    )
    if not hmac.compare_digest(token, expected):
        raise ExportTokenInvalidError("Export download signature mismatch.")
    now_ts = int(now.timestamp())
    if now_ts > int(expires_at):
        raise ExportTokenExpiredError("Export download link has expired.")


def build_human_readable_json_export(
    export_payload: Mapping[str, Any],
    *,
    exported_at: datetime,
) -> dict[str, Any]:
    """Enrich the structured export dictionary with human-readable metadata and data dictionary."""
    dictionary = [
        {
            "categoryId": cat.category_id,
            "store": cat.store,
            "titleEn": cat.title_en,
            "titleAr": cat.title_ar,
            "purposeEn": cat.purpose_en,
            "purposeAr": cat.purpose_ar,
            "personalFields": list(cat.personal_fields),
            "deletionMode": cat.deletion_mode,
            "retentionPolicyEn": cat.retention_policy_en,
            "retentionPolicyAr": cat.retention_policy_ar,
        }
        for cat in PERSONAL_DATA_INVENTORY_REGISTRY
    ]
    result = dict(export_payload)
    result["schemaVersion"] = EXPORT_SCHEMA_VERSION
    result["exportedAt"] = exported_at.isoformat()
    result["dataDictionary"] = dictionary
    return result


def _json_str(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def build_unified_csv_export(export_payload: Mapping[str, Any]) -> str:
    """Render a single, spreadsheet-ready UTF-8 CSV file covering all personal data categories."""
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow(
        [
            "category",
            "record_id",
            "recorded_at",
            "title_or_source",
            "summary",
            "attributes_json",
        ]
    )

    user_obj = export_payload.get("user") or {}
    user_id = str(user_obj.get("id", ""))
    user_created = str(user_obj.get("createdAt") or user_obj.get("created_at") or "")
    profile = user_obj.get("profile") or {}
    context = user_obj.get("context") or {}

    if user_obj:
        writer.writerow(
            [
                "user_profile",
                user_id,
                user_created,
                f"locale={profile.get('locale') or 'en'}",
                f"Timezone {profile.get('timezone') or 'UTC'}",
                _json_str(profile),
            ]
        )
        pref_ch = context.get("preferredChannel") or context.get("preferred_channel") or "app"
        writer.writerow(
            [
                "weekly_context",
                user_id,
                user_created,
                str(context.get("workPattern") or context.get("work_pattern") or "default"),
                f"Preferred channel: {pref_ch}",
                _json_str(context),
            ]
        )

    consent_history = (
        export_payload.get("consentHistory")
        or export_payload.get("consent_history")
        or user_obj.get("consents")
        or []
    )
    for idx, c in enumerate(consent_history, start=1):
        source = str(c.get("source", ""))
        allowed = bool(c.get("allowed", False))
        recorded_at = str(
            c.get("recordedAt")
            or c.get("recorded_at")
            or c.get("decidedAt")
            or c.get("decided_at")
            or ""
        )
        writer.writerow(
            [
                "consent_history",
                f"consent-{idx}",
                recorded_at,
                source,
                f"{'Allowed' if allowed else 'Withdrawn'} ({c.get('purpose', '')})",
                _json_str(c),
            ]
        )

    hs = export_payload.get("humanSupportConsent") or export_payload.get("human_support_consent")
    if isinstance(hs, Mapping):
        hs_allowed = bool(hs.get("allowed", False))
        hs_decided = str(hs.get("decidedAt") or hs.get("decided_at") or "")
        writer.writerow(
            [
                "human_support_and_suggestions",
                f"human-support-{user_id}",
                hs_decided,
                "human_support",
                f"Human coach support: {'Allowed' if hs_allowed else 'Withdrawn'}",
                _json_str(hs),
            ]
        )

    goals = export_payload.get("goals")
    if isinstance(goals, Mapping):
        behaviours = goals.get("behaviours") or []
        writer.writerow(
            [
                "goals_and_readiness",
                user_id,
                str(goals.get("updatedAt") or goals.get("updated_at") or user_created),
                ",".join(str(b) for b in behaviours),
                str(
                    goals.get("why")
                    or f"Start level {goals.get('startLevel') or goals.get('start_level') or 'L1'}"
                ),
                _json_str(goals),
            ]
        )

    plan_versions = export_payload.get("planVersions") or export_payload.get("plan_versions") or []
    for pv in plan_versions:
        pv_id = str(pv.get("id", f"v{pv.get('version', 1)}"))
        created_at = str(pv.get("createdAt") or pv.get("created_at") or "")
        actions = pv.get("actions") or []
        writer.writerow(
            [
                "habit_plans",
                pv_id,
                created_at,
                f"version-{pv.get('version', 1)}",
                f"{len(actions)} planned micro-action(s) ({pv.get('source', '')})",
                _json_str(pv),
            ]
        )

    checkins = export_payload.get("checkins") or []
    for chk in checkins:
        chk_date = chk.get("localDate") or chk.get("local_date") or ""
        writer.writerow(
            [
                "daily_checkins",
                str(chk.get("id", "")),
                str(chk.get("recordedAt") or chk.get("recorded_at") or chk_date),
                str(chk.get("actionId") or chk.get("action_id") or ""),
                f"Status: {chk.get('status', '')} on {chk_date}",
                _json_str(chk),
            ]
        )

    signals = export_payload.get("userSignals") or export_payload.get("user_signals") or []
    for sig in signals:
        sig_type = sig.get("signalType") or sig.get("signal_type")
        sig_val = sig.get("valueInt") or sig.get("value_int")
        writer.writerow(
            [
                "passive_signals",
                str(sig.get("id", "")),
                str(sig.get("recordedAt") or sig.get("recorded_at") or sig.get("localDate") or ""),
                str(sig.get("source", "phone_steps")),
                f"{sig_type}: {sig_val}",
                _json_str(sig),
            ]
        )

    decisions = export_payload.get("decisionLogs") or export_payload.get("decision_logs") or []
    for dec in decisions:
        writer.writerow(
            [
                "adaptive_decisions",
                str(dec.get("id", "")),
                str(dec.get("createdAt") or dec.get("created_at") or ""),
                str(dec.get("decisionType") or dec.get("decision_type") or ""),
                f"Policy {dec.get('policyVersion') or dec.get('policy_version')}",
                _json_str(dec),
            ]
        )

    lapses = export_payload.get("lapseEvents") or export_payload.get("lapse_events") or []
    for lp in lapses:
        writer.writerow(
            [
                "lapse_and_recovery",
                str(lp.get("id", "")),
                str(lp.get("detectedAt") or lp.get("detected_at") or ""),
                str(lp.get("state", "")),
                f"Barrier: {lp.get('barrier') or 'none'}",
                _json_str(lp),
            ]
        )

    messages = export_payload.get("coachMessages") or export_payload.get("coach_messages") or []
    for msg in messages:
        writer.writerow(
            [
                "coach_conversations",
                str(msg.get("id", "")),
                str(msg.get("createdAt") or msg.get("created_at") or ""),
                f"{msg.get('role', 'coach')}:{msg.get('channel', 'app')}",
                str(msg.get("content", ""))[:120],
                _json_str(msg),
            ]
        )

    social = (
        export_payload.get("supportAndSocial") or export_payload.get("support_and_social") or {}
    )
    if isinstance(social, Mapping):
        pod = social.get("podMembership") or social.get("pod_membership")
        if isinstance(pod, Mapping):
            writer.writerow(
                [
                    "social_and_points",
                    str(pod.get("id", "pod")),
                    str(pod.get("joinedAt") or pod.get("joined_at") or ""),
                    "pod_member",
                    f"Pod status: {pod.get('status', 'active')}",
                    _json_str(pod),
                ]
            )
        buddy = social.get("buddyLink") or social.get("buddy_link")
        if isinstance(buddy, Mapping):
            buddy_name = buddy.get("buddyDisplayName") or buddy.get("buddy_display_name") or ""
            writer.writerow(
                [
                    "social_and_points",
                    str(buddy.get("id", "buddy")),
                    str(buddy.get("createdAt") or buddy.get("created_at") or ""),
                    "buddy_link",
                    f"Buddy: {buddy_name}",
                    _json_str(buddy),
                ]
            )
        team = social.get("teamMembership") or social.get("team_membership")
        if isinstance(team, Mapping):
            writer.writerow(
                [
                    "social_and_points",
                    str(team.get("id", "team")),
                    str(team.get("joinedAt") or team.get("joined_at") or ""),
                    "team_member",
                    f"Team status: {team.get('status', 'active')}",
                    _json_str(team),
                ]
            )
        workplace = social.get("workplaceEnrollment") or social.get("workplace_enrollment")
        if isinstance(workplace, Mapping):
            wp_org = workplace.get("orgSlug") or workplace.get("org_slug")
            wp_status = workplace.get("status", "active")
            writer.writerow(
                [
                    "social_and_points",
                    str(workplace.get("id", "workplace")),
                    str(workplace.get("joinedAt") or workplace.get("joined_at") or ""),
                    "workplace_employee_enrollment",
                    f"Workplace ({wp_org}): {wp_status}",
                    _json_str(workplace),
                ]
            )
        points = social.get("pointsLedger") or social.get("points_ledger") or []
        for pt in points:
            writer.writerow(
                [
                    "social_and_points",
                    str(pt.get("id", "")),
                    str(pt.get("createdAt") or pt.get("created_at") or ""),
                    str(pt.get("eventType") or pt.get("event_type") or "points"),
                    f"+{pt.get('pointsDelta') or pt.get('points_delta') or 0} recognition points",
                    _json_str(pt),
                ]
            )

    suggestions = (
        export_payload.get("planSuggestions") or export_payload.get("plan_suggestions") or []
    )
    for sug in suggestions:
        target_act = sug.get("targetActionId") or sug.get("target_action_id")
        writer.writerow(
            [
                "human_support_and_suggestions",
                str(sug.get("id", "")),
                str(sug.get("createdAt") or sug.get("created_at") or ""),
                str(sug.get("proposerRole") or sug.get("proposer_role") or "coach"),
                f"Suggested {target_act} ({sug.get('status')})",
                _json_str(sug),
            ]
        )

    questionnaires = export_payload.get("questionnaires") or []
    for q in questionnaires:
        writer.writerow(
            [
                "questionnaires",
                str(q.get("id", "")),
                str(
                    q.get("respondedAt")
                    or q.get("responded_at")
                    or q.get("createdAt")
                    or q.get("created_at")
                    or ""
                ),
                f"{q.get('instrumentId') or q.get('instrument_id')}:{q.get('milestone')}",
                f"Status: {q.get('status')}",
                _json_str(q),
            ]
        )

    identities = (
        export_payload.get("identityBindings") or export_payload.get("identity_bindings") or []
    )
    for ib in identities:
        writer.writerow(
            [
                "identity_bindings",
                str(ib.get("id", "")),
                str(ib.get("lastAuthenticatedAt") or ib.get("last_authenticated_at") or ""),
                str(ib.get("provider", "")),
                f"Assurance: {ib.get('assuranceLevel') or ib.get('assurance_level')}",
                _json_str(ib),
            ]
        )

    write_biomarker_csv_rows(writer, export_payload)
    return buf.getvalue()


def evaluate_post_deletion_verification(
    *,
    post_deletion_category_counts: Mapping[str, int],
    analytics_suppressed: bool,
    portal_audit_links_remaining: int,
) -> tuple[bool, int]:
    """Verify that zero identifiable personal records remain after account deletion."""
    primary_residual = sum(
        max(0, int(post_deletion_category_counts.get(cat.category_id, 0)))
        for cat in PERSONAL_DATA_INVENTORY_REGISTRY
        if cat.store == "primary_db"
    )
    audit_residual = max(0, int(portal_audit_links_remaining))
    analytics_residual = 0 if analytics_suppressed else 1
    total_residual = primary_residual + audit_residual + analytics_residual
    return total_residual == 0, total_residual


def build_deletion_confirmation_receipt(
    *,
    receipt_id: UUID,
    deleted_at: datetime,
    subject_digest: str,
    primary_records_purged: int,
    analytics_records_anonymised: int,
    audit_records_anonymised: int,
    post_deletion_category_counts: Mapping[str, int],
    analytics_suppressed: bool,
    portal_audit_links_remaining: int,
) -> dict[str, Any]:
    """Assemble the Deletion Confirmation Receipt returned by `DELETE /users/{user_id}`."""
    verified, total_residual = evaluate_post_deletion_verification(
        post_deletion_category_counts=post_deletion_category_counts,
        analytics_suppressed=analytics_suppressed,
        portal_audit_links_remaining=portal_audit_links_remaining,
    )
    primary_residual = sum(
        max(0, int(post_deletion_category_counts.get(cat.category_id, 0)))
        for cat in PERSONAL_DATA_INVENTORY_REGISTRY
        if cat.store == "primary_db"
    )
    analytics_residual = 0 if analytics_suppressed else 1
    audit_residual = max(0, int(portal_audit_links_remaining))

    store_results = [
        {
            "store": "primary_db",
            "action_taken": "hard_delete",
            "records_purged": max(0, int(primary_records_purged)),
            "records_anonymised": 0,
            "residual_personal_records": primary_residual,
            "verified": primary_residual == 0,
        },
        {
            "store": "analytics_store",
            "action_taken": "irreversible_anonymise",
            "records_purged": 0,
            "records_anonymised": max(1, int(analytics_records_anonymised)),
            "residual_personal_records": analytics_residual,
            "verified": analytics_residual == 0,
        },
        {
            "store": "audit_logs",
            "action_taken": "irreversible_anonymise",
            "records_purged": 0,
            "records_anonymised": max(1, int(audit_records_anonymised)),
            "residual_personal_records": audit_residual,
            "verified": audit_residual == 0,
        },
    ]

    return {
        "receipt_id": receipt_id,
        "deleted_at": deleted_at,
        "subject_digest": subject_digest,
        "store_results": store_results,
        "categories_verified": len(PERSONAL_DATA_INVENTORY_REGISTRY),
        "residual_personal_records": total_residual,
        "zero_residual_pii_verified": verified,
        "retention_policy_summary_en": RETENTION_POLICY_SUMMARY_EN,
        "retention_policy_summary_ar": RETENTION_POLICY_SUMMARY_AR,
        "confirmation_message_en": CONFIRMATION_MESSAGE_EN,
        "confirmation_message_ar": CONFIRMATION_MESSAGE_AR,
    }
