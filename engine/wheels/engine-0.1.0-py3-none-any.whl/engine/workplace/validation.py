"""Pure validation rules for bulk invites, enrollment, silent leave, and challenges (T011, T015)."""

from __future__ import annotations

import re
from datetime import datetime
from typing import Literal
from uuid import UUID, uuid5

from engine.workplace.models import (
    MIN_WORKPLACE_K_ANONYMITY,
    WorkplaceEmployeeEnrollment,
    WorkplaceInviteBatch,
    WorkplaceLeaveScope,
)

_WORKPLACE_ENROLLMENT_NAMESPACE = UUID("8b7d4c05-52e3-4469-9f91-81a9e74b1a22")

_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_PHONE_DIGITS_RE = re.compile(r"(?:\+?\d[\d\s\-]{6,}\d)")

_FORBIDDEN_COMPETITIVE_TERMS: tuple[str, ...] = (
    "leaderboard",
    "leaderboards",
    "ranking",
    "rankings",
    "compete",
    "competition",
    "top performer",
    "winner",
    "loser",
    "elimination",
    "weight loss",
    "weight-loss",
    "pounds lost",
    "kilos lost",
    "bmi",
    "calorie deficit",
    "calories burned",
    "streak",
    "streaks",
    "unbroken chain",
    "don't break the chain",
    "shame",
    "penalty",
    "punish",
    "لوحة المتصدرين",
    "إنقاص الوزن",
    "خسارة الوزن",
    "سلسلة متتالية",
)


def _strip_benign_negated_phrases(text: str) -> str:
    cleaned = text.lower()
    for benign in (
        "without individual rankings",
        "without rankings",
        "no individual rankings",
        "no rankings",
        "no leaderboard",
        "without leaderboards",
        "بدون ترتيب فردي",
        "بدون لوحة متصدرين",
    ):
        cleaned = cleaned.replace(benign, "")
    return cleaned


def validate_bulk_invite_labels(
    *,
    cohort_label_en: str,
    cohort_label_ar: str,
) -> tuple[bool, Literal["workplace_roster_pii_forbidden"] | None]:
    """Ensure bulk invitation cohort labels contain no individual emails, phone numbers, or IDs."""
    for text in (cohort_label_en, cohort_label_ar):
        if "@" in text or _EMAIL_RE.search(text):
            return False, "workplace_roster_pii_forbidden"
        if _PHONE_DIGITS_RE.search(text):
            return False, "workplace_roster_pii_forbidden"
    return True, None


def validate_cooperative_challenge(
    *,
    title_en: str,
    title_ar: str,
    summary_en: str,
    summary_ar: str,
    target_value: int,
) -> tuple[bool, Literal["workplace_challenge_not_cooperative"] | None]:
    """Validate that a workplace challenge is cooperative, non-competitive, and blame-free."""
    if target_value < MIN_WORKPLACE_K_ANONYMITY:
        return False, "workplace_challenge_not_cooperative"

    combined = _strip_benign_negated_phrases(f"{title_en} {title_ar} {summary_en} {summary_ar}")
    for term in _FORBIDDEN_COMPETITIVE_TERMS:
        if term in combined:
            return False, "workplace_challenge_not_cooperative"

    return True, None


EnrollmentErrorLiteral = Literal[
    "workplace_invite_expired",
    "workplace_already_enrolled",
]


def evaluate_enrollment_transition(
    *,
    user_id: UUID,
    existing: WorkplaceEmployeeEnrollment | None,
    invite_batch: WorkplaceInviteBatch,
    team_slug: str | None,
    now: datetime,
) -> tuple[WorkplaceEmployeeEnrollment | None, EnrollmentErrorLiteral | None]:
    """Evaluate autonomous employee enrollment or team opt-in transition.

    Enforces:
    - Expired or revoked invite batch -> `workplace_invite_expired`.
    - Active enrollment in a DIFFERENT organisation -> `workplace_already_enrolled`.
    - Active enrollment in the SAME organisation -> updates `team_slug` and `invite_code`.
    - Previously left (`status == 'left_silently'`) -> reactivates silently (`left_at = None`).
    """
    if invite_batch.status != "active" or invite_batch.expires_at <= now:
        return None, "workplace_invite_expired"

    normalized_team = team_slug.strip() if team_slug and team_slug.strip() else None

    if existing is not None and existing.status == "active":
        if existing.org_slug != invite_batch.org_slug:
            return None, "workplace_already_enrolled"
        return (
            WorkplaceEmployeeEnrollment(
                id=existing.id,
                user_id=user_id,
                org_slug=invite_batch.org_slug,
                invite_code=invite_batch.invite_code,
                team_slug=normalized_team,
                status="active",
                joined_at=existing.joined_at,
                updated_at=now,
                left_at=None,
            ),
            None,
        )

    enrollment_id = (
        existing.id
        if existing is not None
        else uuid5(_WORKPLACE_ENROLLMENT_NAMESPACE, f"{user_id}:{invite_batch.org_slug}")
    )
    return (
        WorkplaceEmployeeEnrollment(
            id=enrollment_id,
            user_id=user_id,
            org_slug=invite_batch.org_slug,
            invite_code=invite_batch.invite_code,
            team_slug=normalized_team,
            status="active",
            joined_at=now,
            updated_at=now,
            left_at=None,
        ),
        None,
    )


def evaluate_silent_leave_transition(
    *,
    existing: WorkplaceEmployeeEnrollment | None,
    scope: WorkplaceLeaveScope,
    now: datetime,
) -> tuple[WorkplaceEmployeeEnrollment | None, Literal["workplace_not_enrolled"] | None]:
    """Evaluate silent employee departure from a cooperative team or the entire workplace programme.

    Guarantees zero employer notifications (`notifications_sent = 0`) and preserves personal data.
    """
    if existing is None or existing.status != "active":
        return None, "workplace_not_enrolled"

    if scope == "team_only":
        return (
            WorkplaceEmployeeEnrollment(
                id=existing.id,
                user_id=existing.user_id,
                org_slug=existing.org_slug,
                invite_code=existing.invite_code,
                team_slug=None,
                status="active",
                joined_at=existing.joined_at,
                updated_at=now,
                left_at=None,
            ),
            None,
        )

    return (
        WorkplaceEmployeeEnrollment(
            id=existing.id,
            user_id=existing.user_id,
            org_slug=existing.org_slug,
            invite_code=existing.invite_code,
            team_slug=None,
            status="left_silently",
            joined_at=existing.joined_at,
            updated_at=now,
            left_at=now,
        ),
        None,
    )
