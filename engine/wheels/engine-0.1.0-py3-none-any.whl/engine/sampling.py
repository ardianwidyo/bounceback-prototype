"""Weighted selection with an injected RNG and logged propensity (Principles III and VII)."""

import random
from collections.abc import Sequence
from dataclasses import dataclass


@dataclass(frozen=True)
class Selection[T]:
    item: T
    propensity: float


def select_weighted[T](
    candidates: Sequence[T], weights: Sequence[float], rng: random.Random
) -> Selection[T]:
    """Pick one candidate with probability proportional to its weight.

    ``rng`` is always injected so a decision can be replayed from its seed; the returned
    propensity is the selection probability that decision logs must record.
    """
    if not candidates:
        raise ValueError("candidates must not be empty")
    if len(candidates) != len(weights):
        raise ValueError("candidates and weights must have the same length")
    if any(weight < 0 for weight in weights):
        raise ValueError("weights must not be negative")
    total = sum(weights)
    if total <= 0:
        raise ValueError("at least one weight must be positive")

    (index,) = rng.choices(range(len(candidates)), weights=weights, k=1)
    return Selection(item=candidates[index], propensity=weights[index] / total)
