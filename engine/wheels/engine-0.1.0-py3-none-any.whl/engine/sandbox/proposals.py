"""Adjustment proposals and the step-up (spec 023 US4).

A proposal is only ever a suggestion. Accepting one creates a new immutable plan version and never
touches cumulative active days, milestones or past check-ins. Declining or saying "not now" changes
nothing. Difficulty rises only after an explicit yes (Constitution II).
"""

from __future__ import annotations

from typing import Any

from engine.progress import ACTIVE_STATUSES
from engine.recovery import evaluate_step_up_eligibility
from engine.sandbox.checkin import active_plan, refresh_progress
from engine.sandbox.commands import Event, Handler
from engine.sandbox.context import SCHEDULE_CONSENTS, consent_granted, latest_context
from engine.sandbox.planning import PlanContext, next_plan_version, select_items
from engine.sandbox.radar import add_message
from engine.sandbox.recovery_flow import readapt_recovery
from engine.sandbox.schedule_adapt import adapt
from engine.sandbox.state import SandboxError, State
from engine.sandbox.trail import append_entry, last_decision_id

POLICY_VERSION = "adjustments-1"
CONTEXT_TRIGGERS: frozenset[str] = frozenset(
    {"night_shift", "ramadan", "combined", "restore_regular"}
)
PLAN_REASON = {
    "lapse": "recovery",
    "night_shift": "shift",
    "ramadan": "ramadan",
    "combined": "combined",
    "restore_regular": "restore_regular",
    "quiet_hours": "quiet_hours",
    "step_up": "step_up",
}


def register_proposal(
    state: State, proposal: dict[str, Any], *, inputs: dict[str, Any]
) -> tuple[State, list[Event]]:
    """Log a new proposal and make it the pending one, replacing (and noting) an older one."""
    pending = state["pending_proposal"]
    superseded = pending["id"] if pending else None
    working = append_entry(
        state,
        decision_type="adjustment_proposed",
        on=state["current_date"],
        policy_version=POLICY_VERSION,
        inputs_used={
            "trigger": proposal["trigger"],
            "changes": len(proposal["changes"]),
            "superseded": superseded,
            **inputs,
        },
        excluded_sources=[pair for pair in SCHEDULE_CONSENTS if not consent_granted(state, pair)],
        candidate_set=["keep", "adjust"],
        chosen="proposed",
        propensities=[1.0],
        summary_key="trail.adjustment_proposed",
    )
    decision_id = last_decision_id(working)
    assert decision_id is not None
    proposal_id = f"p{decision_id[1:]}"
    ready = {**proposal, "id": proposal_id, "decision_id": decision_id}
    return {**working, "pending_proposal": ready}, [
        {"type": "proposal_ready", "proposal_id": proposal_id}
    ]


def _withdraw(state: State) -> State:
    """Drop a pending context proposal that no longer applies (the disruption was switched off)."""
    pending = state["pending_proposal"]
    assert pending is not None
    cleared = append_entry(
        state,
        decision_type="choice_recorded",
        on=state["current_date"],
        policy_version=POLICY_VERSION,
        inputs_used={"proposal_id": pending["id"], "trigger": pending["trigger"]},
        excluded_sources=[],
        candidate_set=[],
        chosen="proposal_withdrawn",
        propensities=[1.0],
        summary_key="trail.proposal_withdrawn",
    )
    return {**cleared, "pending_proposal": None}


def target_context(state: State) -> PlanContext:
    """The plan context the user's current situation calls for, respecting their consent."""
    day = latest_context(state)
    adapts_pattern = consent_granted(state, "work_pattern:schedule_adaptation")
    return PlanContext(
        ramadan=bool(day["ramadan"])
        and consent_granted(state, "ramadan_setting:schedule_adaptation"),
        work_pattern=day["work_pattern"] if adapts_pattern else state["profile"]["work_pattern"],
        first_block_day=adapts_pattern and day["night_shift_block_day"] == 1,
    )


def _trigger(state: State, target: PlanContext) -> str:
    usual = state["profile"]["work_pattern"]
    if target == PlanContext(work_pattern=usual):
        return "restore_regular"
    if target.ramadan and target.work_pattern != usual:
        return "combined"
    return "ramadan" if target.ramadan else "night_shift"


def propose_for_context(state: State) -> tuple[State, list[Event]]:
    """After a context change: propose adapting the plan, or withdraw one that no longer fits."""
    plan = active_plan(state)
    target = target_context(state)
    trigger = _trigger(state, target)
    pending = state["pending_proposal"]
    current = PlanContext.from_dict(plan["context"])

    proposal: dict[str, Any] | None = None
    if target != current:
        if plan["reason"] == "recovery":
            proposal = readapt_recovery(state, target, trigger)
        else:
            proposal = adapt(
                state, target=target, trigger=trigger, new_version=next_plan_version(state)
            )

    if proposal is None:
        if pending is not None and pending["trigger"] in CONTEXT_TRIGGERS:
            return _withdraw(state), []
        return state, []
    return register_proposal(
        state,
        proposal,
        inputs={"context": target.to_dict(), "before_version": plan["version"]},
    )


def _activate(state: State, proposal: dict[str, Any]) -> tuple[State, list[Event]]:
    """Make an accepted proposal the new plan version (immutable: the old one is left behind)."""
    old = active_plan(state)
    version = next_plan_version(state)
    items = proposal["after_items"]
    working = append_entry(
        state,
        decision_type="plan_built",
        on=state["current_date"],
        policy_version=POLICY_VERSION,
        inputs_used={
            "trigger": proposal["trigger"],
            "from_version": old["version"],
            "barrier": proposal.get("barrier"),
        },
        excluded_sources=[],
        candidate_set=[item["action_id"] for item in items],
        chosen=[item["action_id"] for item in items],
        propensities=[1.0],
        summary_key="trail.plan_adjusted",
    )
    plan_decision = last_decision_id(working)
    plan: dict[str, Any] = {
        "version": version,
        "parent_version": old["version"],
        "created_on": state["current_date"],
        "reason": PLAN_REASON[proposal["trigger"]],
        "items": [{**item, "decision_id": item["decision_id"] or plan_decision} for item in items],
        "active": True,
        "context": proposal.get("context", old["context"]),
        "seeds": proposal.get("seeds", old["seeds"]),
    }
    if proposal.get("barrier"):
        plan["barrier"] = proposal["barrier"]
    plans = [{**p, "active": False} if p["active"] else p for p in working["plans"]] + [plan]
    return {**working, "plans": plans}, [{"type": "plan_activated", "version": version}]


def _respond_proposal(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    assert state is not None  # the command schema requires a state
    proposal = state["pending_proposal"]
    if (
        proposal is None
        or proposal["id"] != command["proposal_id"]
        or proposal["status"] != "pending"
    ):
        raise SandboxError("proposal_not_pending")
    choice = command["choice"]
    working = append_entry(
        state,
        decision_type="choice_recorded",
        on=state["current_date"],
        policy_version=POLICY_VERSION,
        inputs_used={"proposal_id": proposal["id"], "trigger": proposal["trigger"]},
        excluded_sources=[],
        candidate_set=["accept", "keep", "not_now"],
        chosen=choice,
        propensities=[1.0],
        summary_key="trail.proposal_answered",
    )
    working = {**working, "pending_proposal": None}
    events: list[Event] = []
    if choice == "accept":
        working, events = _activate(working, proposal)
        working, progress_events = refresh_progress(working)
        events = [*events, *progress_events]
    return working, events


# ---------------------------------------------------------------- the step-up


def maybe_invite_step_up(state: State) -> tuple[State, list[Event]]:
    """After 5 successful check-ins on a recovery plan, invite the user (once) to step back up."""
    plan = active_plan(state)
    if plan["reason"] != "recovery" or plan.get("step_up_offered"):
        return state, []
    slots = {item["slot_id"] for item in plan["items"]}
    successful = sum(
        1 for c in state["checkins"] if c["slot_id"] in slots and c["status"] in ACTIVE_STATUSES
    )
    verdict = evaluate_step_up_eligibility(
        plan_created_by="recovery",
        completed_checkins_since_version=successful,
        step_up_dismissed=bool(plan.get("step_up_dismissed")),
        plan_source=plan.get("source"),
    )
    if not verdict.eligible:
        return state, []
    marked = {**plan, "step_up_offered": True}
    plans = [marked if p["version"] == plan["version"] else p for p in state["plans"]]
    working, message_id = add_message(
        {**state, "plans": plans},
        "step_up_invite",
        "coach.step_up_invite",
        {"plan_version": str(plan["version"])},
    )
    return working, [{"type": "coach_message", "message_id": message_id}]


def _respond_step_up(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    assert state is not None  # the command schema requires a state
    plan = active_plan(state)
    if (
        plan["reason"] != "recovery"
        or not plan.get("step_up_offered")
        or plan.get("step_up_answered")
    ):
        raise SandboxError("proposal_not_pending")
    answered = {**plan, "step_up_answered": True, "step_up_dismissed": not command["accept"]}
    plans = [answered if p["version"] == plan["version"] else p for p in state["plans"]]
    working = append_entry(
        {**state, "plans": plans},
        decision_type="choice_recorded",
        on=state["current_date"],
        policy_version=POLICY_VERSION,
        inputs_used={"plan_version": plan["version"]},
        excluded_sources=[],
        candidate_set=["accept", "decline"],
        chosen="accept" if command["accept"] else "decline",
        propensities=[1.0],
        summary_key="trail.step_up_answered",
    )
    if not command["accept"]:
        return working, []

    parent = next(p for p in working["plans"] if p["version"] == plan["parent_version"])
    target = target_context(working)
    version = next_plan_version(working)
    selection = select_items(working, version=version, context=target, seeds=parent["seeds"])
    stepped = {
        "id": None,
        "trigger": "step_up",
        "created_on": working["current_date"],
        "before_version": plan["version"],
        "after_items": selection.items,
        "changes": [],
        "context": target.to_dict(),
        "seeds": dict(parent["seeds"]),
    }
    activated, events = _activate(working, {**stepped, "decision_id": None})
    last = activated["plans"][-1]
    activated["plans"][-1] = {**last, "source": "recovery_step_up"}
    refreshed, progress_events = refresh_progress(activated)
    return refreshed, [*events, *progress_events]


HANDLERS: dict[str, Handler] = {
    "respond_proposal": _respond_proposal,
    "respond_step_up": _respond_step_up,
}
