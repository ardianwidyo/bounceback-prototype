"""F05 Lapse Radar — pure, deterministic daily disengagement risk estimation."""

from __future__ import annotations

import math
from datetime import date, timedelta
from enum import StrEnum
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field

LAPSE_RADAR_POLICY_VERSION = "lapse-radar-v1"
DEFAULT_WEIGHTS_PATH = Path(__file__).with_name("lapse_weights.yaml")


class LapseState(StrEnum):
    HEALTHY = "healthy"
    WATCH = "watch"
    LAPSE_RISK = "lapse_risk"
    LAPSED = "lapsed"


class SensorSyncStatus(StrEnum):
    ACTIVE = "active"
    UNCONSENTED = "unconsented"
    SYNC_MISSING = "sync_missing"


class LapseReasonCode(StrEnum):
    NIGHT_SHIFT_TRANSITION = "night_shift_transition"
    WORK_PATTERN_CHANGE = "work_pattern_change"
    RAMADAN_STARTED = "ramadan_started"
    CHECKIN_GAP = "checkin_gap"
    COMPLETION_DIP = "completion_dip"
    LOW_SUGGESTION_RESPONSIVENESS = "low_suggestion_responsiveness"
    ACTIVITY_SIGNAL_DIP = "activity_signal_dip"
    LAPSED_INACTIVITY_WINDOW = "lapsed_inactivity_window"


WorkPatternKind = Literal[
    "day",
    "rotating",
    "nights",
    "office_9_to_5",
    "shift",
    "flexible",
    "student",
    "other",
]

DEFAULT_REASON_TEMPLATES: dict[str, str] = {
    LapseReasonCode.NIGHT_SHIFT_TRANSITION.value: (
        "Shift schedule recently changed to a night-shift block"
    ),
    LapseReasonCode.WORK_PATTERN_CHANGE.value: "Recent change in daily work schedule",
    LapseReasonCode.RAMADAN_STARTED.value: (
        "Ramadan has just begun, which changes the rhythm of your day"
    ),
    LapseReasonCode.CHECKIN_GAP.value: "Check-ins have been paused for the last {days} days",
    LapseReasonCode.COMPLETION_DIP.value: (
        "Recent 7-day routine pace is quieter than your 28-day baseline"
    ),
    LapseReasonCode.LOW_SUGGESTION_RESPONSIVENESS.value: (
        "Recent action suggestions haven't matched your available moments"
    ),
    LapseReasonCode.ACTIVITY_SIGNAL_DIP.value: (
        "Consented activity signal is gentler than your recent baseline"
    ),
    LapseReasonCode.LAPSED_INACTIVITY_WINDOW.value: (
        "Routine has been quiet for {days} days — ready for a gentle restart whenever you are"
    ),
}


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CheckInDayRecord(_FrozenModel):
    local_date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    status: Literal["done", "partial", "skipped", "unanswered"]


class NudgeResponseRecord(_FrozenModel):
    local_date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    responded: bool


class LapseHistoryInput(_FrozenModel):
    checkins: tuple[CheckInDayRecord, ...] = ()
    nudge_responses: tuple[NudgeResponseRecord, ...] = ()
    scheduled_dates_28d: tuple[str, ...] = ()


class DailyActivitySample(_FrozenModel):
    local_date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    activity_value: float = Field(ge=0.0)


class LapseSignalsInput(_FrozenModel):
    wearable_consented: bool = False
    sync_status: SensorSyncStatus = SensorSyncStatus.UNCONSENTED
    daily_samples: tuple[DailyActivitySample, ...] = ()
    baseline_value: float | None = Field(default=None, ge=0.0)
    recent_value: float | None = Field(default=None, ge=0.0)


class LapseContextInput(_FrozenModel):
    user_id: str = Field(min_length=1)
    local_date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    enrolled_local_date: str | None = Field(default=None, pattern=r"^\d{4}-\d{2}-\d{2}$")
    work_pattern: WorkPatternKind = "day"
    night_shift_block_started_recently: bool = False
    work_pattern_changed_recently: bool = False
    # Ramadan began within the last few days; treated like any other change to the daily routine.
    ramadan_started_recently: bool = False
    is_paused: bool = False


class Features(_FrozenModel):
    user_id: str
    local_date: str
    days_since_last_checkin: int = Field(ge=0)
    completion_rate_7d: float = Field(ge=0.0, le=1.0)
    completion_rate_28d: float = Field(ge=0.0, le=1.0)
    completion_vs_baseline_ratio: float = Field(ge=0.0)
    completion_drop: float = Field(ge=0.0, le=1.0)
    suggestion_responsiveness_7d: float | None = Field(default=None, ge=0.0, le=1.0)
    responsiveness_7d: float = Field(ge=0.0, le=1.0)
    responsiveness_drop: float = Field(ge=0.0, le=1.0)
    wearable_consented: bool
    sensor_sync_status: SensorSyncStatus
    wearable_signal_available: bool
    activity_drop_ratio: float | None = Field(default=None, ge=0.0, le=1.0)
    activity_signal_drop: float = Field(ge=0.0, le=1.0)
    has_recent_activity_signal: bool
    has_active_activity_signal_today: bool
    consecutive_no_checkin_and_no_signal_days: int = Field(ge=0)
    work_pattern: str
    night_shift_block_active: bool
    night_shift_transition_flag: bool
    work_pattern_change: bool
    work_pattern_change_flag: bool
    ramadan_started: bool = False
    is_paused: bool = False


LapseFeatures = Features


class LapseThresholds(_FrozenModel):
    watch: float = Field(default=0.40, ge=0.0, le=1.0)
    lapse_risk: float = Field(default=0.60, ge=0.0, le=1.0)
    lapsed_days: int = Field(default=3, ge=1)
    lapsed_min_score: float = Field(default=0.80, ge=0.0, le=1.0)
    reason_min_contribution: float = Field(default=0.15, ge=0.0)


class LapseCoefficients(_FrozenModel):
    intercept: float = -2.20
    days_since_last_checkin: float = 1.50
    completion_drop: float = 2.20
    responsiveness_drop: float = 1.20
    activity_signal_drop: float = 1.10
    work_pattern_change: float = 1.15


class LapseWeights(_FrozenModel):
    version: str = LAPSE_RADAR_POLICY_VERSION
    coefficients: LapseCoefficients = Field(default_factory=LapseCoefficients)
    thresholds: LapseThresholds = Field(default_factory=LapseThresholds)
    reason_templates: dict[str, str] = Field(default_factory=lambda: dict(DEFAULT_REASON_TEMPLATES))


class Risk(_FrozenModel):
    score: float = Field(ge=0.0, le=1.0)
    state: LapseState
    reasons: tuple[str, ...] = ()
    reason_codes: tuple[LapseReasonCode, ...] = ()
    feature_contributions: dict[str, float] = Field(default_factory=dict)
    policy_version: str = LAPSE_RADAR_POLICY_VERSION
    should_trigger_recovery: bool = False


LapseRisk = Risk


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def _status_weight(status: str) -> float:
    if status == "done":
        return 1.0
    if status == "partial":
        return 0.5
    return 0.0


def load_lapse_weights(path: Path | None = None) -> LapseWeights:
    """Load and validate versioned YAML weights for the Lapse Radar."""
    target = path if path is not None else DEFAULT_WEIGHTS_PATH
    with target.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle)
    if not isinstance(raw, dict):
        raise ValueError(f"Expected mapping in lapse weights YAML at {target}")
    merged_templates = dict(DEFAULT_REASON_TEMPLATES)
    raw_templates = raw.get("reason_templates")
    if isinstance(raw_templates, dict):
        for k, v in raw_templates.items():
            merged_templates[str(k)] = str(v)
    payload = dict(raw)
    payload["reason_templates"] = merged_templates
    return LapseWeights.model_validate(payload)


def features(
    history: LapseHistoryInput,
    signals: LapseSignalsInput,
    context: LapseContextInput,
) -> Features:
    """Extract normalized, consent-aware daily disengagement features for `context.local_date`."""
    target_date = date.fromisoformat(context.local_date)
    enrolled_date = (
        date.fromisoformat(context.enrolled_local_date)
        if context.enrolled_local_date is not None
        else None
    )
    days_enrolled: int | None = None
    if enrolled_date is not None:
        days_enrolled = max(0, (target_date - enrolled_date).days)

    # Aggregate best check-in status weight per local_date <= target_date
    day_weights: dict[date, float] = {}
    active_checkin_dates: set[date] = set()
    for record in history.checkins:
        rec_date = date.fromisoformat(record.local_date)
        if rec_date > target_date:
            continue
        w = _status_weight(record.status)
        if rec_date not in day_weights or w > day_weights[rec_date]:
            day_weights[rec_date] = w
        if record.status in {"done", "partial"}:
            active_checkin_dates.add(rec_date)

    # 1. Days since last check-in (with cold-start safety)
    is_cold_start = (
        days_enrolled is not None and days_enrolled < 3 and len(active_checkin_dates) == 0
    )
    if active_checkin_dates:
        most_recent_active = max(active_checkin_dates)
        days_since_last_checkin = max(0, (target_date - most_recent_active).days)
    elif is_cold_start:
        days_since_last_checkin = 0
    elif days_enrolled is not None:
        days_since_last_checkin = min(14, max(0, days_enrolled))
    else:
        days_since_last_checkin = 7

    # 2. 7-day and 28-day completion rates & personal baseline comparison
    window_7d_start = target_date - timedelta(days=6)
    window_28d_start = target_date - timedelta(days=27)

    scheduled_dates = {
        date.fromisoformat(d)
        for d in history.scheduled_dates_28d
        if window_28d_start <= date.fromisoformat(d) <= target_date
    }

    if scheduled_dates:
        denom_7d_dates = [d for d in scheduled_dates if d >= window_7d_start]
        denom_28d_dates = list(scheduled_dates)
    elif day_weights:
        earliest_date_bound = min(min(day_weights.keys()), enrolled_date or window_28d_start)
        eff_28d_start = max(window_28d_start, earliest_date_bound)
        eff_7d_start = max(window_7d_start, earliest_date_bound)
        denom_7d_dates = [
            eff_7d_start + timedelta(days=i) for i in range((target_date - eff_7d_start).days + 1)
        ]
        denom_28d_dates = [
            eff_28d_start + timedelta(days=i) for i in range((target_date - eff_28d_start).days + 1)
        ]
    else:
        denom_7d_dates = []
        denom_28d_dates = []

    if denom_7d_dates:
        completion_rate_7d = round(
            _clamp(sum(day_weights.get(d, 0.0) for d in denom_7d_dates) / len(denom_7d_dates)),
            4,
        )
    else:
        completion_rate_7d = 0.0

    if denom_28d_dates:
        completion_rate_28d = round(
            _clamp(sum(day_weights.get(d, 0.0) for d in denom_28d_dates) / len(denom_28d_dates)),
            4,
        )
    else:
        completion_rate_28d = 0.0

    prior_baseline_dates = [d for d in denom_28d_dates if d < window_7d_start]
    under_7d_enrolled = (
        days_enrolled is not None and days_enrolled < 7 and len(prior_baseline_dates) < 3
    )

    if under_7d_enrolled or len(denom_28d_dates) < 3:
        completion_vs_baseline_ratio = 1.0
        completion_drop = 0.0
    else:
        effective_baseline = completion_rate_28d
        if len(prior_baseline_dates) >= 3:
            prior_rate = sum(day_weights.get(d, 0.0) for d in prior_baseline_dates) / len(
                prior_baseline_dates
            )
            effective_baseline = max(completion_rate_28d, round(_clamp(prior_rate), 4))
        if effective_baseline <= 1e-6:
            completion_vs_baseline_ratio = 1.0
            completion_drop = 0.0
        else:
            completion_vs_baseline_ratio = round(completion_rate_7d / effective_baseline, 4)
            completion_drop = round(_clamp(effective_baseline - completion_rate_7d), 4)

    # 3. 7-day suggestion responsiveness
    nudges_7d = [
        n
        for n in history.nudge_responses
        if window_7d_start <= date.fromisoformat(n.local_date) <= target_date
    ]
    if not nudges_7d:
        suggestion_responsiveness_7d: float | None = None
        responsiveness_7d = 1.0
        responsiveness_drop = 0.0
    else:
        responded_count = sum(1 for n in nudges_7d if n.responded)
        resp_ratio = round(_clamp(responded_count / len(nudges_7d)), 4)
        suggestion_responsiveness_7d = resp_ratio
        responsiveness_7d = resp_ratio
        responsiveness_drop = round(_clamp(1.0 - resp_ratio), 4) if len(nudges_7d) >= 2 else 0.0

    # 4. Consent-aware passive activity signals (FR-002 / SC-002)
    effective_sync_status = (
        SensorSyncStatus.UNCONSENTED if not signals.wearable_consented else signals.sync_status
    )

    sample_by_date: dict[date, float] = {}
    for sample in signals.daily_samples:
        s_date = date.fromisoformat(sample.local_date)
        if s_date <= target_date:
            sample_by_date[s_date] = sample.activity_value

    recent_3d_dates = [target_date - timedelta(days=i) for i in range(3)]
    baseline_21d_dates = [target_date - timedelta(days=i) for i in range(3, 28)]

    recent_samples = [sample_by_date[d] for d in recent_3d_dates if d in sample_by_date]
    baseline_samples = [sample_by_date[d] for d in baseline_21d_dates if d in sample_by_date]

    computed_baseline = (
        signals.baseline_value
        if signals.baseline_value is not None
        else (sum(baseline_samples) / len(baseline_samples) if baseline_samples else None)
    )
    computed_recent = (
        signals.recent_value
        if signals.recent_value is not None
        else (sum(recent_samples) / len(recent_samples) if recent_samples else None)
    )

    wearable_signal_available = bool(
        signals.wearable_consented
        and effective_sync_status == SensorSyncStatus.ACTIVE
        and computed_baseline is not None
        and computed_baseline > 0.0
        and computed_recent is not None
    )

    if wearable_signal_available and computed_baseline is not None and computed_recent is not None:
        drop_ratio = round(
            _clamp((computed_baseline - computed_recent) / computed_baseline),
            4,
        )
        activity_drop_ratio: float | None = drop_ratio
        activity_signal_drop = drop_ratio
        min_engaged_threshold = 0.50 * computed_baseline
        today_val = sample_by_date.get(target_date, computed_recent)
        has_active_activity_signal_today = today_val >= min_engaged_threshold
        has_recent_activity_signal = computed_recent >= min_engaged_threshold
    else:
        activity_drop_ratio = None
        activity_signal_drop = 0.0
        has_active_activity_signal_today = False
        has_recent_activity_signal = False
        min_engaged_threshold = 0.0

    # 5. Consecutive days ending at target_date with neither check-in nor consented active signal
    if is_cold_start:
        consecutive_silent_days = 0
    else:
        consecutive_silent_days = 0
        max_lookback = min(28, (days_enrolled + 1) if days_enrolled is not None else 28)
        for offset in range(max_lookback):
            d = target_date - timedelta(days=offset)
            has_checkin_on_d = d in active_checkin_dates
            has_signal_on_d = False
            if wearable_signal_available and computed_baseline is not None:
                if d in sample_by_date:
                    has_signal_on_d = sample_by_date[d] >= min_engaged_threshold
                elif offset < 3 and has_recent_activity_signal:
                    has_signal_on_d = True
            if has_checkin_on_d or has_signal_on_d:
                break
            consecutive_silent_days += 1

    # 6. Work pattern / shift transition flags
    night_shift_active = bool(
        context.night_shift_block_started_recently
        and context.work_pattern in {"shift", "rotating", "nights"}
    )
    work_pattern_changed = bool(
        night_shift_active
        or context.work_pattern_changed_recently
        or context.ramadan_started_recently
    )

    return Features(
        user_id=context.user_id,
        local_date=context.local_date,
        days_since_last_checkin=days_since_last_checkin,
        completion_rate_7d=completion_rate_7d,
        completion_rate_28d=completion_rate_28d,
        completion_vs_baseline_ratio=completion_vs_baseline_ratio,
        completion_drop=completion_drop,
        suggestion_responsiveness_7d=suggestion_responsiveness_7d,
        responsiveness_7d=responsiveness_7d,
        responsiveness_drop=responsiveness_drop,
        wearable_consented=signals.wearable_consented,
        sensor_sync_status=effective_sync_status,
        wearable_signal_available=wearable_signal_available,
        activity_drop_ratio=activity_drop_ratio,
        activity_signal_drop=activity_signal_drop,
        has_recent_activity_signal=has_recent_activity_signal,
        has_active_activity_signal_today=has_active_activity_signal_today,
        consecutive_no_checkin_and_no_signal_days=consecutive_silent_days,
        work_pattern=context.work_pattern,
        night_shift_block_active=night_shift_active,
        night_shift_transition_flag=night_shift_active,
        work_pattern_change=work_pattern_changed,
        work_pattern_change_flag=work_pattern_changed,
        ramadan_started=context.ramadan_started_recently,
        is_paused=context.is_paused,
    )


def score(
    extracted_features: Features,
    weights: LapseWeights | None = None,
) -> Risk:
    """Compute disengagement risk score in [0.0, 1.0], state, and blame-free reasons."""
    active_weights = weights if weights is not None else load_lapse_weights()
    if extracted_features.is_paused:
        return Risk(
            score=0.0,
            state=LapseState.HEALTHY,
            reasons=(),
            reason_codes=(),
            feature_contributions={},
            policy_version=active_weights.version,
            should_trigger_recovery=False,
        )
    coeff = active_weights.coefficients
    thresh = active_weights.thresholds
    templates = {**DEFAULT_REASON_TEMPLATES, **active_weights.reason_templates}

    days_norm = min(extracted_features.days_since_last_checkin / 3.0, 2.0)
    c_days = round(coeff.days_since_last_checkin * days_norm, 4)
    c_comp = round(coeff.completion_drop * extracted_features.completion_drop, 4)
    c_resp = round(coeff.responsiveness_drop * extracted_features.responsiveness_drop, 4)
    c_act = (
        round(coeff.activity_signal_drop * extracted_features.activity_signal_drop, 4)
        if extracted_features.wearable_signal_available
        else 0.0
    )
    c_shift = (
        round(coeff.work_pattern_change * 1.0, 4) if extracted_features.work_pattern_change else 0.0
    )

    logit = coeff.intercept + c_days + c_comp + c_resp + c_act + c_shift
    raw_prob = 1.0 / (1.0 + math.exp(-logit))

    is_lapsed = extracted_features.consecutive_no_checkin_and_no_signal_days >= thresh.lapsed_days
    if is_lapsed:
        final_score = round(_clamp(max(raw_prob, thresh.lapsed_min_score)), 4)
        state = LapseState.LAPSED
    else:
        final_score = round(_clamp(raw_prob), 4)
        if final_score >= thresh.lapse_risk:
            state = LapseState.LAPSE_RISK
        elif final_score >= thresh.watch:
            state = LapseState.WATCH
        else:
            state = LapseState.HEALTHY

    feature_contributions: dict[str, float] = {
        "days_since_last_checkin": c_days,
        "completion_drop": c_comp,
        "responsiveness_drop": c_resp,
        "activity_signal_drop": c_act,
        "work_pattern_change": c_shift,
    }

    # Build ordered candidate reasons by descending contribution
    candidate_reasons: list[tuple[float, int, LapseReasonCode, str]] = []
    min_contrib = thresh.reason_min_contribution

    if is_lapsed:
        inactivity_days = max(
            extracted_features.consecutive_no_checkin_and_no_signal_days,
            extracted_features.days_since_last_checkin,
        )
        candidate_reasons.append(
            (
                10.0,
                0,
                LapseReasonCode.LAPSED_INACTIVITY_WINDOW,
                templates[LapseReasonCode.LAPSED_INACTIVITY_WINDOW.value].format(
                    days=inactivity_days
                ),
            )
        )

    if extracted_features.work_pattern_change and c_shift >= min_contrib:
        if extracted_features.night_shift_block_active:
            code = LapseReasonCode.NIGHT_SHIFT_TRANSITION
        elif extracted_features.ramadan_started:
            code = LapseReasonCode.RAMADAN_STARTED
        else:
            code = LapseReasonCode.WORK_PATTERN_CHANGE
        candidate_reasons.append((c_shift, 1, code, templates[code.value]))

    if extracted_features.days_since_last_checkin >= 1 and c_days >= min_contrib:
        candidate_reasons.append(
            (
                c_days,
                2,
                LapseReasonCode.CHECKIN_GAP,
                templates[LapseReasonCode.CHECKIN_GAP.value].format(
                    days=extracted_features.days_since_last_checkin
                ),
            )
        )

    if extracted_features.completion_drop > 0.0 and c_comp >= min_contrib:
        candidate_reasons.append(
            (
                c_comp,
                3,
                LapseReasonCode.COMPLETION_DIP,
                templates[LapseReasonCode.COMPLETION_DIP.value],
            )
        )

    if extracted_features.responsiveness_drop > 0.0 and c_resp >= min_contrib:
        candidate_reasons.append(
            (
                c_resp,
                4,
                LapseReasonCode.LOW_SUGGESTION_RESPONSIVENESS,
                templates[LapseReasonCode.LOW_SUGGESTION_RESPONSIVENESS.value],
            )
        )

    if (
        extracted_features.wearable_signal_available
        and extracted_features.activity_signal_drop > 0.0
        and c_act >= min_contrib
    ):
        candidate_reasons.append(
            (
                c_act,
                5,
                LapseReasonCode.ACTIVITY_SIGNAL_DIP,
                templates[LapseReasonCode.ACTIVITY_SIGNAL_DIP.value],
            )
        )

    # Sort by descending contribution, then deterministic tie-breaker priority index
    candidate_reasons.sort(key=lambda item: (-item[0], item[1]))

    if state == LapseState.HEALTHY:
        reason_codes: tuple[LapseReasonCode, ...] = ()
        reasons: tuple[str, ...] = ()
    else:
        reason_codes = tuple(item[2] for item in candidate_reasons)
        reasons = tuple(item[3] for item in candidate_reasons)

    return Risk(
        score=final_score,
        state=state,
        reasons=reasons,
        reason_codes=reason_codes,
        feature_contributions=feature_contributions,
        policy_version=active_weights.version,
        should_trigger_recovery=state in {LapseState.LAPSE_RISK, LapseState.LAPSED},
    )


def steady_user_fixture(
    local_date: str = "2026-04-21",
) -> tuple[LapseHistoryInput, LapseSignalsInput, LapseContextInput]:
    """Steady user with consistent check-ins (6/7 in 7d, 24/28 in 28d) and regular schedule."""
    base = date.fromisoformat(local_date)
    checkins: list[CheckInDayRecord] = []
    for offset in range(28):
        d_str = (base - timedelta(days=offset)).isoformat()
        status: Literal["done", "partial", "skipped", "unanswered"] = (
            "skipped" if offset in {4, 11, 18, 25} else "done"
        )
        checkins.append(CheckInDayRecord(local_date=d_str, status=status))

    nudges = tuple(
        NudgeResponseRecord(
            local_date=(base - timedelta(days=offset)).isoformat(),
            responded=True,
        )
        for offset in range(5)
    )
    samples = tuple(
        DailyActivitySample(
            local_date=(base - timedelta(days=offset)).isoformat(),
            activity_value=7500.0,
        )
        for offset in range(28)
    )
    history = LapseHistoryInput(checkins=tuple(checkins), nudge_responses=nudges)
    signals = LapseSignalsInput(
        wearable_consented=True,
        sync_status=SensorSyncStatus.ACTIVE,
        daily_samples=samples,
    )
    context = LapseContextInput(
        user_id="persona-steady",
        local_date=local_date,
        enrolled_local_date=(base - timedelta(days=35)).isoformat(),
        work_pattern="office_9_to_5",
        night_shift_block_started_recently=False,
        work_pattern_changed_recently=False,
    )
    return history, signals, context


def wearable_off_fixture(
    local_date: str = "2026-04-21",
    *,
    sync_status: SensorSyncStatus = SensorSyncStatus.UNCONSENTED,
) -> tuple[LapseHistoryInput, LapseSignalsInput, LapseContextInput]:
    """Steady check-in user whose wearable is `UNCONSENTED` or `SYNC_MISSING`."""
    steady_history, _, steady_context = steady_user_fixture(local_date)
    consented = sync_status != SensorSyncStatus.UNCONSENTED
    signals = LapseSignalsInput(
        wearable_consented=consented,
        sync_status=sync_status,
        daily_samples=(),
        baseline_value=None,
        recent_value=None,
    )
    context = steady_context.model_copy(update={"user_id": f"persona-wearable-{sync_status.value}"})
    return steady_history, signals, context


def fatima_week3_fixture(
    local_date: str = "2026-04-21",
) -> tuple[LapseHistoryInput, LapseSignalsInput, LapseContextInput]:
    """Fatima (36, ICU nurse, shift work) in Week 3 after starting a night-shift block."""
    base = date.fromisoformat(local_date)
    checkins: list[CheckInDayRecord] = []
    # Days -20..-7 (Weeks 1-2): strong baseline (12 done, 2 partial -> ~93% completion)
    for offset in range(7, 21):
        d_str = (base - timedelta(days=offset)).isoformat()
        status: Literal["done", "partial", "skipped", "unanswered"] = (
            "partial" if offset in {10, 17} else "done"
        )
        checkins.append(CheckInDayRecord(local_date=d_str, status=status))

    # Days -6..0 (Week 3): night-shift transition; last active check-in was 2 days ago (day -2)
    week3_statuses: dict[int, Literal["done", "partial", "skipped", "unanswered"]] = {
        6: "done",
        5: "skipped",
        4: "partial",
        3: "skipped",
        2: "partial",
        1: "unanswered",
        0: "unanswered",
    }
    for offset, st in week3_statuses.items():
        checkins.append(
            CheckInDayRecord(
                local_date=(base - timedelta(days=offset)).isoformat(),
                status=st,
            )
        )

    nudges = (
        NudgeResponseRecord(local_date=(base - timedelta(days=3)).isoformat(), responded=False),
        NudgeResponseRecord(local_date=(base - timedelta(days=2)).isoformat(), responded=True),
        NudgeResponseRecord(local_date=(base - timedelta(days=1)).isoformat(), responded=False),
        NudgeResponseRecord(local_date=base.isoformat(), responded=False),
    )
    history = LapseHistoryInput(checkins=tuple(checkins), nudge_responses=nudges)
    signals = LapseSignalsInput(
        wearable_consented=True,
        sync_status=SensorSyncStatus.ACTIVE,
        baseline_value=8200.0,
        recent_value=5100.0,
    )
    context = LapseContextInput(
        user_id="persona-fatima-week3",
        local_date=local_date,
        enrolled_local_date=(base - timedelta(days=21)).isoformat(),
        work_pattern="shift",
        night_shift_block_started_recently=True,
        work_pattern_changed_recently=True,
    )
    return history, signals, context


def lapsed_multi_day_fixture(
    local_date: str = "2026-04-21",
) -> tuple[LapseHistoryInput, LapseSignalsInput, LapseContextInput]:
    """User with 4 consecutive days of zero check-ins and no active consented signal."""
    base = date.fromisoformat(local_date)
    checkins: list[CheckInDayRecord] = []
    for offset in range(4, 24):
        checkins.append(
            CheckInDayRecord(
                local_date=(base - timedelta(days=offset)).isoformat(),
                status="done",
            )
        )
    for offset in range(0, 4):
        checkins.append(
            CheckInDayRecord(
                local_date=(base - timedelta(days=offset)).isoformat(),
                status="unanswered",
            )
        )
    nudges = tuple(
        NudgeResponseRecord(
            local_date=(base - timedelta(days=offset)).isoformat(),
            responded=False,
        )
        for offset in range(4)
    )
    history = LapseHistoryInput(checkins=tuple(checkins), nudge_responses=nudges)
    signals = LapseSignalsInput(
        wearable_consented=False,
        sync_status=SensorSyncStatus.UNCONSENTED,
    )
    context = LapseContextInput(
        user_id="persona-lapsed-4d",
        local_date=local_date,
        enrolled_local_date=(base - timedelta(days=25)).isoformat(),
        work_pattern="day",
    )
    return history, signals, context
