"""Per-day context for the sandbox: work pattern, night-shift block, Ramadan and synthetic steps.

A ContextDay is one simulated day's situation. The Lapse Radar reads it, and the fasting window
comes from ``engine.policy.environment`` (Fajr to Maghrib), the engine's single source for the
fasting day.
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from engine.sandbox.cues import fasting_window
from engine.sandbox.personas import PERSONAS, synthetic_steps
from engine.sandbox.state import State

NIGHT_BLOCK_WINDOW_DAYS = 7
PATTERN_CHANGE_WINDOW_DAYS = 7
RAMADAN_WINDOW_DAYS = 3
FALLBACK_STEPS_BASELINE: tuple[int, ...] = (6000,) * 14

ContextDay = dict[str, Any]


def initial_context_day(state: State) -> ContextDay:
    """The context of the first simulated day, from the profile."""
    return {
        "date": state["current_date"],
        "work_pattern": state["profile"]["work_pattern"],
        "night_shift_block_day": None,
        "pattern_change_day": None,
        "ramadan": False,
        "ramadan_day": None,
        "fasting_window": None,
        "steps": None,
    }


def next_context_day(previous: ContextDay, on: str) -> ContextDay:
    """The next day's context: the same situation, with the day counters moved on by one."""

    def tick(value: int | None) -> int | None:
        return None if value is None else value + 1

    return {
        **previous,
        "date": on,
        "night_shift_block_day": tick(previous["night_shift_block_day"]),
        "pattern_change_day": tick(previous["pattern_change_day"]),
        "ramadan_day": tick(previous["ramadan_day"]),
        "steps": None,
    }


def latest_context(state: State) -> ContextDay:
    """The context of the current simulated day."""
    return state["context_days"][-1]  # type: ignore[no-any-return]


def with_latest_context(state: State, day: ContextDay) -> State:
    """A copy of ``state`` with the current day's context replaced."""
    return {**state, "context_days": [*state["context_days"][:-1], day]}


def add_days(iso: str, days: int) -> str:
    return (date.fromisoformat(iso) + timedelta(days=days)).isoformat()


# Pairs whose withdrawal changes how the plan is adapted (the radar lists its own in radar.py).
SCHEDULE_CONSENTS: tuple[str, ...] = (
    "work_pattern:schedule_adaptation",
    "ramadan_setting:schedule_adaptation",
)


def consent_granted(state: State, pair: str) -> bool:
    return bool(state["consent"][pair]["granted"])


def has_sensor(state: State) -> bool:
    """Whether this person has an activity sensor at all (a persona may have none)."""
    persona = PERSONAS.get(state["profile"]["persona_id"] or "")
    return True if persona is None else persona.wearable


def todays_steps(state: State, *, checked_in: bool) -> int | None:
    """Synthetic steps for the current day, or None without consent or a sensor."""
    persona = PERSONAS.get(state["profile"]["persona_id"] or "")
    baseline = persona.steps_baseline if persona else FALLBACK_STEPS_BASELINE
    on = date.fromisoformat(state["current_date"])
    day_index = (on - date.fromisoformat(state["start_date"])).days
    return synthetic_steps(
        baseline=baseline,
        day_index=day_index,
        night_shift_block_day=latest_context(state)["night_shift_block_day"],
        checked_in=checked_in,
        sensor_consent=consent_granted(state, "activity_sensor:risk_detection")
        and has_sensor(state),
        seed=state["seed"],
    )


__all__ = ["fasting_window"]
