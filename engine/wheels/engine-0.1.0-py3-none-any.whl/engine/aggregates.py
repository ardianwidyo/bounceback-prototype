"""Pure social support, k>=20 team aggregation, and append-only points engine (F14)."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Literal

MIN_POD_SIZE: int = 4
MAX_POD_SIZE: int = 8
MIN_TEAM_K_ANONYMITY: int = 20

POINTS_PARTIAL: int = 5
POINTS_DONE: int = 10
POINTS_RECOVERY_BONUS: int = 15

NON_LINKAGE_STATEMENT_EN: str = (
    "Participation and recognition points are for personal encouragement only and are never "
    "linked to insurance premiums, health coverage, or workplace HR decisions."
)
NON_LINKAGE_STATEMENT_AR: str = (
    "المشاركة ونقاط التقدير مخصصة للتشجيع الشخصي فقط ولا ترتبط أبداً بأقساط التأمين "
    "أو التغطية الصحية أو قرارات الموارد البشرية في العمل."
)

BuddyScopeLiteral = Literal[
    "active_days_only",
    "weekly_summary",
    "celebrate_milestones",
]
ALLOWED_BUDDY_SCOPES: tuple[BuddyScopeLiteral, ...] = (
    "active_days_only",
    "weekly_summary",
    "celebrate_milestones",
)

PointsEventTypeLiteral = Literal[
    "action_partial",
    "action_done",
    "action_upgrade_done",
    "recovery_bonus",
]
CheckInStatusOption = Literal["done", "partial", "not_today", "skipped"]


@dataclass(frozen=True, slots=True)
class PodProgressSnapshot:
    pod_slug: str
    member_count: int
    min_members: int
    max_members: int
    weekly_target_actions: int
    weekly_completed_actions: int
    progress_ratio: float
    goal_reached: bool
    individual_rankings_exposed: bool
    status_message_en: str
    status_message_ar: str


@dataclass(frozen=True, slots=True)
class BuddySubjectSnapshot:
    user_display_name: str
    cumulative_active_days: int
    weekly_completed_actions: int
    weekly_active_days: int
    milestone_codes: tuple[str, ...] = ()
    raw_checkin_notes: tuple[str, ...] = ()
    barrier_reasons: tuple[str, ...] = ()
    clinical_red_flags: tuple[str, ...] = ()
    coach_messages: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class BuddyProjection:
    buddy_display_name: str
    relationship_label: str
    granted_scopes: tuple[BuddyScopeLiteral, ...]
    cumulative_active_days: int | None
    weekly_completed_actions: int | None
    weekly_active_days: int | None
    milestones: tuple[str, ...]
    encouragement_en: str
    encouragement_ar: str


@dataclass(frozen=True, slots=True)
class TeamMemberContribution:
    member_key: str
    completed_actions: int
    active_days: int


@dataclass(frozen=True, slots=True)
class TeamAggregateResult:
    team_slug: str
    member_count: int
    min_k_threshold: int
    suppressed_k_anonymity: bool
    total_completed_actions: int | None
    total_active_days: int | None
    non_linkage_guaranteed: bool = True


@dataclass(frozen=True, slots=True)
class PointsAwardDraft:
    source_checkin_id: str
    event_type: PointsEventTypeLiteral
    points_delta: int


@dataclass(frozen=True, slots=True)
class PointsLedgerSummary:
    total_points: int
    entries_count: int
    breakdown_by_type: dict[str, int]
    never_decreases: bool = True
    non_linkage_guaranteed: bool = True


def compute_pod_progress(
    *,
    pod_slug: str,
    member_count: int,
    weekly_target_actions: int,
    weekly_completed_actions: int,
) -> PodProgressSnapshot:
    """Compute cooperative peer pod progress enforcing 4 <= member_count <= 8 and no rankings."""
    if member_count < MIN_POD_SIZE or member_count > MAX_POD_SIZE:
        raise ValueError(
            f"Cooperative peer pod member_count must be between {MIN_POD_SIZE} and {MAX_POD_SIZE}, "
            f"got {member_count}."
        )
    if weekly_target_actions < MIN_POD_SIZE:
        raise ValueError("weekly_target_actions must be at least 4.")
    if weekly_completed_actions < 0:
        raise ValueError("weekly_completed_actions cannot be negative.")

    ratio = min(1.0, round(weekly_completed_actions / float(weekly_target_actions), 4))
    reached = weekly_completed_actions >= weekly_target_actions

    if reached:
        status_en = (
            f"Together your pod completed {weekly_completed_actions} of "
            f"{weekly_target_actions} shared weekly steps."
        )
        status_ar = (
            f"أتمت مجموعتكم معاً {weekly_completed_actions} من أصل "
            f"{weekly_target_actions} خطوة أسبوعية مشتركة."
        )
    else:
        status_en = (
            f"Your pod has shared {weekly_completed_actions} of {weekly_target_actions} "
            "cooperative steps this week. Every small step counts."
        )
        status_ar = (
            f"شاركت مجموعتكم {weekly_completed_actions} من أصل {weekly_target_actions} "
            "خطوة تعاونية هذا الأسبوع. كل خطوة صغيرة تُحدث فرقاً."
        )

    return PodProgressSnapshot(
        pod_slug=pod_slug,
        member_count=member_count,
        min_members=MIN_POD_SIZE,
        max_members=MAX_POD_SIZE,
        weekly_target_actions=weekly_target_actions,
        weekly_completed_actions=weekly_completed_actions,
        progress_ratio=ratio,
        goal_reached=reached,
        individual_rankings_exposed=False,
        status_message_en=status_en,
        status_message_ar=status_ar,
    )


def project_buddy_view(
    *,
    subject: BuddySubjectSnapshot,
    buddy_display_name: str,
    relationship_label: str,
    scopes: Sequence[str],
) -> BuddyProjection:
    """Construct a whitelist-only family buddy projection based on user-selected scopes."""
    normalized: list[BuddyScopeLiteral] = []
    for raw_scope in scopes:
        if raw_scope not in ALLOWED_BUDDY_SCOPES:
            raise ValueError(f"Unsupported buddy sharing scope: {raw_scope}")
        if raw_scope not in normalized:
            normalized.append(raw_scope)

    if not normalized:
        raise ValueError("At least one buddy sharing scope is required.")

    granted = tuple(normalized)
    include_active_days = "active_days_only" in granted
    include_weekly = "weekly_summary" in granted
    include_milestones = "celebrate_milestones" in granted

    encouragement_en = (
        f"{subject.user_display_name} is building steady healthy habits at a comfortable pace."
    )
    encouragement_ar = f"{subject.user_display_name} يبني عادات صحية هادئة بوتيرة مريحة."

    return BuddyProjection(
        buddy_display_name=buddy_display_name,
        relationship_label=relationship_label,
        granted_scopes=granted,
        cumulative_active_days=subject.cumulative_active_days if include_active_days else None,
        weekly_completed_actions=subject.weekly_completed_actions if include_weekly else None,
        weekly_active_days=subject.weekly_active_days if include_weekly else None,
        milestones=subject.milestone_codes if include_milestones else (),
        encouragement_en=encouragement_en,
        encouragement_ar=encouragement_ar,
    )


def compute_team_aggregate(
    team_slug: str,
    contributions: Sequence[TeamMemberContribution],
    *,
    min_k: int = MIN_TEAM_K_ANONYMITY,
) -> TeamAggregateResult:
    """Compute workplace team aggregate enforcing hard k >= 20 k-anonymity."""
    effective_k = max(min_k, MIN_TEAM_K_ANONYMITY)
    deduped: dict[str, TeamMemberContribution] = {}
    for item in contributions:
        if item.completed_actions < 0 or item.active_days < 0:
            raise ValueError("TeamMemberContribution counts cannot be negative.")
        deduped[item.member_key] = item

    member_count = len(deduped)
    if member_count < effective_k:
        return TeamAggregateResult(
            team_slug=team_slug,
            member_count=member_count,
            min_k_threshold=effective_k,
            suppressed_k_anonymity=True,
            total_completed_actions=None,
            total_active_days=None,
            non_linkage_guaranteed=True,
        )

    total_actions = sum(m.completed_actions for m in deduped.values())
    total_days = sum(m.active_days for m in deduped.values())
    return TeamAggregateResult(
        team_slug=team_slug,
        member_count=member_count,
        min_k_threshold=effective_k,
        suppressed_k_anonymity=False,
        total_completed_actions=total_actions,
        total_active_days=total_days,
        non_linkage_guaranteed=True,
    )


def calculate_checkin_points(
    *,
    check_in_id: str,
    previous_status: CheckInStatusOption | None,
    new_status: CheckInStatusOption,
    is_recovery_checkin: bool,
    existing_event_types: Sequence[str] = (),
) -> tuple[PointsAwardDraft, ...]:
    """Calculate append-only, strictly positive point awards for a check-in transition."""
    if new_status in ("not_today", "skipped"):
        return ()

    existing = set(existing_event_types)
    awards: list[PointsAwardDraft] = []

    if new_status == "partial":
        if (
            "action_partial" not in existing
            and "action_done" not in existing
            and "action_upgrade_done" not in existing
        ):
            awards.append(
                PointsAwardDraft(
                    source_checkin_id=check_in_id,
                    event_type="action_partial",
                    points_delta=POINTS_PARTIAL,
                )
            )
    elif (
        new_status == "done"
        and "action_done" not in existing
        and "action_upgrade_done" not in existing
    ):
        if "action_partial" in existing or previous_status == "partial":
            if "action_partial" not in existing:
                awards.append(
                    PointsAwardDraft(
                        source_checkin_id=check_in_id,
                        event_type="action_partial",
                        points_delta=POINTS_PARTIAL,
                    )
                )
            awards.append(
                PointsAwardDraft(
                    source_checkin_id=check_in_id,
                    event_type="action_upgrade_done",
                    points_delta=POINTS_DONE - POINTS_PARTIAL,
                )
            )
        else:
            awards.append(
                PointsAwardDraft(
                    source_checkin_id=check_in_id,
                    event_type="action_done",
                    points_delta=POINTS_DONE,
                )
            )

    if is_recovery_checkin and "recovery_bonus" not in existing:
        awards.append(
            PointsAwardDraft(
                source_checkin_id=check_in_id,
                event_type="recovery_bonus",
                points_delta=POINTS_RECOVERY_BONUS,
            )
        )

    return tuple(awards)


def summarize_points_ledger(
    entries: Sequence[PointsAwardDraft],
) -> PointsLedgerSummary:
    """Summarize append-only points ledger entries while verifying points_delta > 0."""
    breakdown: dict[str, int] = {}
    total = 0
    for entry in entries:
        if entry.points_delta <= 0:
            raise ValueError("Points ledger entries must have points_delta > 0.")
        total += entry.points_delta
        breakdown[entry.event_type] = breakdown.get(entry.event_type, 0) + entry.points_delta

    return PointsLedgerSummary(
        total_points=total,
        entries_count=len(entries),
        breakdown_by_type=breakdown,
        never_decreases=True,
        non_linkage_guaranteed=True,
    )
