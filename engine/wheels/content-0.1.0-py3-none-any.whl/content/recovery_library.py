"""Versioned recovery rules and bilingual message catalogues (F06, Principles II, III, IV)."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from functools import lru_cache
from pathlib import Path
from typing import Any, Literal

import yaml

from content.library import Behaviour

Locale = Literal["en", "ar", "ur", "hi", "tl", "ml"]
SUPPORTED_RECOVERY_LOCALES: tuple[Locale, ...] = ("en", "ar", "ur", "hi", "tl", "ml")

DEFAULT_RECOVERY_RULES_PATH = Path(__file__).with_name("recovery_rules.yaml")
DEFAULT_MESSAGES_DIR = Path(__file__).with_name("messages")
DEFAULT_LOCALES_DIR = Path(__file__).with_name("locales")


class BarrierCode(StrEnum):
    TIME = "time"
    TIRED = "tired"
    PAIN_OR_ILLNESS = "pain_or_illness"
    LOW_MOOD = "low_mood"
    TRAVEL = "travel"
    RAMADAN_FASTING = "ramadan_fasting"
    COST = "cost"
    FAMILY = "family"
    NOT_FEELING_IT = "not_feeling_it"
    OTHER = "other"
    NO_ANSWER = "no_answer"


USER_SELECTABLE_BARRIERS: tuple[BarrierCode, ...] = (
    BarrierCode.TIME,
    BarrierCode.TIRED,
    BarrierCode.PAIN_OR_ILLNESS,
    BarrierCode.LOW_MOOD,
    BarrierCode.TRAVEL,
    BarrierCode.RAMADAN_FASTING,
    BarrierCode.COST,
    BarrierCode.FAMILY,
    BarrierCode.NOT_FEELING_IT,
    BarrierCode.OTHER,
)


class CueStrategy(StrEnum):
    POST_SHIFT_OR_ANCHORS = "post_shift_or_anchors"
    POST_SHIFT_OR_REST = "post_shift_or_rest"
    GENTLE_RECOVERY = "gentle_recovery"
    AFTER_IFTAR = "after_iftar"
    PORTABLE_ANYTIME = "portable_anytime"
    NO_COST_HOME = "no_cost_home"
    FLEXIBLE_FAMILY_WINDOW = "flexible_family_window"
    FRESH_SMALLEST_STEP = "fresh_smallest_step"
    KEEP_OR_SOFTEN = "keep_or_soften"


@dataclass(frozen=True, slots=True)
class RecoveryRule:
    barrier: BarrierCode
    user_selectable: bool = True
    level_delta: int = -1
    max_duration_min: int = 5
    max_actions: int | None = None
    cue_strategy: CueStrategy = CueStrategy.KEEP_OR_SOFTEN
    pause_behaviours: tuple[Behaviour, ...] = ()
    substitute_behaviours: tuple[Behaviour, ...] = ()
    avoid_context_tags: tuple[str, ...] = ()
    prefer_alternate_action: bool = False
    recommends_health_professional: bool = False


@dataclass(frozen=True, slots=True)
class RecoveryRulesCatalogue:
    version: str
    rules: Mapping[BarrierCode, RecoveryRule]

    def get(self, barrier: BarrierCode | str) -> RecoveryRule:
        code = BarrierCode(barrier)
        return self.rules[code]

    def user_selectable_rules(self) -> tuple[RecoveryRule, ...]:
        return tuple(
            self.rules[code]
            for code in USER_SELECTABLE_BARRIERS
            if code in self.rules and self.rules[code].user_selectable
        )


@dataclass(frozen=True, slots=True)
class BarrierMessageItem:
    code: BarrierCode
    label: str
    info_note: str


@dataclass(frozen=True, slots=True)
class RecoveryMessagesCatalogue:
    locale: Locale
    offer_eyebrow: str
    offer_title: str
    offer_body: str
    offer_primary_cta: str
    offer_secondary_cta: str
    barrier_question: str
    barrier_optional_tag: str
    barriers: Mapping[BarrierCode, BarrierMessageItem]
    health_professional_note: str
    smaller_plan_title: str
    smaller_plan_subtitle: str
    step_up_eyebrow: str
    step_up_title: str
    step_up_body: str
    step_up_accept_cta: str
    step_up_decline_cta: str


def _parse_rule(barrier_key: str, raw: Mapping[str, Any]) -> RecoveryRule:
    code = BarrierCode(barrier_key)
    max_actions_raw = raw.get("max_actions")
    max_actions = int(max_actions_raw) if max_actions_raw is not None else None
    return RecoveryRule(
        barrier=code,
        user_selectable=bool(raw.get("user_selectable", True)),
        level_delta=int(raw.get("level_delta", -1)),
        max_duration_min=int(raw.get("max_duration_min", 5)),
        max_actions=max_actions,
        cue_strategy=CueStrategy(str(raw["cue_strategy"])),
        pause_behaviours=tuple(Behaviour(b) for b in raw.get("pause_behaviours", ())),
        substitute_behaviours=tuple(Behaviour(b) for b in raw.get("substitute_behaviours", ())),
        avoid_context_tags=tuple(str(t) for t in raw.get("avoid_context_tags", ())),
        prefer_alternate_action=bool(raw.get("prefer_alternate_action", False)),
        recommends_health_professional=bool(raw.get("recommends_health_professional", False)),
    )


@lru_cache(maxsize=4)
def load_recovery_rules(path: Path | None = None) -> RecoveryRulesCatalogue:
    """Load and validate the declarative recovery rules catalogue."""
    target = path or DEFAULT_RECOVERY_RULES_PATH
    data = yaml.safe_load(target.read_text(encoding="utf-8"))
    if not isinstance(data, Mapping):
        raise ValueError(f"Invalid recovery rules YAML in {target}")
    version = str(data.get("version", "")).strip()
    if not version:
        raise ValueError("recovery_rules.yaml must declare a non-empty version")
    raw_rules = data.get("rules")
    if not isinstance(raw_rules, Mapping):
        raise ValueError("recovery_rules.yaml must contain a 'rules' mapping")

    parsed: dict[BarrierCode, RecoveryRule] = {}
    for key, val in raw_rules.items():
        if not isinstance(val, Mapping):
            raise ValueError(f"Rule {key!r} must be a mapping")
        rule = _parse_rule(str(key), val)
        parsed[rule.barrier] = rule

    missing = set(BarrierCode) - set(parsed.keys())
    if missing:
        missing_str = ", ".join(sorted(m.value for m in missing))
        raise ValueError(f"recovery_rules.yaml missing barrier definitions: {missing_str}")

    return RecoveryRulesCatalogue(version=version, rules=parsed)


@lru_cache(maxsize=12)
def load_recovery_messages(
    locale: Locale = "en",
    path: Path | None = None,
) -> RecoveryMessagesCatalogue:
    """Load localized recovery copy for 'en', 'ar', 'ur', 'hi', 'tl', or 'ml'."""
    if locale not in SUPPORTED_RECOVERY_LOCALES:
        raise ValueError(
            f"Unsupported locale {locale!r}; expected one of {SUPPORTED_RECOVERY_LOCALES}"
        )
    if path is not None:
        target = path
        data = yaml.safe_load(target.read_text(encoding="utf-8"))
    elif locale in ("en", "ar"):
        target = DEFAULT_MESSAGES_DIR / f"recovery.{locale}.yaml"
        data = yaml.safe_load(target.read_text(encoding="utf-8"))
    else:
        target = DEFAULT_LOCALES_DIR / "recovery_locales.yaml"
        bundle = yaml.safe_load(target.read_text(encoding="utf-8"))
        data = bundle.get(locale) if isinstance(bundle, Mapping) else None
    if not isinstance(data, Mapping):
        raise ValueError(f"Invalid recovery messages YAML in {target}")

    raw_barriers = data.get("barriers")
    if not isinstance(raw_barriers, Mapping):
        raise ValueError(f"Recovery messages file {target} missing 'barriers' mapping")

    barriers: dict[BarrierCode, BarrierMessageItem] = {}
    for code in USER_SELECTABLE_BARRIERS:
        entry = raw_barriers.get(code.value)
        if not isinstance(entry, Mapping):
            raise ValueError(f"Missing barrier copy for {code.value!r} in {target}")
        label = str(entry.get("label", "")).strip()
        info_note = str(entry.get("info_note", "")).strip()
        if not label or not info_note:
            raise ValueError(f"Empty label or info_note for {code.value!r} in {target}")
        barriers[code] = BarrierMessageItem(code=code, label=label, info_note=info_note)

    return RecoveryMessagesCatalogue(
        locale=locale,
        offer_eyebrow=str(data["offer_eyebrow"]).strip(),
        offer_title=str(data["offer_title"]).strip(),
        offer_body=str(data["offer_body"]).strip(),
        offer_primary_cta=str(data["offer_primary_cta"]).strip(),
        offer_secondary_cta=str(data["offer_secondary_cta"]).strip(),
        barrier_question=str(data["barrier_question"]).strip(),
        barrier_optional_tag=str(data["barrier_optional_tag"]).strip(),
        barriers=barriers,
        health_professional_note=str(data["health_professional_note"]).strip(),
        smaller_plan_title=str(data["smaller_plan_title"]).strip(),
        smaller_plan_subtitle=str(data["smaller_plan_subtitle"]).strip(),
        step_up_eyebrow=str(data["step_up_eyebrow"]).strip(),
        step_up_title=str(data["step_up_title"]).strip(),
        step_up_body=str(data["step_up_body"]).strip(),
        step_up_accept_cta=str(data["step_up_accept_cta"]).strip(),
        step_up_decline_cta=str(data["step_up_decline_cta"]).strip(),
    )
