"""Fixed participant copy keys and the biomarker forbidden-term scan (F21 FR-010; research R10).

The summary never uses generated text: the API returns i18n keys and the apps render approved
strings. ``scan_copy`` flags diagnostic or value-judging words in any approved string.
"""

from __future__ import annotations

import re
from typing import Final

from engine.sahatna_health_age import FORBIDDEN_BLAME_AND_ALARM_TERMS

SUMMARY_PREFIX: Final = "biomarkers.summary"
SAFETY_NOTE_KEY: Final = f"{SUMMARY_PREFIX}.safetyNote"
SUMMARY_COPY_KEYS: Final = (
    f"{SUMMARY_PREFIX}.title",
    f"{SUMMARY_PREFIX}.careTeamNote",
    f"{SUMMARY_PREFIX}.activeDays",
)
ALL_SUMMARY_KEYS: Final = (
    "title",
    "baseline",
    "latest",
    "changedBy",
    "noResult",
    "notRetrieved",
    "activeDays",
    "careTeamNote",
    "safetyNote",
    "optionKeepPlan",
    "optionTalkCareTeam",
    "notNow",
    "leaveOutBodyMeasures",
)

FORBIDDEN_BIOMARKER_TERMS_EN: Final = (
    "high",
    "low",
    "normal",
    "abnormal",
    "better",
    "worse",
    "improved",
    "risk",
    "diabetic",
    "pre-diabetic",
    "hypertension",
)
FORBIDDEN_BIOMARKER_TERMS_AR: Final = (
    "مرتفع",
    "منخفض",
    "طبيعي",
    "غير طبيعي",
    "أفضل",
    "أسوأ",
    "تحسن",
    "خطر",
    "سكري",
    "ما قبل السكري",
    "ارتفاع ضغط الدم",
)

_EN_PATTERN: Final = re.compile(
    r"\b(" + "|".join(re.escape(term) for term in FORBIDDEN_BIOMARKER_TERMS_EN) + r")\b",
    re.IGNORECASE,
)


def scan_copy(text: str) -> tuple[str, ...]:
    """Forbidden terms found in ``text`` (empty tuple when the copy is acceptable)."""
    found = [match.group(1).lower() for match in _EN_PATTERN.finditer(text)]
    found += [term for term in FORBIDDEN_BIOMARKER_TERMS_AR if term in text]
    lowered = text.lower()
    found += [term for term in FORBIDDEN_BLAME_AND_ALARM_TERMS if term in lowered]
    return tuple(dict.fromkeys(found))
