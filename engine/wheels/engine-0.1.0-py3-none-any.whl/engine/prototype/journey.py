"""Run one synthetic user through the real BounceBack engine, day by day (clickable prototype).

Every decision shown in the prototype comes from the production engine functions:
``build_plan`` (F02), ``lapse_radar.features/score`` (F05), ``plan_downshift`` (F06) and
``evaluate_step_up_eligibility``/``plan_step_up`` (F06). Nothing here invents a decision; this
module only scripts check-ins and serialises the results to JSON-safe dicts.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any, Literal, cast

from content.library import Behaviour, Library
from content.recovery_library import USER_SELECTABLE_BARRIERS, load_recovery_messages
from engine.lapse_radar import (
    CheckInDayRecord,
    DailyActivitySample,
    LapseContextInput,
    LapseHistoryInput,
    LapseSignalsInput,
    NudgeResponseRecord,
    Risk,
    SensorSyncStatus,
    features,
    score,
)
from engine.plan_builder import (
    CombScores,
    ContextInput,
    GoalInput,
    PlanDraft,
    PlannedActionDraft,
    build_plan,
)
from engine.progress import CheckInEntry, active_days
from engine.prototype.synthea import SyntheaProfile
from engine.recovery import (
    RecoveryContextInput,
    RecoveryPlanDraft,
    evaluate_step_up_eligibility,
    plan_downshift,
    plan_step_up,
)

Status = Literal["done", "partial", "skipped", "unanswered"]
WorkPattern = Literal["day", "rotating", "nights"]

VALID_STATUSES: frozenset[str] = frozenset({"done", "partial", "skipped", "unanswered"})
ACTIVE_STATUSES: frozenset[str] = frozenset({"done", "partial"})
STEP_UP_REQUIRED_CHECKINS = 5
NIGHT_BLOCK_WINDOW_DAYS = 7
# Synthetic wearable step counts per check-in status (only used when the persona consented).
STEPS_BY_STATUS: dict[str, float] = {
    "done": 7600.0,
    "partial": 5400.0,
    "skipped": 3100.0,
    "unanswered": 2600.0,
}


@dataclass(frozen=True, slots=True)
class JourneyScript:
    """Scripted inputs a person would give in the app, plus their simulated check-ins."""

    persona_id: str
    why: str
    work_pattern: WorkPattern
    barriers: tuple[str, ...]
    comb: tuple[int, int, int]
    daily_statuses: tuple[str, ...]
    work_change_day: int | None
    lapse_barrier: str
    wearable: bool
    seed: int


def _validate(script: JourneyScript) -> None:
    unknown = sorted(set(script.daily_statuses) - VALID_STATUSES)
    if unknown:
        raise ValueError(
            f"unknown check-in status {unknown}; expected one of {sorted(VALID_STATUSES)}"
        )
    if not script.daily_statuses:
        raise ValueError("daily_statuses must not be empty")


# ---------------------------------------------------------------- serialisation helpers


def _action_dict(action: PlannedActionDraft, library: Library) -> dict[str, Any]:
    micro = library.get(action.action_id)
    why = micro.why_card.en if micro else None
    return {
        "id": action.id,
        "action_id": action.action_id,
        "behaviour": action.behaviour.value,
        "level": action.level.value,
        "duration_min": action.duration_min,
        "cue": action.cue_en,
        "action_text": action.action_text_en,
        "if_then": action.if_then_en,
        "reason": action.reason_en,
        "bct_codes": list(action.bct_codes),
        "propensity": action.propensity,
        "why_card": {
            "evidence_level": micro.why_card.evidence_level if micro else "",
            "technique_label": why.technique_label if why else "",
            "idea": why.idea if why else "",
            "evidence_summary": why.evidence_summary if why else "",
            "limits": list(why.limits) if why else [],
        },
    }


def _plan_dict(plan: PlanDraft, library: Library) -> dict[str, Any]:
    audit = plan.audit
    return {
        "start_level": plan.start_level.value,
        "library_version": plan.library_version,
        "actions": [_action_dict(a, library) for a in plan.actions],
        "audit": {
            "policy_version": audit.policy_version,
            "seed": audit.seed,
            "excluded_action_ids": list(audit.excluded_action_ids),
            "candidate_ids_by_slot": [list(s) for s in audit.candidate_ids_by_slot],
            "chosen_action_ids": list(audit.chosen_action_ids),
            "propensities": list(audit.propensities),
            "inputs_summary": audit.inputs_summary,
        },
    }


def _risk_dict(risk: Risk) -> dict[str, Any]:
    return {
        "score": risk.score,
        "state": risk.state.value,
        "reasons": list(risk.reasons),
        "reason_codes": [c.value for c in risk.reason_codes],
        "contributions": dict(risk.feature_contributions),
        "policy_version": risk.policy_version,
        "should_trigger_recovery": risk.should_trigger_recovery,
    }


def _recovery_option(
    draft: RecoveryPlanDraft, label: str, info_note: str, library: Library
) -> dict[str, Any]:
    return {
        "label": label,
        "info_note": info_note,
        "rule_version": draft.rule_version,
        "paused_behaviours": [b.value for b in draft.paused_behaviours],
        "recommends_health_professional": draft.recommends_health_professional,
        "health_professional_note": draft.health_professional_note_en,
        "comparisons": [
            {
                "before": _action_dict(c.previous_action, library),
                "after": _action_dict(c.adapted_action, library),
                "change_kind": c.change_kind,
                "change_reason": c.change_reason_en,
            }
            for c in draft.comparisons
        ],
        "plan": _plan_dict(draft.plan_draft, library),
    }


# ---------------------------------------------------------------- engine steps


def _onboarding(
    profile: SyntheaProfile, script: JourneyScript
) -> tuple[GoalInput, ContextInput, CombScores]:
    behaviours = tuple(Behaviour(b) for b in profile.suggested_behaviours) or (Behaviour.MOVEMENT,)
    goals = GoalInput(behaviours=behaviours, why=script.why)
    context = ContextInput(
        work_pattern=script.work_pattern,
        barriers=script.barriers,
        contraindications=profile.contraindications,
    )
    capability, opportunity, motivation = script.comb
    return goals, context, CombScores(capability, opportunity, motivation)


def _signals(script: JourneyScript, statuses: list[CheckInDayRecord]) -> LapseSignalsInput:
    if not script.wearable:
        return LapseSignalsInput()
    samples = tuple(
        DailyActivitySample(local_date=r.local_date, activity_value=STEPS_BY_STATUS[r.status])
        for r in statuses
    )
    return LapseSignalsInput(
        wearable_consented=True, sync_status=SensorSyncStatus.ACTIVE, daily_samples=samples
    )


def _score_day(
    profile: SyntheaProfile,
    script: JourneyScript,
    records: list[CheckInDayRecord],
    day: int,
    start: date,
) -> Risk:
    today = start + timedelta(days=day)
    nudges = tuple(
        NudgeResponseRecord(local_date=r.local_date, responded=r.status in ACTIVE_STATUSES)
        for r in records[-7:]
    )
    in_block = (
        script.work_change_day is not None
        and 0 <= day - script.work_change_day < NIGHT_BLOCK_WINDOW_DAYS
    )
    context = LapseContextInput(
        user_id=profile.patient_id,
        local_date=today.isoformat(),
        enrolled_local_date=start.isoformat(),
        work_pattern=script.work_pattern,
        night_shift_block_started_recently=in_block,
        work_pattern_changed_recently=in_block,
    )
    history = LapseHistoryInput(checkins=tuple(records), nudge_responses=nudges)
    return score(features(history, _signals(script, records), context))


def _recovery_options(plan: PlanDraft, script: JourneyScript, library: Library) -> dict[str, Any]:
    messages = load_recovery_messages("en")
    ctx = RecoveryContextInput(shift_type=script.work_pattern)
    options: dict[str, Any] = {}
    for barrier in USER_SELECTABLE_BARRIERS:
        msg = messages.barriers[barrier]
        draft = plan_downshift(plan, barrier, library, ctx)
        options[barrier.value] = _recovery_option(draft, msg.label, msg.info_note, library)
    return options


def _recovery_copy() -> dict[str, str]:
    m = load_recovery_messages("en")
    return {
        "offer_eyebrow": m.offer_eyebrow,
        "offer_title": m.offer_title,
        "offer_body": m.offer_body,
        "offer_primary_cta": m.offer_primary_cta,
        "offer_secondary_cta": m.offer_secondary_cta,
        "barrier_question": m.barrier_question,
        "smaller_plan_title": m.smaller_plan_title,
        "smaller_plan_subtitle": m.smaller_plan_subtitle,
        "step_up_eyebrow": m.step_up_eyebrow,
        "step_up_title": m.step_up_title,
        "step_up_body": m.step_up_body,
        "step_up_accept_cta": m.step_up_accept_cta,
        "step_up_decline_cta": m.step_up_decline_cta,
    }


def _timeline(
    profile: SyntheaProfile, script: JourneyScript, start: date
) -> tuple[list[dict[str, Any]], int | None, int | None]:
    """Score every day; return (days, recovery trigger day, step-up eligible day)."""
    records: list[CheckInDayRecord] = []
    entries: list[CheckInEntry] = []
    days: list[dict[str, Any]] = []
    trigger: int | None = None
    step_up_day: int | None = None
    completed_since = 0
    for day, status in enumerate(script.daily_statuses):
        local = start + timedelta(days=day)
        records.append(CheckInDayRecord(local_date=local.isoformat(), status=cast(Status, status)))
        if status != "unanswered":
            entries.append(CheckInEntry(local_date=local, status=cast(Any, status)))
        risk = _score_day(profile, script, records, day, start)
        if trigger is None and risk.should_trigger_recovery:
            trigger = day
        elif trigger is not None and status in ACTIVE_STATUSES and step_up_day is None:
            completed_since += 1
            if completed_since == STEP_UP_REQUIRED_CHECKINS:
                step_up_day = day
        days.append(
            {
                "day": day,
                "date": local.isoformat(),
                "status": status,
                "active_days": active_days(entries),
                "phase": _phase(day, trigger, step_up_day),
                "risk": _risk_dict(risk),
            }
        )
    return days, trigger, step_up_day


def _phase(day: int, trigger: int | None, step_up_day: int | None) -> str:
    if trigger is None or day < trigger:
        return "plan"
    if day == trigger:
        return "lapse_detected"
    if step_up_day is not None and day >= step_up_day:
        return "step_up"
    return "recovery"


def run_journey(
    profile: SyntheaProfile, script: JourneyScript, library: Library, start: date
) -> dict[str, Any]:
    """Return a JSON-safe trace of one persona's journey through the real engine."""
    _validate(script)
    goals, context, comb = _onboarding(profile, script)
    plan = build_plan(goals, context, comb, library, seed=script.seed)
    days, trigger, step_up_day = _timeline(profile, script, start)

    recovery: dict[str, Any] | None = None
    step_up: dict[str, Any] | None = None
    if trigger is not None:
        options = _recovery_options(plan, script, library)
        recovery = {
            "day": trigger,
            "default_barrier": script.lapse_barrier,
            "active_days_intact": days[trigger]["active_days"],
            "copy": _recovery_copy(),
            "options": options,
        }
        if step_up_day is not None:
            downshifted = plan_downshift(
                plan,
                script.lapse_barrier,
                library,
                RecoveryContextInput(shift_type=script.work_pattern),
            )
            eligibility = evaluate_step_up_eligibility(
                plan_created_by="recovery",
                completed_checkins_since_version=STEP_UP_REQUIRED_CHECKINS,
            )
            stepped = plan_step_up(downshifted.plan_draft, plan, library)
            step_up = {
                "day": step_up_day,
                "eligibility": eligibility.model_dump(),
                "plan": _plan_dict(stepped, library),
            }

    return {
        "persona_id": script.persona_id,
        "start_date": start.isoformat(),
        "onboarding": {
            "behaviours": [b.value for b in goals.behaviours],
            "why": goals.why,
            "work_pattern": context.work_pattern,
            "barriers": list(context.barriers),
            "contraindications": list(context.contraindications),
            "comb": {
                "capability": comb.capability,
                "opportunity": comb.opportunity,
                "motivation": comb.motivation,
            },
            "wearable_consented": script.wearable,
        },
        "plan": _plan_dict(plan, library),
        "days": days,
        "lapse": {"trigger_day": trigger, "work_change_day": script.work_change_day},
        "recovery": recovery,
        "step_up": step_up,
    }
