"""Synthea FHIR R4 bundle -> BounceBack onboarding profile (clickable prototype).

Only synthetic records are accepted (constitution Principle IV): a bundle must carry the Synthea
patient identifier system. Clinical codes are used solely to pre-fill onboarding and to exclude
contraindicated micro-actions; they never produce clinical advice.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import date
from typing import Any

SYNTHEA_IDENTIFIER_SYSTEM = "https://github.com/synthetichealth/synthea"

LOINC_BMI = "39156-5"
LOINC_TOBACCO_STATUS = "72166-2"
SNOMED_DAILY_SMOKER = "449868002"
BMI_MOVEMENT_THRESHOLD = 25.0
MAX_SUGGESTED_BEHAVIOURS = 2

# SNOMED CT -> content-library contraindication tag (see packages/content actions.yaml).
CONTRAINDICATION_BY_SNOMED: Mapping[str, str] = {
    "53741008": "cardiac_condition",  # Coronary heart disease
    "22298006": "cardiac_condition",  # Myocardial infarction
    "88805009": "cardiac_condition",  # Chronic congestive heart failure
    "239873007": "mobility_limitation",  # Osteoarthritis of knee
    "239872002": "mobility_limitation",  # Osteoarthritis of hip
    "69896004": "mobility_limitation",  # Rheumatoid arthritis
}

# SNOMED CT -> behaviour suggested at onboarding (user can always change it).
BEHAVIOUR_BY_SNOMED: Mapping[str, str] = {
    "15777000": "nutrition",  # Prediabetes
    "44054006": "nutrition",  # Type 2 diabetes
    "59621000": "movement",  # Essential hypertension
    "162864005": "movement",  # Body mass index 30+ - obesity
    "73430006": "sleep",  # Sleep apnea
    "193462001": "sleep",  # Insomnia
}

_ACTIVE_CLINICAL_STATUSES = frozenset({"active", "recurrence", "relapse"})
_AGE_BANDS: tuple[tuple[int, int, str], ...] = (
    (18, 29, "18-29"),
    (30, 44, "30-44"),
    (45, 59, "45-59"),
    (60, 74, "60-74"),
    (75, 200, "75+"),
)


class SyntheaBundleError(ValueError):
    """Raised when a bundle is malformed or not a synthetic (Synthea) record."""


@dataclass(frozen=True, slots=True)
class SyntheaProfile:
    patient_id: str
    display_name: str
    gender: str
    age: int
    age_band: str
    preferred_language: str
    contraindications: tuple[str, ...]
    suggested_behaviours: tuple[str, ...]
    is_daily_smoker: bool
    bmi: float | None
    findings: tuple[str, ...]


def _resources(bundle: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    if bundle.get("resourceType") != "Bundle":
        raise SyntheaBundleError("expected a FHIR Bundle")
    entries = bundle.get("entry")
    if not isinstance(entries, list) or not entries:
        raise SyntheaBundleError("bundle has no entries")
    return [e["resource"] for e in entries if isinstance(e, Mapping) and "resource" in e]


def _codes(concept: Mapping[str, Any] | None) -> list[Mapping[str, Any]]:
    if not isinstance(concept, Mapping):
        return []
    coding = concept.get("coding")
    return [c for c in coding if isinstance(c, Mapping)] if isinstance(coding, list) else []


def _first_code(concept: Mapping[str, Any] | None) -> str | None:
    codes = _codes(concept)
    code = codes[0].get("code") if codes else None
    return code if isinstance(code, str) else None


def _find_patient(resources: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    patients = [r for r in resources if r.get("resourceType") == "Patient"]
    if len(patients) != 1:
        raise SyntheaBundleError("bundle must contain exactly one Patient")
    patient = patients[0]
    identifiers = patient.get("identifier") or []
    if not any(
        isinstance(i, Mapping) and i.get("system") == SYNTHEA_IDENTIFIER_SYSTEM for i in identifiers
    ):
        raise SyntheaBundleError("Patient is not marked as a synthetic (Synthea) record")
    return patient


def _age(birth_date: object, as_of: date) -> int:
    if not isinstance(birth_date, str):
        raise SyntheaBundleError("Patient.birthDate is required")
    try:
        born = date.fromisoformat(birth_date)
    except ValueError as exc:
        raise SyntheaBundleError(f"invalid Patient.birthDate {birth_date!r}") from exc
    had_birthday = (as_of.month, as_of.day) >= (born.month, born.day)
    return as_of.year - born.year - (0 if had_birthday else 1)


def _age_band(age: int) -> str:
    for low, high, label in _AGE_BANDS:
        if low <= age <= high:
            return label
    raise SyntheaBundleError(f"prototype supports adults only (age {age})")


def _display_name(patient: Mapping[str, Any]) -> str:
    names = patient.get("name") or []
    given = names[0].get("given") if names and isinstance(names[0], Mapping) else None
    if isinstance(given, list) and given and isinstance(given[0], str):
        return "".join(ch for ch in given[0] if not ch.isdigit())  # Synthea appends digits
    return "Synthetic user"


def _language(patient: Mapping[str, Any]) -> str:
    comms = patient.get("communication") or []
    code = (
        _first_code(comms[0].get("language")) if comms and isinstance(comms[0], Mapping) else None
    )
    return (code or "en").split("-")[0]


def _active_conditions(resources: Sequence[Mapping[str, Any]]) -> list[tuple[str, str]]:
    found: list[tuple[str, str]] = []
    for res in resources:
        if res.get("resourceType") != "Condition":
            continue
        if _first_code(res.get("clinicalStatus")) not in _ACTIVE_CLINICAL_STATUSES:
            continue
        codes = _codes(res.get("code"))
        if codes and isinstance(codes[0].get("code"), str):
            found.append((str(codes[0]["code"]), str(codes[0].get("display", codes[0]["code"]))))
    return found


def _latest_observation(
    resources: Sequence[Mapping[str, Any]], loinc: str
) -> Mapping[str, Any] | None:
    matches = [
        r
        for r in resources
        if r.get("resourceType") == "Observation" and _first_code(r.get("code")) == loinc
    ]
    return max(matches, key=lambda r: str(r.get("effectiveDateTime", ""))) if matches else None


def _bmi(resources: Sequence[Mapping[str, Any]]) -> float | None:
    obs = _latest_observation(resources, LOINC_BMI)
    quantity = obs.get("valueQuantity") if obs else None
    value = quantity.get("value") if isinstance(quantity, Mapping) else None
    return float(value) if isinstance(value, int | float) else None


def _is_daily_smoker(resources: Sequence[Mapping[str, Any]]) -> bool:
    obs = _latest_observation(resources, LOINC_TOBACCO_STATUS)
    return bool(obs) and _first_code(obs.get("valueCodeableConcept")) == SNOMED_DAILY_SMOKER  # type: ignore[union-attr]


def _unique(items: Sequence[str]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(items))


def parse_bundle(bundle: Mapping[str, Any], *, as_of: date) -> SyntheaProfile:
    """Derive an onboarding profile from one Synthea patient bundle (input is never mutated)."""
    resources = _resources(bundle)
    patient = _find_patient(resources)
    age = _age(patient.get("birthDate"), as_of)
    conditions = _active_conditions(resources)
    bmi = _bmi(resources)
    smoker = _is_daily_smoker(resources)

    behaviours: list[str] = []
    if bmi is not None and bmi >= BMI_MOVEMENT_THRESHOLD:
        behaviours.append("movement")
    behaviours.extend(BEHAVIOUR_BY_SNOMED[c] for c, _ in conditions if c in BEHAVIOUR_BY_SNOMED)
    if smoker:
        behaviours.append("smoking_cessation")

    findings = [display for _, display in conditions]
    if bmi is not None:
        findings.append(f"BMI {bmi:.1f} kg/m2 (LOINC {LOINC_BMI})")
    if smoker:
        findings.append(f"Smokes tobacco daily (LOINC {LOINC_TOBACCO_STATUS})")

    return SyntheaProfile(
        patient_id=str(patient.get("id", "")),
        display_name=_display_name(patient),
        gender=str(patient.get("gender", "unknown")),
        age=age,
        age_band=_age_band(age),
        preferred_language=_language(patient),
        contraindications=_unique(
            [
                CONTRAINDICATION_BY_SNOMED[c]
                for c, _ in conditions
                if c in CONTRAINDICATION_BY_SNOMED
            ]
        ),
        suggested_behaviours=_unique(behaviours)[:MAX_SUGGESTED_BEHAVIOURS],
        is_daily_smoker=smoker,
        bmi=bmi,
        findings=tuple(findings),
    )
