"""Decision-trail entries (Constitution III: every decision is logged and replayable).

Entries carry the policy version, inputs, candidates, choice and propensities, plus the
sources excluded by consent, so any recommendation can be explained after the fact.
"""

from __future__ import annotations

import copy
from collections.abc import Mapping, Sequence
from typing import Any

DECISION_TYPES: frozenset[str] = frozenset(
    {
        "plan_built",
        "action_selected",
        "risk_scored",
        "adjustment_proposed",
        "choice_recorded",
        "consent_changed",
        "milestone_awarded",
        "safety_escalation",
    }
)


def append_entry(
    state: Mapping[str, Any],
    *,
    decision_type: str,
    on: str,
    policy_version: str,
    inputs_used: Mapping[str, Any],
    excluded_sources: Sequence[str],
    candidate_set: Sequence[Any],
    chosen: Any,
    propensities: Sequence[float],
    summary_key: str,
) -> dict[str, Any]:
    """Return a copy of ``state`` with one more trail entry. ``seq`` is strictly increasing."""
    if decision_type not in DECISION_TYPES:
        raise ValueError(f"unknown decision type: {decision_type}")
    trail = list(state["decision_trail"])
    seq = len(trail) + 1
    entry = {
        "id": f"d{seq:05d}",
        "seq": seq,
        "date": on,
        "decision_type": decision_type,
        "policy_version": policy_version,
        "inputs_used": copy.deepcopy(dict(inputs_used)),
        "excluded_sources": list(excluded_sources),
        "candidate_set": copy.deepcopy(list(candidate_set)),
        "chosen": copy.deepcopy(chosen),
        "propensities": list(propensities),
        "summary_key": summary_key,
    }
    return {**state, "decision_trail": [*trail, entry]}


def last_decision_id(state: Mapping[str, Any]) -> str | None:
    """Id of the most recent trail entry, or None when the trail is empty."""
    trail = state["decision_trail"]
    return trail[-1]["id"] if trail else None
