"""Consent per source x purpose (spec 023 US6, Constitution IV).

Each (source, purpose) pair can be withdrawn and granted again at any time. A change is logged,
and what the engine decides next uses only the pairs that are still granted.
"""

from __future__ import annotations

from typing import Any

from engine.sandbox.commands import Event, Handler
from engine.sandbox.proposals import propose_for_context
from engine.sandbox.radar import score_today
from engine.sandbox.state import State
from engine.sandbox.trail import append_entry

POLICY_VERSION = "consent-1"


def _set_consent(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    assert state is not None  # the command schema requires a state
    pair = f"{command['source']}:{command['purpose']}"
    granted = bool(command["granted"])
    if state["consent"][pair]["granted"] == granted:
        return state, []

    on = state["current_date"]
    updated = {
        **state,
        "consent": {**state["consent"], pair: {"granted": granted, "changed_on": on}},
    }
    recorded = append_entry(
        updated,
        decision_type="consent_changed",
        on=on,
        policy_version=POLICY_VERSION,
        inputs_used={"pair": pair, "granted": granted},
        excluded_sources=[],
        candidate_set=["granted", "withdrawn"],
        chosen="granted" if granted else "withdrawn",
        propensities=[1.0],
        summary_key="trail.consent_changed",
    )
    # Today's radar and any suggested change are reworked with the new choice.
    scored, events = score_today(recorded)
    proposed, proposal_events = propose_for_context(scored)
    return proposed, [*events, *proposal_events]


HANDLERS: dict[str, Handler] = {"set_consent": _set_consent}
