"""Immutable domain models, literals, and constants for F22 Workplace Programme at Scale."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Literal
from uuid import UUID

from engine.aggregates import MIN_TEAM_K_ANONYMITY

MIN_WORKPLACE_K_ANONYMITY: int = MIN_TEAM_K_ANONYMITY  # 20
WORKPLACE_TERMS_VERSION: str = "workplace-tos-v1"

EmployerTermsStatus = Literal["pending", "accepted", "suspended"]
InviteBatchStatus = Literal["active", "revoked", "expired"]
WorkplaceEnrollmentStatus = Literal["active", "left_silently"]
ChallengeGoalMetric = Literal["completed_actions", "active_days"]
WorkplaceSubgroupDimension = Literal["work_pattern", "language"]
WorkplaceLeaveScope = Literal["programme", "team_only"]
TermsGateReason = Literal[
    "workplace_terms_not_accepted",
    "workplace_terms_suspended",
    "workplace_terms_version_outdated",
]


@dataclass(frozen=True, slots=True)
class EmployerTermsAgreement:
    version: str
    prohibits_hr_decisions: bool
    prohibits_performance_evaluation: bool
    prohibits_insurance_linking: bool
    prohibits_individual_data_access: bool
    min_k_anonymity: int
    title_en: str
    title_ar: str
    summary_en: str
    summary_ar: str
    clauses_en: tuple[str, ...]
    clauses_ar: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class EmployerTermsGateDecision:
    allowed: bool
    reason: TermsGateReason | None = None


@dataclass(frozen=True, slots=True)
class WorkplaceOrganisation:
    org_slug: str
    name_en: str
    name_ar: str
    sector: str
    terms_status: EmployerTermsStatus
    terms_version: str | None
    accepted_by_role: str | None
    accepted_at: datetime | None
    synthetic_cohort_size: int = 0
    created_at: datetime | None = None
    updated_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class WorkplaceInviteBatch:
    invite_code: str
    org_slug: str
    cohort_label_en: str
    cohort_label_ar: str
    estimated_headcount: int
    status: InviteBatchStatus
    expires_at: datetime
    created_at: datetime


@dataclass(frozen=True, slots=True)
class WorkplaceEmployeeEnrollment:
    id: UUID
    user_id: UUID
    org_slug: str
    invite_code: str
    team_slug: str | None
    status: WorkplaceEnrollmentStatus
    joined_at: datetime
    updated_at: datetime
    left_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class WorkplaceCooperativeChallenge:
    challenge_slug: str
    org_slug: str
    team_slug: str
    title_en: str
    title_ar: str
    summary_en: str
    summary_ar: str
    goal_metric: ChallengeGoalMetric
    target_value: int
    start_date: date
    end_date: date
    synthetic_member_count: int = 0
    synthetic_completed_actions: int = 0
    synthetic_active_days: int = 0
    created_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class WorkplaceChallengeAggregateView:
    challenge_slug: str
    org_slug: str
    team_slug: str
    title_en: str
    title_ar: str
    summary_en: str
    summary_ar: str
    goal_metric: ChallengeGoalMetric
    target_value: int
    member_count: int
    min_k_threshold: int
    suppressed_k_anonymity: bool
    complementary_suppression: bool
    total_completed_actions: int | None
    total_active_days: int | None
    progress_ratio: float | None
    goal_reached: bool | None
    individual_rankings_exposed: bool
    privacy_notice_en: str
    privacy_notice_ar: str


@dataclass(frozen=True, slots=True)
class WorkplaceSustainedOutcomesPayload:
    suppressed_k_anonymity: bool
    persistence_week_12: float | None
    persistence_week_26: float | None
    lapse_recovery_rate_14d: float | None
    median_recovery_days: float | None
    weekly_mvpa_minutes: float | None
    retention_week_26: float | None
    notification_opt_out_rate: float | None
    mean_autonomy_support_score: float | None
    mean_active_days: float | None


@dataclass(frozen=True, slots=True)
class WorkplaceSubgroupOutcomeRow:
    dimension: WorkplaceSubgroupDimension
    subgroup: str
    n: int
    suppressed_k_anonymity: bool
    complementary_suppression: bool
    persistence_week_12: float | None
    persistence_week_26: float | None
    lapse_recovery_rate_14d: float | None
    median_recovery_days: float | None
    weekly_mvpa_minutes: float | None
    retention_week_26: float | None
    notification_opt_out_rate: float | None
    mean_autonomy_support_score: float | None
    mean_active_days: float | None
    persistence_gap_points: float | None
    recovery_gap_points: float | None
    autonomy_gap_points: float | None
    equity_gap_flagged: bool


@dataclass(frozen=True, slots=True)
class WorkplaceImpactReport:
    org_slug: str
    org_name_en: str
    org_name_ar: str
    sector: str
    synthetic: bool
    illustrative_label_en: str
    illustrative_label_ar: str
    active_participants: int
    enrolled_without_team_count: int | None
    min_k_threshold: int
    suppressed_k_anonymity: bool
    privacy_notice_en: str
    privacy_notice_ar: str
    non_punitive_terms: EmployerTermsAgreement
    outcomes: WorkplaceSustainedOutcomesPayload
    subgroups: tuple[WorkplaceSubgroupOutcomeRow, ...]
    challenges: tuple[WorkplaceChallengeAggregateView, ...]
    reproducibility_digest: str
