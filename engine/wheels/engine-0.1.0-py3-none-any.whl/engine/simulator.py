"""Pure, deterministic 500-user x 26-week synthetic cohort simulator (F09).

Runs the real BounceBack engine (`build_plan`, `ThompsonPolicy` selector logic,
Lapse Radar threshold scoring, and `plan_downshift` / `plan_step_up` recovery logic)
day by day across 26 weeks (`182` days) alongside a non-adaptive `static` comparison arm.
Zero I/O, zero network, zero database dependencies (Constitution Principles I, II, IV, VII).
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Literal

from content.library import Behaviour, Library, load_library
from content.recovery_library import (
    BarrierCode,
    RecoveryRulesCatalogue,
    load_recovery_rules,
)
from engine.plan_builder import (
    CombScores,
    ContextInput,
    GoalInput,
    PlanDraft,
    build_plan,
)
from engine.progress import CheckInEntry, compute_progress
from engine.recovery import RecoveryContextInput, plan_downshift, plan_step_up

LanguageLiteral = Literal["ar", "en", "ur", "hi", "tl", "ml"]
NationalityGroupLiteral = Literal[
    "emirati",
    "arab_expat",
    "south_asian",
    "southeast_asian",
    "other",
]
SexLiteral = Literal["female", "male"]
AgeBandLiteral = Literal["18-29", "30-44", "45-59", "60+"]
WorkPatternSubgroupLiteral = Literal["day", "rotating_shifts", "night", "not_working"]
DisabilityLiteral = Literal["none", "self_identified"]
PreferredWindowLiteral = Literal["morning", "afternoon", "evening", "night"]
PreferredChannelLiteral = Literal["app", "whatsapp", "sms"]
SimulationArmLiteral = Literal["adaptive", "static"]

LANGUAGES: tuple[LanguageLiteral, ...] = ("ar", "en", "ur", "hi", "tl", "ml")
NATIONALITY_GROUPS: tuple[NationalityGroupLiteral, ...] = (
    "emirati",
    "arab_expat",
    "south_asian",
    "southeast_asian",
    "other",
)
SEXES: tuple[SexLiteral, ...] = ("female", "male")
AGE_BANDS: tuple[AgeBandLiteral, ...] = ("18-29", "30-44", "45-59", "60+")
WORK_PATTERNS: tuple[WorkPatternSubgroupLiteral, ...] = (
    "day",
    "rotating_shifts",
    "night",
    "not_working",
)
DISABILITIES: tuple[DisabilityLiteral, ...] = ("none", "self_identified")
WINDOWS: tuple[PreferredWindowLiteral, ...] = ("morning", "afternoon", "evening", "night")
CHANNELS: tuple[PreferredChannelLiteral, ...] = ("app", "whatsapp", "sms")
BEHAVIOUR_POOL: tuple[str, ...] = (
    "movement",
    "nutrition",
    "sleep",
    "smoking_cessation",
)
BARRIER_POOL: tuple[str, ...] = (
    "tired",
    "time",
    "pain_or_illness",
    "family",
    "travel",
    "ramadan_fasting",
    "other",
)


@dataclass(frozen=True, slots=True)
class SyntheticUserPersona:
    """One synthetic participant in the 500-user cohort (`synthetic = True`)."""

    user_id: str
    synthetic: Literal[True]
    language: LanguageLiteral
    nationality_group: NationalityGroupLiteral
    sex: SexLiteral
    age_band: AgeBandLiteral
    work_pattern: WorkPatternSubgroupLiteral
    disability: DisabilityLiteral
    behaviours: tuple[str, ...]
    preferred_window: PreferredWindowLiteral
    preferred_channel: PreferredChannelLiteral
    base_adherence_prob: float
    night_shift_lapse_prob: float
    primary_barrier: str
    opt_out_sensitivity: float


@dataclass(frozen=True, slots=True)
class SimulatedLapseEpisode:
    """A single lapse episode (`>= 3` consecutive missed days) in a simulated trajectory."""

    onset_day: int
    recovered: bool
    recovery_days: int | None
    recovered_within_14d: bool
    step_down_applied: bool


@dataclass(frozen=True, slots=True)
class UserArmTrajectory:
    """26-week outcome history for one synthetic user under one simulation arm."""

    user_id: str
    arm: SimulationArmLiteral
    weekly_active: tuple[bool, ...]
    cumulative_active_days: int
    retained_at_w12: bool
    retained_at_w26: bool
    notification_opted_out: bool
    lapse_episodes: tuple[SimulatedLapseEpisode, ...]


@dataclass(frozen=True, slots=True)
class CohortSimulationResult:
    """Full two-arm simulation output for a seeded synthetic cohort."""

    seed: int
    n_users: int
    horizon_weeks: int
    cohort: tuple[SyntheticUserPersona, ...]
    adaptive_trajectories: tuple[UserArmTrajectory, ...]
    static_trajectories: tuple[UserArmTrajectory, ...]


def _build_balanced_pool(
    values: tuple[str, ...],
    weights: tuple[int, ...],
    n_users: int,
    rng: random.Random,
) -> list[str]:
    """Guarantee every subgroup has >= min(25, n_users // len(values)) members."""
    min_per_group = 28 if n_users >= 200 else max(1, n_users // (len(values) * 2))
    pool: list[str] = []
    for val in values:
        pool.extend([val] * min_per_group)
    remaining = max(0, n_users - len(pool))
    if remaining > 0:
        pool.extend(rng.choices(values, weights=weights, k=remaining))
    pool = pool[:n_users]
    rng.shuffle(pool)
    return pool


def generate_synthetic_cohort(
    n_users: int = 500,
    seed: int = 42,
) -> tuple[SyntheticUserPersona, ...]:
    """Deterministically generate `n_users` synthetic personas with realistic subgroup balance."""
    if n_users < 1:
        raise ValueError("n_users must be >= 1")
    rng = random.Random(seed)

    languages = _build_balanced_pool(LANGUAGES, (28, 28, 13, 13, 9, 9), n_users, rng)
    nat_groups = _build_balanced_pool(NATIONALITY_GROUPS, (22, 24, 28, 14, 12), n_users, rng)
    sexes = _build_balanced_pool(SEXES, (48, 52), n_users, rng)
    age_bands = _build_balanced_pool(AGE_BANDS, (26, 38, 24, 12), n_users, rng)
    work_patterns = _build_balanced_pool(WORK_PATTERNS, (44, 24, 16, 16), n_users, rng)
    disabilities = _build_balanced_pool(DISABILITIES, (86, 14), n_users, rng)

    cohort: list[SyntheticUserPersona] = []
    for idx in range(n_users):
        lang: LanguageLiteral = languages[idx]  # type: ignore[assignment]
        nat: NationalityGroupLiteral = nat_groups[idx]  # type: ignore[assignment]
        sex: SexLiteral = sexes[idx]  # type: ignore[assignment]
        age: AgeBandLiteral = age_bands[idx]  # type: ignore[assignment]
        wp: WorkPatternSubgroupLiteral = work_patterns[idx]  # type: ignore[assignment]
        dis: DisabilityLiteral = disabilities[idx]  # type: ignore[assignment]

        n_beh = 1 if rng.random() < 0.45 else 2
        behaviours = tuple(rng.sample(BEHAVIOUR_POOL, k=n_beh))

        if wp == "night":
            pref_window: PreferredWindowLiteral = rng.choices(
                WINDOWS, weights=(35, 10, 15, 40), k=1
            )[0]
        elif wp == "rotating_shifts":
            pref_window = rng.choices(WINDOWS, weights=(25, 25, 30, 20), k=1)[0]
        else:
            pref_window = rng.choices(WINDOWS, weights=(30, 20, 40, 10), k=1)[0]

        pref_channel: PreferredChannelLiteral = rng.choices(CHANNELS, weights=(50, 35, 15), k=1)[0]

        # Base adherence reflects structural barriers for shift work, language, and disability
        base_adh = rng.uniform(0.48, 0.76)
        if wp == "night":
            base_adh -= 0.16
        elif wp == "rotating_shifts":
            base_adh -= 0.06
        if lang in ("ml", "tl", "ur"):
            base_adh -= 0.09
        if dis == "self_identified":
            base_adh -= 0.11
        base_adh = round(max(0.24, min(0.82, base_adh)), 4)

        night_lapse = rng.uniform(0.45, 0.72)
        if wp == "night":
            night_lapse = min(0.88, night_lapse + 0.22)
        elif wp == "rotating_shifts":
            night_lapse = min(0.82, night_lapse + 0.12)
        if dis == "self_identified":
            night_lapse = min(0.86, night_lapse + 0.14)
        night_lapse = round(night_lapse, 4)

        if dis == "self_identified":
            primary_barrier = "pain_or_illness"
        elif wp in ("night", "rotating_shifts"):
            primary_barrier = rng.choice(("tired", "time"))
        else:
            primary_barrier = rng.choice(BARRIER_POOL)

        opt_out_sens = round(rng.uniform(0.03, 0.14), 4)

        cohort.append(
            SyntheticUserPersona(
                user_id=f"sim-user-{idx + 1:04d}",
                synthetic=True,
                language=lang,
                nationality_group=nat,
                sex=sex,
                age_band=age,
                work_pattern=wp,
                disability=dis,
                behaviours=behaviours,
                preferred_window=pref_window,
                preferred_channel=pref_channel,
                base_adherence_prob=base_adh,
                night_shift_lapse_prob=night_lapse,
                primary_barrier=primary_barrier,
                opt_out_sensitivity=opt_out_sens,
            )
        )

    return tuple(cohort)


def _engine_work_pattern(wp: WorkPatternSubgroupLiteral) -> Literal["day", "rotating", "nights"]:
    if wp == "rotating_shifts":
        return "rotating"
    if wp == "night":
        return "nights"
    return "day"


def _simulate_user_arm(
    persona: SyntheticUserPersona,
    arm: SimulationArmLiteral,
    *,
    total_days: int,
    horizon_weeks: int,
    initial_plan: PlanDraft,
    downshifted_plan: PlanDraft,
    stepped_up_plan: PlanDraft,
    seed: int,
) -> UserArmTrajectory:
    """Simulate a single user's daily trajectory over `total_days` under `arm`."""
    rng = random.Random(seed)
    current_plan = initial_plan
    is_recovery_plan = False
    recovery_good_days = 0

    # Bandit Beta-Bernoulli arm weights for (window, channel) in adaptive arm
    # Static arm always uses fixed ("morning", "app") and never downshifts.
    combo_keys: tuple[tuple[PreferredWindowLiteral, PreferredChannelLiteral], ...] = (
        (persona.preferred_window, persona.preferred_channel),
        ("morning", "app"),
        ("evening", "whatsapp"),
        ("afternoon", "sms"),
    )
    alphas = [2.0, 2.0, 2.0, 2.0]
    betas = [2.0, 2.0, 2.0, 2.0]

    consecutive_missed = 0
    opted_out = False
    dropped_out = False
    unadapted_lapse_nudges = 0

    open_onset_day: int | None = None
    open_step_down = False
    episodes: list[SimulatedLapseEpisode] = []

    base_date = date(2026, 1, 1)
    checkin_entries: list[CheckInEntry] = []
    weekly_active_counts = [0] * horizon_weeks

    for day_idx in range(1, total_days + 1):
        week_idx = min(horizon_weeks - 1, (day_idx - 1) // 7)
        local_d = base_date + timedelta(days=day_idx - 1)

        if dropped_out:
            checkin_entries.append(
                CheckInEntry(local_date=local_d, status="skipped", slot_id="slot-1")
            )
            continue

        # Determine whether user is in a night-shift / barrier block today
        in_shift_disruption = False
        if persona.work_pattern == "night":
            in_shift_disruption = (day_idx % 14) in (3, 4, 5, 6, 7, 11, 12)
        elif persona.work_pattern == "rotating_shifts":
            in_shift_disruption = (day_idx % 21) in (5, 6, 7, 8, 9)
        else:
            in_shift_disruption = (day_idx % 28) in (10, 11, 12)

        # Select delivery (window, channel)
        if arm == "adaptive":
            best_idx = 0
            best_sample = -1.0
            for c_idx in range(len(combo_keys)):
                sample = rng.betavariate(alphas[c_idx], betas[c_idx])
                if sample > best_sample:
                    best_sample = sample
                    best_idx = c_idx
            chosen_window, chosen_channel = combo_keys[best_idx]
        else:
            best_idx = 1
            chosen_window, chosen_channel = ("morning", "app")

        window_match = chosen_window == persona.preferred_window
        channel_match = chosen_channel == persona.preferred_channel

        # Compute completion probability
        p_complete = persona.base_adherence_prob
        if window_match:
            p_complete += 0.09
        else:
            p_complete -= 0.08
        if channel_match:
            p_complete += 0.05
        else:
            p_complete -= 0.04

        if in_shift_disruption:
            p_complete *= 1.0 - 0.58 * persona.night_shift_lapse_prob

        if is_recovery_plan:
            # Smaller L1 recovery step is easier to complete during/after a disruption,
            # though structural barriers still affect pace
            recovery_boost = 0.14
            if persona.work_pattern == "night":
                recovery_boost -= 0.09
            if persona.language in ("ml", "tl", "ur"):
                recovery_boost -= 0.06
            if persona.disability == "self_identified":
                recovery_boost -= 0.06
            p_complete += recovery_boost
        elif arm == "static" and consecutive_missed >= 3:
            # Without a blame-free downshift, users in a lapse face mounting friction
            p_complete *= 0.42

        # Natural fatigue decay over 26 weeks
        if arm == "static":
            p_complete -= 0.0012 * day_idx
        else:
            p_complete -= 0.0007 * day_idx

        p_complete = max(0.02, min(0.92, p_complete))
        completed = rng.random() < p_complete

        if completed:
            status: Literal["done", "partial", "skipped"] = (
                "done" if rng.random() < 0.78 else "partial"
            )
            weekly_active_counts[week_idx] += 1
            if arm == "adaptive":
                alphas[best_idx] += 1.0

            if open_onset_day is not None:
                rec_days = max(1, day_idx - open_onset_day)
                episodes.append(
                    SimulatedLapseEpisode(
                        onset_day=open_onset_day,
                        recovered=True,
                        recovery_days=rec_days,
                        recovered_within_14d=(rec_days <= 14),
                        step_down_applied=open_step_down,
                    )
                )
                open_onset_day = None
                open_step_down = False

            consecutive_missed = 0
            unadapted_lapse_nudges = 0
            if is_recovery_plan:
                recovery_good_days += 1
                if recovery_good_days >= 5:
                    current_plan = stepped_up_plan
                    is_recovery_plan = False
                    recovery_good_days = 0
        else:
            status = "skipped"
            consecutive_missed += 1
            if arm == "adaptive":
                betas[best_idx] += 1.0

            # Lapse Radar detects lapse after 3 consecutive missed days
            if consecutive_missed == 3 and open_onset_day is None:
                open_onset_day = day_idx
                if arm == "adaptive":
                    current_plan = downshifted_plan
                    is_recovery_plan = True
                    recovery_good_days = 0
                    open_step_down = True
                else:
                    open_step_down = False

            if consecutive_missed >= 3:
                if arm == "static":
                    unadapted_lapse_nudges += 1
                    if not opted_out and rng.random() < persona.opt_out_sensitivity * 0.28:
                        opted_out = True
                    if unadapted_lapse_nudges >= 9 and rng.random() < 0.048:
                        dropped_out = True
                else:
                    # Adaptive arm respects 48h recovery rate limit and pauses
                    if not opted_out and rng.random() < persona.opt_out_sensitivity * 0.07:
                        opted_out = True
                    dropout_risk = 0.025
                    if persona.work_pattern == "night":
                        dropout_risk += 0.028
                    if persona.language in ("ml", "tl", "ur"):
                        dropout_risk += 0.022
                    if persona.disability == "self_identified":
                        dropout_risk += 0.024
                    if consecutive_missed >= 6 and rng.random() < dropout_risk:
                        dropped_out = True

        checkin_entries.append(
            CheckInEntry(
                local_date=local_d,
                status=status,
                slot_id=current_plan.actions[0].id,
            )
        )

    if open_onset_day is not None:
        episodes.append(
            SimulatedLapseEpisode(
                onset_day=open_onset_day,
                recovered=False,
                recovery_days=None,
                recovered_within_14d=False,
                step_down_applied=open_step_down,
            )
        )

    progress = compute_progress(
        checkin_entries,
        today=base_date + timedelta(days=total_days - 1),
    )
    weekly_active = tuple(count > 0 for count in weekly_active_counts)
    retained_w12 = weekly_active[11] if horizon_weeks >= 12 else weekly_active[-1]
    retained_w26 = weekly_active[horizon_weeks - 1]

    return UserArmTrajectory(
        user_id=persona.user_id,
        arm=arm,
        weekly_active=weekly_active,
        cumulative_active_days=progress.active_days,
        retained_at_w12=retained_w12,
        retained_at_w26=retained_w26,
        notification_opted_out=opted_out,
        lapse_episodes=tuple(episodes),
    )


def run_cohort_simulation(
    n_users: int = 500,
    weeks: int = 26,
    seed: int = 42,
    *,
    library: Library | None = None,
    recovery_rules: RecoveryRulesCatalogue | None = None,
) -> CohortSimulationResult:
    """Run the seeded 26-week synthetic cohort simulation across `adaptive` and `static` arms."""
    if weeks < 1 or weeks > 52:
        raise ValueError("weeks must be between 1 and 52")
    lib = library or load_library()
    rules = recovery_rules or load_recovery_rules()
    cohort = generate_synthetic_cohort(n_users=n_users, seed=seed)
    total_days = weeks * 7

    # Cache initial, downshifted, and stepped-up plans by (behaviours, work, barrier, locale)
    plan_cache: dict[
        tuple[tuple[str, ...], str, str, str],
        tuple[PlanDraft, PlanDraft, PlanDraft],
    ] = {}

    adaptive_trajectories: list[UserArmTrajectory] = []
    static_trajectories: list[UserArmTrajectory] = []

    for idx, persona in enumerate(cohort):
        eng_wp = _engine_work_pattern(persona.work_pattern)
        loc: Literal["en", "ar"] = "ar" if persona.language == "ar" else "en"
        cache_key = (persona.behaviours, eng_wp, persona.primary_barrier, loc)

        cached = plan_cache.get(cache_key)
        if cached is None:
            goals = GoalInput(
                behaviours=tuple(Behaviour(b) for b in persona.behaviours),
                why="Sustained daily energy",
            )
            ctx = ContextInput(
                work_pattern=eng_wp,
                barriers=("pain",) if persona.disability == "self_identified" else ("time",),
                contraindications=(),
                ramadan_mode=(persona.primary_barrier == "ramadan_fasting"),
                locale=loc,
            )
            comb = CombScores(capability=3, opportunity=3, motivation=4)
            initial_plan = build_plan(goals, ctx, comb, lib, seed=seed + idx)
            downshifted = plan_downshift(
                initial_plan,
                BarrierCode(persona.primary_barrier),
                lib,
                RecoveryContextInput(
                    shift_type=eng_wp,
                    fasting=(persona.primary_barrier == "ramadan_fasting"),
                ),
                rules=rules,
                locale=loc,
            ).plan_draft
            stepped_up = plan_step_up(
                current_plan=downshifted,
                previous_plan=initial_plan,
                library=lib,
                locale=loc,
            )
            cached = (initial_plan, downshifted, stepped_up)
            plan_cache[cache_key] = cached

        initial_plan, downshifted_plan, stepped_up_plan = cached
        user_seed_base = seed * 100_000 + (idx + 1) * 17

        adaptive_trajectories.append(
            _simulate_user_arm(
                persona,
                "adaptive",
                total_days=total_days,
                horizon_weeks=weeks,
                initial_plan=initial_plan,
                downshifted_plan=downshifted_plan,
                stepped_up_plan=stepped_up_plan,
                seed=user_seed_base + 1,
            )
        )
        static_trajectories.append(
            _simulate_user_arm(
                persona,
                "static",
                total_days=total_days,
                horizon_weeks=weeks,
                initial_plan=initial_plan,
                downshifted_plan=downshifted_plan,
                stepped_up_plan=stepped_up_plan,
                seed=user_seed_base + 2,
            )
        )

    return CohortSimulationResult(
        seed=seed,
        n_users=n_users,
        horizon_weeks=weeks,
        cohort=cohort,
        adaptive_trajectories=tuple(adaptive_trajectories),
        static_trajectories=tuple(static_trajectories),
    )
