"""Non-punitive Employer Terms of Service policy and gate evaluation for F22 (T008)."""

from __future__ import annotations

from typing import Literal

from engine.workplace.models import (
    MIN_WORKPLACE_K_ANONYMITY,
    WORKPLACE_TERMS_VERSION,
    EmployerTermsAgreement,
    EmployerTermsGateDecision,
    TermsGateReason,
    WorkplaceOrganisation,
)

DEFAULT_EMPLOYER_TERMS_POLICY = EmployerTermsAgreement(
    version=WORKPLACE_TERMS_VERSION,
    prohibits_hr_decisions=True,
    prohibits_performance_evaluation=True,
    prohibits_insurance_linking=True,
    prohibits_individual_data_access=True,
    min_k_anonymity=MIN_WORKPLACE_K_ANONYMITY,
    title_en="BounceBack Workplace Programme Non-Punitive Terms of Service",
    title_ar="شروط خدمة برنامج مكان العمل غير العقابية من باونس باك",
    summary_en=(
        "Workplace programme participation is strictly voluntary and non-punitive. "
        "Employers receive only aggregate metrics for cohorts of at least 20 active participants "
        "and are contractually prohibited from using programme data for HR, performance "
        "evaluation, promotion, disciplinary, or health insurance decisions."
    ),
    summary_ar=(
        "المشاركة في برنامج مكان العمل طوعية تماماً وغير عقابية. يتلقى أصحاب العمل فقط مؤشرات "
        "مجمّعة للمجموعات التي تضم 20 مشاركاً نشطاً على الأقل، ويُحظر تعاقدياً استخدام بيانات "
        "البرنامج في قرارات الموارد البشرية أو تقييم الأداء أو الترقيات أو التأمين الصحي."
    ),
    clauses_en=(
        (
            "No HR, Performance, or Disciplinary Use: Employer shall never use programme "
            "enrollment, participation, recognition points, or aggregate reports for hiring, "
            "firing, promotion, demotion, performance appraisal, bonus allocation, or discipline."
        ),
        (
            "No Health Insurance or Premium Linkage: Programme participation and aggregate "
            "outcomes shall never be linked to health insurance underwriting, premium pricing, "
            "deductibles, or benefit eligibility."
        ),
        (
            "Strict k >= 20 Anonymity & Complementary Suppression: All participation, "
            "cooperative challenge, and sustained-outcome metrics are suppressed unless at least "
            "20 active participants are present in the cell and cannot be inferred by subtraction."
        ),
        (
            "Autonomous Enrollment Without a Team: Employees may join the workplace programme "
            "without joining any team and receive full adaptive companion support."
        ),
        (
            "Silent, Unconditional Withdrawal: Employees may leave a cooperative team or leave "
            "the workplace programme at any time without any notification, alert, or roster "
            "signal sent to the employer."
        ),
    ),
    clauses_ar=(
        (
            "حظر الاستخدام في الموارد البشرية أو تقييم الأداء أو الإجراءات التأديبية: يلتزم صاحب "
            "العمل بعدم استخدام التسجيل في البرنامج أو المشاركة أو نقاط التقدير أو التقارير "
            "المجمّعة في التوظيف أو الفصل أو الترقية أو تقييم الأداء أو المكافآت أو المساءلة."
        ),
        (
            "حظر الربط بالتأمين الصحي أو الأقساط: لا يجوز بأي حال ربط المشاركة في البرنامج أو "
            "النتائج المجمّعة بتسعير أقساط التأمين الصحي أو التغطية التأمينية أو الأهلية للمزايا."
        ),
        (
            "إخفاء الهوية الصارم (k >= 20) والإخفاء التكميلي: يتم إخفاء جميع مؤشرات المشاركة "
            "والتحديات التعاونية والنتائج المستدامة ما لم يتوفر 20 مشاركاً نشطاً على الأقل في "
            "الخلية مع منع الاستنتاج بالطرح."
        ),
        (
            "التسجيل المستقل بدون فريق: يحق للموظفين الانضمام إلى برنامج مكان العمل دون الانضمام "
            "إلى أي فريق مع الحصول على الدعم التكيفي الكامل."
        ),
        (
            "الانسحاب الصامت وغير المشروط: يحق للموظفين مغادرة الفريق التعاوني أو مغادرة برنامج "
            "مكان العمل في أي وقت دون إرسال أي إشعار أو تنبيه إلى صاحب العمل."
        ),
    ),
)


def get_employer_terms_policy() -> EmployerTermsAgreement:
    """Return the canonical binding non-punitive Workplace Programme Terms of Service."""
    return DEFAULT_EMPLOYER_TERMS_POLICY


def evaluate_employer_terms_gate(organisation: WorkplaceOrganisation) -> EmployerTermsGateDecision:
    """Evaluate whether an employer organisation may run workplace actions or view reports."""
    if organisation.terms_status == "suspended":
        return EmployerTermsGateDecision(
            allowed=False,
            reason="workplace_terms_suspended",
        )
    if organisation.terms_status != "accepted":
        return EmployerTermsGateDecision(
            allowed=False,
            reason="workplace_terms_not_accepted",
        )
    if organisation.terms_version != WORKPLACE_TERMS_VERSION:
        return EmployerTermsGateDecision(
            allowed=False,
            reason="workplace_terms_version_outdated",
        )
    return EmployerTermsGateDecision(allowed=True, reason=None)


def validate_terms_acceptance(
    *,
    status: Literal["accepted", "suspended"],
    terms_version: str,
    confirm_non_punitive_terms: bool,
) -> tuple[bool, TermsGateReason | None]:
    """Validate an employer terms update request."""
    if terms_version != WORKPLACE_TERMS_VERSION:
        return False, "workplace_terms_version_outdated"
    if status == "accepted" and not confirm_non_punitive_terms:
        return False, "workplace_terms_not_accepted"
    return True, None
