"""Load and validate the versioned support & incentive mechanics catalog (F14)."""

from __future__ import annotations

import json
from collections import Counter
from collections.abc import Mapping
from dataclasses import dataclass
from functools import cache
from importlib.resources import files
from pathlib import Path
from typing import Any, Literal, cast

from content.copy_lint import lint_text
from content.library import WhyCard, parse_yaml, to_why_card
from content.validation import (
    ContentValidationError,
    ValidationIssue,
    describe,
    validate_document,
)

PACKAGE = files("content")
MECHANICS_SOURCE = "mechanics.yaml"

SupportMechanicId = Literal["peer_pod", "family_buddy", "workplace_team", "recognition_points"]
MECHANIC_IDS: tuple[SupportMechanicId, ...] = (
    "peer_pod",
    "family_buddy",
    "workplace_team",
    "recognition_points",
)


@dataclass(frozen=True)
class SupportMechanic:
    id: SupportMechanicId
    bct_codes: tuple[str, ...]
    opt_in_by_default: bool
    silent_exit_supported: bool
    non_linkage_guaranteed: bool
    title_en: str
    title_ar: str
    summary_en: str
    summary_ar: str
    why_card: WhyCard

    def title_for_locale(self, locale: str) -> str:
        return self.title_ar if locale == "ar" else self.title_en

    def summary_for_locale(self, locale: str) -> str:
        return self.summary_ar if locale == "ar" else self.summary_en


@dataclass(frozen=True)
class MechanicsCatalog:
    version: str
    non_linkage_en: str
    non_linkage_ar: str
    mechanics: tuple[SupportMechanic, ...]

    def get(self, mechanic_id: str) -> SupportMechanic | None:
        for mechanic in self.mechanics:
            if mechanic.id == mechanic_id:
                return mechanic
        return None

    def non_linkage_for_locale(self, locale: str) -> str:
        return self.non_linkage_ar if locale == "ar" else self.non_linkage_en


@cache
def mechanics_schema() -> Mapping[str, Any]:
    schema: dict[str, Any] = json.loads(
        PACKAGE.joinpath("schemas/mechanics.schema.json").read_text(encoding="utf-8")
    )
    return schema


def _duplicate_mechanic_id_issues(data: object) -> list[ValidationIssue]:
    mechanics = data.get("mechanics") if isinstance(data, Mapping) else None
    if not isinstance(mechanics, list):
        return []
    ids = [
        m.get("id") for m in mechanics if isinstance(m, Mapping) and isinstance(m.get("id"), str)
    ]
    return [
        ValidationIssue(
            action_id=mech_id,
            path="mechanics",
            rule="duplicate_id",
            message=describe(mech_id, "mechanics", f"id used by {count} mechanics"),
        )
        for mech_id, count in Counter(ids).items()
        if count > 1
    ]


def _mechanics_copy_lint_issues(data: object) -> list[ValidationIssue]:
    if not isinstance(data, Mapping):
        return []
    issues: list[ValidationIssue] = []

    non_linkage = data.get("non_linkage_statement")
    if isinstance(non_linkage, Mapping):
        for loc in ("en", "ar"):
            val = non_linkage.get(loc)
            if isinstance(val, str):
                path = f"non_linkage_statement/{loc}"
                for v in lint_text(val, source=MECHANICS_SOURCE, field_path=path):
                    issues.append(
                        ValidationIssue(
                            action_id=None,
                            path=path,
                            rule="copy_lint",
                            message=describe(
                                None,
                                path,
                                f"blame-free copy violation ({v.matched_term})",
                            ),
                        )
                    )

    mechanics = data.get("mechanics")
    if not isinstance(mechanics, list):
        return issues

    for idx, mech in enumerate(mechanics):
        if not isinstance(mech, Mapping):
            continue
        mech_id = mech.get("id") if isinstance(mech.get("id"), str) else None
        for section_name in ("title", "summary"):
            sec = mech.get(section_name)
            if isinstance(sec, Mapping):
                for loc in ("en", "ar"):
                    val = sec.get(loc)
                    if isinstance(val, str):
                        path = f"mechanics/{idx}/{section_name}/{loc}"
                        for v in lint_text(val, source=MECHANICS_SOURCE, field_path=path):
                            issues.append(
                                ValidationIssue(
                                    action_id=mech_id,
                                    path=path,
                                    rule="copy_lint",
                                    message=describe(
                                        mech_id,
                                        path,
                                        f"blame-free copy violation ({v.matched_term})",
                                    ),
                                )
                            )
        why_card = mech.get("why_card")
        if isinstance(why_card, Mapping):
            for loc in ("en", "ar"):
                card_loc = why_card.get(loc)
                if not isinstance(card_loc, Mapping):
                    continue
                for field_name in ("technique_label", "idea", "evidence_summary"):
                    val = card_loc.get(field_name)
                    if isinstance(val, str):
                        path = f"mechanics/{idx}/why_card/{loc}/{field_name}"
                        for v in lint_text(val, source=MECHANICS_SOURCE, field_path=path):
                            issues.append(
                                ValidationIssue(
                                    action_id=mech_id,
                                    path=path,
                                    rule="copy_lint",
                                    message=describe(
                                        mech_id,
                                        path,
                                        f"blame-free copy violation ({v.matched_term})",
                                    ),
                                )
                            )
                limits = card_loc.get("limits")
                if isinstance(limits, list):
                    for lim_idx, lim_val in enumerate(limits):
                        if isinstance(lim_val, str):
                            path = f"mechanics/{idx}/why_card/{loc}/limits/{lim_idx}"
                            for v in lint_text(lim_val, source=MECHANICS_SOURCE, field_path=path):
                                issues.append(
                                    ValidationIssue(
                                        action_id=mech_id,
                                        path=path,
                                        rule="copy_lint",
                                        message=describe(
                                            mech_id,
                                            path,
                                            f"blame-free copy violation ({v.matched_term})",
                                        ),
                                    )
                                )
    return issues


def validate_mechanics(data: object) -> list[ValidationIssue]:
    return (
        validate_document(mechanics_schema(), data)
        + _duplicate_mechanic_id_issues(data)
        + _mechanics_copy_lint_issues(data)
    )


def _to_mechanic(raw: Mapping[str, Any]) -> SupportMechanic:
    return SupportMechanic(
        id=cast(SupportMechanicId, raw["id"]),
        bct_codes=tuple(raw["bct_codes"]),
        opt_in_by_default=bool(raw["opt_in_by_default"]),
        silent_exit_supported=bool(raw["silent_exit_supported"]),
        non_linkage_guaranteed=bool(raw["non_linkage_guaranteed"]),
        title_en=str(raw["title"]["en"]),
        title_ar=str(raw["title"]["ar"]),
        summary_en=str(raw["summary"]["en"]),
        summary_ar=str(raw["summary"]["ar"]),
        why_card=to_why_card(raw["why_card"]),
    )


@cache
def _load_default_mechanics_catalog() -> MechanicsCatalog:
    text = PACKAGE.joinpath(MECHANICS_SOURCE).read_text(encoding="utf-8")
    data, issues = parse_yaml(text, MECHANICS_SOURCE)
    issues = issues or validate_mechanics(data)
    if issues:
        raise ContentValidationError(issues)
    assert isinstance(data, Mapping)
    non_linkage = data["non_linkage_statement"]
    return MechanicsCatalog(
        version=str(data["version"]),
        non_linkage_en=str(non_linkage["en"]),
        non_linkage_ar=str(non_linkage["ar"]),
        mechanics=tuple(_to_mechanic(m) for m in data["mechanics"]),
    )


def load_mechanics_catalog(path: Path | None = None) -> MechanicsCatalog:
    if path is None:
        return _load_default_mechanics_catalog()
    text = path.read_text(encoding="utf-8")
    data, issues = parse_yaml(text, path.name)
    issues = issues or validate_mechanics(data)
    if issues:
        raise ContentValidationError(issues)
    assert isinstance(data, Mapping)
    non_linkage = data["non_linkage_statement"]
    return MechanicsCatalog(
        version=str(data["version"]),
        non_linkage_en=str(non_linkage["en"]),
        non_linkage_ar=str(non_linkage["ar"]),
        mechanics=tuple(_to_mechanic(m) for m in data["mechanics"]),
    )
