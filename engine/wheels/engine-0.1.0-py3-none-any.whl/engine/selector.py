"""Pure, deterministic adaptive micro-action selector (F04 / 006-adaptive-selector).

Implements:
- Stage 1: Deterministic hard-rule candidate filtering (`filter_candidates`).
- Stage 2: Contextual Beta-Bernoulli Thompson-sampling bandit with hierarchical
  `(time_window, channel)` pooling, minimum uniform exploration (`epsilon = 0.10`),
  and 1,000-draw Monte Carlo propensity estimation (`ThompsonPolicy.choose`).
- Deterministic seed replay (`replay_selector_decision`) and 6-hour reward
  window attribution (`evaluate_reward_window`).

Zero I/O, zero network, zero database dependencies (Constitution Principle I & VII).
"""

from __future__ import annotations

import random
from datetime import datetime
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from engine.policy.protocol import CandidatePolicyContext, LevelLiteral
from engine.policy.registry import POLICY_VERSION, evaluate_candidate_policy

SELECTOR_POLICY_VERSION: Literal["adaptive-selector-v1"] = "adaptive-selector-v1"
DEFAULT_EPSILON: float = 0.10
DEFAULT_PROPENSITY_DRAWS: int = 1000
REWARD_WINDOW_HOURS: int = 6
DEFAULT_DAILY_NOTIFICATION_BUDGET: int = 2
POOL_CONTEXT_KEY: Literal["*"] = "*"


class TimeWindow(StrEnum):
    MORNING = "morning"
    AFTERNOON = "afternoon"
    EVENING = "evening"
    NIGHT = "night"


class Channel(StrEnum):
    APP = "app"
    WHATSAPP = "whatsapp"
    SMS = "sms"


class VariantKind(StrEnum):
    PRIMARY = "primary"
    SMALLER = "smaller"


class ExclusionRuleId(StrEnum):
    RULE_NO_ACTIVE_PLAN = "RULE_NO_ACTIVE_PLAN"
    RULE_USER_PAUSED = "RULE_USER_PAUSED"
    RULE_SLOT_ALREADY_COMPLETED_TODAY = "RULE_SLOT_ALREADY_COMPLETED_TODAY"
    RULE_QUIET_HOURS = "RULE_QUIET_HOURS"
    RULE_DAILY_BUDGET_REACHED = "RULE_DAILY_BUDGET_REACHED"
    RULE_CHANNEL_NOT_CONSENTED = "RULE_CHANNEL_NOT_CONSENTED"
    RULE_RAMADAN_FASTING_CONTRAINDICATION = "RULE_RAMADAN_FASTING_CONTRAINDICATION"
    RULE_BARRIER_CONTRAINDICATION = "RULE_BARRIER_CONTRAINDICATION"
    RULE_OUTSIDE_CURRENT_WINDOW = "RULE_OUTSIDE_CURRENT_WINDOW"
    RULE_PRAYER_TIME_WINDOW = "RULE_PRAYER_TIME_WINDOW"
    RULE_PAIN_ILLNESS_PHYSICAL_PAUSE = "RULE_PAIN_ILLNESS_PHYSICAL_PAUSE"
    RULE_MAX_WEEKLY_LEVEL_INCREASE = "RULE_MAX_WEEKLY_LEVEL_INCREASE"
    RULE_HEAT_INDEX_OUTDOOR_BLOCK = "RULE_HEAT_INDEX_OUTDOOR_BLOCK"
    RULE_ACTIVE_RED_FLAG_HOLD = "RULE_ACTIVE_RED_FLAG_HOLD"


class PlannedSlotCandidateInput(BaseModel):
    """Represents a single active planned slot from the user's current PlanVersion."""

    model_config = ConfigDict(frozen=True)

    slot_id: str
    habit_domain: str
    preferred_time_window: TimeWindow = TimeWindow.EVENING
    primary_action_id: str
    smaller_action_id: str | None = None
    primary_level: LevelLiteral = "L1"
    smaller_level: LevelLiteral = "L1"
    primary_contraindications: tuple[str, ...] = ()
    smaller_contraindications: tuple[str, ...] = ()
    primary_avoid_contexts: tuple[str, ...] = ()
    smaller_avoid_contexts: tuple[str, ...] = ()


class CandidateArm(BaseModel):
    """A single candidate (action_variant, time_window, channel) arm."""

    model_config = ConfigDict(frozen=True)

    arm_key: str  # "{slot_id}:{variant_kind}:{action_id}:{time_window}:{channel}"
    pool_arm_key: str  # "pool:{time_window}:{channel}"
    slot_id: str
    habit_domain: str
    variant_kind: VariantKind
    action_id: str
    time_window: TimeWindow
    channel: Channel
    level: LevelLiteral = "L1"
    contraindications: tuple[str, ...] = ()
    avoid_contexts: tuple[str, ...] = ()


class ExcludedCandidate(BaseModel):
    """Audit record for a candidate arm excluded by a deterministic rule."""

    model_config = ConfigDict(frozen=True)

    arm_key: str
    slot_id: str
    variant_kind: VariantKind
    action_id: str
    time_window: TimeWindow
    channel: Channel
    rule_id: ExclusionRuleId
    reason: str


class ArmStat(BaseModel):
    """Stored Beta(alpha, beta) state in arm_stats(user_id, arm_key, alpha, beta, updated_at)."""

    model_config = ConfigDict(frozen=True)

    arm_key: str
    alpha: float = Field(gt=0.0)
    beta: float = Field(gt=0.0)
    alpha_prior: float = Field(gt=0.0, default=2.0)
    beta_prior: float = Field(gt=0.0, default=2.0)
    pulls: int = Field(ge=0, default=0)
    rewards: int = Field(ge=0, default=0)

    @property
    def delta_alpha(self) -> float:
        return max(0.0, self.alpha - self.alpha_prior)

    @property
    def delta_beta(self) -> float:
        return max(0.0, self.beta - self.beta_prior)


class EffectiveArmPosterior(BaseModel):
    """Hierarchically pooled Beta(alpha_eff, beta_eff) used at decision time."""

    model_config = ConfigDict(frozen=True)

    arm_key: str
    contextual_arm_key: str
    pool_arm_key: str
    context_key: str
    alpha_prior: float
    beta_prior: float
    arm_delta_alpha: float
    arm_delta_beta: float
    pool_delta_alpha: float
    pool_delta_beta: float
    alpha_eff: float
    beta_eff: float
    posterior_mean: float
    sampled_theta: float
    propensity: float


class SelectorContext(BaseModel):
    """Complete deterministic snapshot of inputs to a single selector decision."""

    model_config = ConfigDict(frozen=True)

    user_id: str
    local_date: str  # YYYY-MM-DD in user's timezone
    local_time: str  # HH:MM in user's timezone
    current_time_window: TimeWindow
    day_type: Literal["workday", "day_off"] = "workday"
    work_pattern: Literal["day", "rotating", "nights"] = "day"
    preferred_channel: Channel = Channel.APP
    quiet_hours_start: str | None = None  # HH:MM
    quiet_hours_end: str | None = None  # HH:MM
    daily_notification_budget: int = Field(default=DEFAULT_DAILY_NOTIFICATION_BUDGET, ge=0, le=5)
    nudges_sent_today: int = Field(default=0, ge=0)
    consented_channels: tuple[Channel, ...] = (Channel.APP,)
    completed_slot_ids_today: tuple[str, ...] = ()
    ramadan_fasting_window_active: bool = False
    active_barriers: tuple[str, ...] = ()
    planned_slots: tuple[PlannedSlotCandidateInput, ...] = ()
    restrict_to_current_window: bool = False
    is_paused: bool = False
    paused_until: str | None = None
    steps_consented: bool = False
    wearable_consented: bool = False
    city: str = "abu_dhabi"
    local_heat_index_c: float | None = None
    baseline_level_7d: LevelLiteral | None = None
    has_open_red_flag: bool = False


class Decision(BaseModel):
    """Immutable, auditable result of ThompsonPolicy.choose(context, rng)."""

    model_config = ConfigDict(frozen=True)

    policy_version: str = SELECTOR_POLICY_VERSION
    seed: int
    coarse_context_key: str
    no_op: bool
    no_op_reason: ExclusionRuleId | None = None
    chosen_arm: CandidateArm | None = None
    chosen_propensity: float = 1.0
    exploration_rate: float = DEFAULT_EPSILON
    allowed_candidates: tuple[CandidateArm, ...] = ()
    excluded_candidates: tuple[ExcludedCandidate, ...] = ()
    effective_posteriors: dict[str, EffectiveArmPosterior] = Field(default_factory=dict)
    propensities: dict[str, float] = Field(default_factory=dict)
    inputs_used: dict[str, Any] = Field(default_factory=dict)


SelectorDecision = Decision


class RewardUpdateResult(BaseModel):
    """Result of evaluating a check-in or 6h expiry against a selector decision."""

    model_config = ConfigDict(frozen=True)

    decision_id: str
    previous_status: Literal["no_op", "pending", "rewarded_1", "rewarded_0"]
    new_status: Literal["no_op", "pending", "rewarded_1", "rewarded_0"]
    reward_value: int | None
    applied_delta_alpha: float
    applied_delta_beta: float
    updated_arm_stat: ArmStat | None = None
    updated_pool_stat: ArmStat | None = None


CANONICAL_WINDOW_TIME: dict[TimeWindow, str] = {
    TimeWindow.MORNING: "08:00",
    TimeWindow.AFTERNOON: "14:00",
    TimeWindow.EVENING: "18:30",
    TimeWindow.NIGHT: "22:00",
}


def _parse_hhmm_to_minutes(hhmm: str) -> int:
    parts = hhmm.strip().split(":")
    if len(parts) < 2:
        raise ValueError(f"Invalid HH:MM time string: {hhmm!r}")
    hours = int(parts[0])
    minutes = int(parts[1])
    if not (0 <= hours <= 23 and 0 <= minutes <= 59):
        raise ValueError(f"Out-of-range HH:MM time string: {hhmm!r}")
    return hours * 60 + minutes


def derive_coarse_context_key(day_type: str, work_pattern: str) -> str:
    """Return coarse context key '{day_type}:{work_pattern}'."""
    return f"{day_type.strip().lower()}:{work_pattern.strip().lower()}"


def classify_time_window(local_time: str) -> TimeWindow:
    """Map local HH:MM time to one of morning, afternoon, evening, or night."""
    minutes = _parse_hhmm_to_minutes(local_time)
    if 300 <= minutes < 720:
        return TimeWindow.MORNING
    if 720 <= minutes < 1020:
        return TimeWindow.AFTERNOON
    if 1020 <= minutes < 1260:
        return TimeWindow.EVENING
    return TimeWindow.NIGHT


def is_in_quiet_hours(check_time: str, quiet_start: str | None, quiet_end: str | None) -> bool:
    """Return True if check_time (HH:MM) falls inside [quiet_start, quiet_end)."""
    if not quiet_start or not quiet_end:
        return False
    check_min = _parse_hhmm_to_minutes(check_time)
    start_min = _parse_hhmm_to_minutes(quiet_start)
    end_min = _parse_hhmm_to_minutes(quiet_end)
    if start_min == end_min:
        return False
    if start_min < end_min:
        return start_min <= check_min < end_min
    return check_min >= start_min or check_min < end_min


def default_population_prior(
    variant_kind: VariantKind,
    time_window: TimeWindow,
    channel: Channel,
    preferred_channel: Channel = Channel.APP,
    preferred_time_window: TimeWindow | None = None,
) -> tuple[float, float]:
    """Compute cold-start Beta(alpha_0, beta_0) prior with preferred-channel/window boosts."""
    _ = variant_kind
    alpha_0 = 2.0
    beta_0 = 2.0
    if channel == preferred_channel:
        alpha_0 += 0.5
    if preferred_time_window is not None and time_window == preferred_time_window:
        alpha_0 += 0.5
    return (alpha_0, beta_0)


def build_candidate_arms(
    planned_slots: tuple[PlannedSlotCandidateInput, ...],
    time_windows: tuple[TimeWindow, ...] | None = None,
    channels: tuple[Channel, ...] | None = None,
) -> tuple[CandidateArm, ...]:
    """Expand active planned slots into candidate (action_variant, time_window, channel) arms."""
    windows = time_windows or (
        TimeWindow.MORNING,
        TimeWindow.AFTERNOON,
        TimeWindow.EVENING,
        TimeWindow.NIGHT,
    )
    all_channels = channels or (Channel.APP, Channel.WHATSAPP, Channel.SMS)

    arms: list[CandidateArm] = []
    for slot in planned_slots:
        variants: list[tuple[VariantKind, str, LevelLiteral, tuple[str, ...], tuple[str, ...]]] = [
            (
                VariantKind.PRIMARY,
                slot.primary_action_id,
                slot.primary_level,
                slot.primary_contraindications,
                slot.primary_avoid_contexts,
            )
        ]
        if slot.smaller_action_id and slot.smaller_action_id != slot.primary_action_id:
            variants.append(
                (
                    VariantKind.SMALLER,
                    slot.smaller_action_id,
                    slot.smaller_level,
                    slot.smaller_contraindications,
                    slot.smaller_avoid_contexts,
                )
            )
        for variant_kind, action_id, level, contraindications, avoid_contexts in variants:
            for tw in windows:
                for ch in all_channels:
                    arm_key = (
                        f"{slot.slot_id}:{variant_kind.value}:{action_id}:{tw.value}:{ch.value}"
                    )
                    pool_arm_key = f"pool:{tw.value}:{ch.value}"
                    arms.append(
                        CandidateArm(
                            arm_key=arm_key,
                            pool_arm_key=pool_arm_key,
                            slot_id=slot.slot_id,
                            habit_domain=slot.habit_domain,
                            variant_kind=variant_kind,
                            action_id=action_id,
                            time_window=tw,
                            channel=ch,
                            level=level,
                            contraindications=contraindications,
                            avoid_contexts=avoid_contexts,
                        )
                    )
    return tuple(arms)


_POLICY_RULE_TO_EXCLUSION: dict[str, ExclusionRuleId] = {
    "active_red_flag_hold": ExclusionRuleId.RULE_ACTIVE_RED_FLAG_HOLD,
    "pain_illness_physical_pause": ExclusionRuleId.RULE_PAIN_ILLNESS_PHYSICAL_PAUSE,
    "contraindicated_action": ExclusionRuleId.RULE_BARRIER_CONTRAINDICATION,
    "prayer_time_window": ExclusionRuleId.RULE_PRAYER_TIME_WINDOW,
    "ramadan_fasting_window": ExclusionRuleId.RULE_RAMADAN_FASTING_CONTRAINDICATION,
    "heat_index_outdoor_block": ExclusionRuleId.RULE_HEAT_INDEX_OUTDOOR_BLOCK,
    "max_weekly_level_increase": ExclusionRuleId.RULE_MAX_WEEKLY_LEVEL_INCREASE,
}


def _filter_and_modify_candidates(
    candidates: tuple[CandidateArm, ...],
    context: SelectorContext,
) -> tuple[
    tuple[CandidateArm, ...],
    tuple[ExcludedCandidate, ...],
    ExclusionRuleId | None,
    list[dict[str, Any]],
]:
    """Deterministically filter and apply central policy modifications to candidate arms."""
    if not context.planned_slots or not candidates:
        return (), (), ExclusionRuleId.RULE_NO_ACTIVE_PLAN, []

    if context.is_paused:
        excluded_paused = tuple(
            ExcludedCandidate(
                arm_key=arm.arm_key,
                slot_id=arm.slot_id,
                variant_kind=arm.variant_kind,
                action_id=arm.action_id,
                time_window=arm.time_window,
                channel=arm.channel,
                rule_id=ExclusionRuleId.RULE_USER_PAUSED,
                reason="User has paused all suggestions.",
            )
            for arm in candidates
        )
        return (), excluded_paused, ExclusionRuleId.RULE_USER_PAUSED, []

    if context.nudges_sent_today >= context.daily_notification_budget:
        excluded_budget = tuple(
            ExcludedCandidate(
                arm_key=arm.arm_key,
                slot_id=arm.slot_id,
                variant_kind=arm.variant_kind,
                action_id=arm.action_id,
                time_window=arm.time_window,
                channel=arm.channel,
                rule_id=ExclusionRuleId.RULE_DAILY_BUDGET_REACHED,
                reason=(
                    f"Daily notification budget reached "
                    f"({context.nudges_sent_today}/{context.daily_notification_budget})."
                ),
            )
            for arm in candidates
        )
        return (), excluded_budget, ExclusionRuleId.RULE_DAILY_BUDGET_REACHED, []

    allowed: list[CandidateArm] = []
    excluded: list[ExcludedCandidate] = []
    modifications: list[dict[str, Any]] = []
    completed_set = set(context.completed_slot_ids_today)
    consented_set = set(context.consented_channels)

    for arm in candidates:
        canonical_time = CANONICAL_WINDOW_TIME[arm.time_window]
        in_quiet = is_in_quiet_hours(
            context.local_time, context.quiet_hours_start, context.quiet_hours_end
        ) or is_in_quiet_hours(canonical_time, context.quiet_hours_start, context.quiet_hours_end)
        if in_quiet:
            excluded.append(
                ExcludedCandidate(
                    arm_key=arm.arm_key,
                    slot_id=arm.slot_id,
                    variant_kind=arm.variant_kind,
                    action_id=arm.action_id,
                    time_window=arm.time_window,
                    channel=arm.channel,
                    rule_id=ExclusionRuleId.RULE_QUIET_HOURS,
                    reason=f"Time window '{arm.time_window.value}' falls inside quiet hours.",
                )
            )
            continue

        if arm.slot_id in completed_set:
            excluded.append(
                ExcludedCandidate(
                    arm_key=arm.arm_key,
                    slot_id=arm.slot_id,
                    variant_kind=arm.variant_kind,
                    action_id=arm.action_id,
                    time_window=arm.time_window,
                    channel=arm.channel,
                    rule_id=ExclusionRuleId.RULE_SLOT_ALREADY_COMPLETED_TODAY,
                    reason=f"Slot '{arm.slot_id}' is already completed today.",
                )
            )
            continue

        if arm.channel not in consented_set:
            excluded.append(
                ExcludedCandidate(
                    arm_key=arm.arm_key,
                    slot_id=arm.slot_id,
                    variant_kind=arm.variant_kind,
                    action_id=arm.action_id,
                    time_window=arm.time_window,
                    channel=arm.channel,
                    rule_id=ExclusionRuleId.RULE_CHANNEL_NOT_CONSENTED,
                    reason=f"Channel '{arm.channel.value}' does not have active user consent.",
                )
            )
            continue

        if context.restrict_to_current_window and arm.time_window != context.current_time_window:
            excluded.append(
                ExcludedCandidate(
                    arm_key=arm.arm_key,
                    slot_id=arm.slot_id,
                    variant_kind=arm.variant_kind,
                    action_id=arm.action_id,
                    time_window=arm.time_window,
                    channel=arm.channel,
                    rule_id=ExclusionRuleId.RULE_OUTSIDE_CURRENT_WINDOW,
                    reason=(
                        f"Arm window '{arm.time_window.value}' is outside current window "
                        f"'{context.current_time_window.value}'."
                    ),
                )
            )
            continue

        policy_ctx = CandidatePolicyContext(
            user_id=context.user_id,
            slot_id=arm.slot_id,
            habit_domain=arm.habit_domain,
            action_id=arm.action_id,
            variant_kind=arm.variant_kind.value,
            level=arm.level,
            time_window=arm.time_window.value,
            current_time_window=context.current_time_window.value,
            channel=arm.channel.value,
            local_date=context.local_date,
            local_time=context.local_time,
            city=context.city,
            contraindications=arm.contraindications,
            avoid_contexts=arm.avoid_contexts,
            active_barriers=context.active_barriers,
            heat_index_c=context.local_heat_index_c,
            ramadan_mode=context.ramadan_fasting_window_active,
            baseline_level_7d=context.baseline_level_7d,
            has_open_red_flag=context.has_open_red_flag,
        )
        policy_res = evaluate_candidate_policy(policy_ctx)
        if policy_res.verdict == "block":
            first_rule = policy_res.rule_ids[0] if policy_res.rule_ids else "contraindicated_action"
            ex_rule = _POLICY_RULE_TO_EXCLUSION.get(
                first_rule, ExclusionRuleId.RULE_BARRIER_CONTRAINDICATION
            )
            reason = (
                policy_res.triggered_rules[0].reason
                if policy_res.triggered_rules
                else f"Blocked by central policy rule '{first_rule}'."
            )
            excluded.append(
                ExcludedCandidate(
                    arm_key=arm.arm_key,
                    slot_id=arm.slot_id,
                    variant_kind=arm.variant_kind,
                    action_id=arm.action_id,
                    time_window=arm.time_window,
                    channel=arm.channel,
                    rule_id=ex_rule,
                    reason=reason,
                )
            )
            continue

        effective_arm = arm
        if policy_res.verdict == "modify" and policy_res.modified_payload:
            new_action_id = str(policy_res.modified_payload.get("action_id", arm.action_id))
            new_arm_key = (
                f"{arm.slot_id}:{arm.variant_kind.value}:{new_action_id}:"
                f"{arm.time_window.value}:{arm.channel.value}"
            )
            cleaned_contras = tuple(
                c for c in arm.contraindications if c not in ("heat_exposure", "extreme_heat")
            )
            cleaned_avoid = tuple(c for c in arm.avoid_contexts if c != "midday_heat")
            effective_arm = arm.model_copy(
                update={
                    "arm_key": new_arm_key,
                    "action_id": new_action_id,
                    "contraindications": cleaned_contras,
                    "avoid_contexts": cleaned_avoid,
                }
            )
            for tr in policy_res.triggered_rules:
                if tr.verdict == "modify":
                    modifications.append(
                        {
                            "rule_id": tr.rule_id,
                            "slot_id": arm.slot_id,
                            "time_window": arm.time_window.value,
                            "channel": arm.channel.value,
                            "original_action_id": arm.action_id,
                            "modified_action_id": new_action_id,
                            "reason": tr.reason,
                            "modified_fields": tr.modified_fields,
                        }
                    )

        allowed.append(effective_arm)

    no_op_reason: ExclusionRuleId | None = None
    if not allowed:
        no_op_reason = excluded[0].rule_id if excluded else ExclusionRuleId.RULE_NO_ACTIVE_PLAN

    return tuple(allowed), tuple(excluded), no_op_reason, modifications


def filter_candidates(
    candidates: tuple[CandidateArm, ...],
    context: SelectorContext,
) -> tuple[tuple[CandidateArm, ...], tuple[ExcludedCandidate, ...], ExclusionRuleId | None]:
    """Deterministically filter candidate arms against hard safety, consent, and budget rules."""
    allowed, excluded, no_op_reason, _ = _filter_and_modify_candidates(candidates, context)
    return allowed, excluded, no_op_reason


def compute_effective_posteriors(
    allowed_candidates: tuple[CandidateArm, ...],
    context: SelectorContext,
    arm_stats: dict[str, ArmStat],
) -> dict[str, tuple[float, float, float, float, float, float, float, float]]:
    """Compute hierarchically pooled Beta parameters for each allowed candidate arm.

    Returns dict mapping `arm.arm_key` ->
    `(alpha_prior, beta_prior, arm_delta_alpha, arm_delta_beta,
      pool_delta_alpha, pool_delta_beta, alpha_eff, beta_eff)`.
    """
    context_key = derive_coarse_context_key(context.day_type, context.work_pattern)
    slot_pref_window: dict[str, TimeWindow] = {
        slot.slot_id: slot.preferred_time_window for slot in context.planned_slots
    }

    result: dict[str, tuple[float, float, float, float, float, float, float, float]] = {}
    for arm in allowed_candidates:
        alpha_0, beta_0 = default_population_prior(
            arm.variant_kind,
            arm.time_window,
            arm.channel,
            preferred_channel=context.preferred_channel,
            preferred_time_window=slot_pref_window.get(arm.slot_id),
        )
        contextual_key = f"{context_key}|{arm.arm_key}"
        arm_stat = arm_stats.get(contextual_key) or arm_stats.get(arm.arm_key)
        pool_stat = arm_stats.get(arm.pool_arm_key)

        arm_da = arm_stat.delta_alpha if arm_stat is not None else 0.0
        arm_db = arm_stat.delta_beta if arm_stat is not None else 0.0
        pool_da = pool_stat.delta_alpha if pool_stat is not None else 0.0
        pool_db = pool_stat.delta_beta if pool_stat is not None else 0.0

        alpha_eff = alpha_0 + arm_da + pool_da
        beta_eff = beta_0 + arm_db + pool_db

        result[arm.arm_key] = (
            alpha_0,
            beta_0,
            arm_da,
            arm_db,
            pool_da,
            pool_db,
            alpha_eff,
            beta_eff,
        )
    return result


class ThompsonPolicy:
    """Contextual Beta-Bernoulli Thompson-sampling bandit policy with hierarchical pooling."""

    def __init__(
        self,
        arm_stats: dict[str, ArmStat] | None = None,
        *,
        epsilon: float = DEFAULT_EPSILON,
        propensity_draws: int = DEFAULT_PROPENSITY_DRAWS,
        policy_version: str = SELECTOR_POLICY_VERSION,
    ) -> None:
        self.arm_stats: dict[str, ArmStat] = dict(arm_stats or {})
        self.epsilon = epsilon
        self.propensity_draws = propensity_draws
        self.policy_version = policy_version

    def choose(
        self,
        context: SelectorContext,
        rng: random.Random,
        *,
        seed: int = 0,
    ) -> Decision:
        """Select a candidate arm via Thompson sampling and 1,000-draw propensity estimation."""
        context_key = derive_coarse_context_key(context.day_type, context.work_pattern)
        candidates = build_candidate_arms(context.planned_slots)
        allowed, excluded, no_op_reason, policy_modifications = _filter_and_modify_candidates(
            candidates, context
        )

        inputs_used: dict[str, Any] = {
            "context": context.model_dump(mode="json"),
            "arm_stats": {k: v.model_dump(mode="json") for k, v in sorted(self.arm_stats.items())},
            "epsilon": self.epsilon,
            "propensity_draws": self.propensity_draws,
            "policy_version": self.policy_version,
            "policy_version_guardrail": POLICY_VERSION,
            "policy_modifications": policy_modifications,
        }

        if not allowed:
            return Decision(
                policy_version=self.policy_version,
                seed=seed,
                coarse_context_key=context_key,
                no_op=True,
                no_op_reason=no_op_reason,
                chosen_arm=None,
                chosen_propensity=1.0,
                exploration_rate=self.epsilon,
                allowed_candidates=(),
                excluded_candidates=excluded,
                effective_posteriors={},
                propensities={},
                inputs_used=inputs_used,
            )

        raw_posteriors = compute_effective_posteriors(allowed, context, self.arm_stats)
        k = len(allowed)

        if k == 1:
            only_arm = allowed[0]
            a0, b0, arm_da, arm_db, pool_da, pool_db, a_eff, b_eff = raw_posteriors[
                only_arm.arm_key
            ]
            sampled_theta = rng.betavariate(a_eff, b_eff)
            propensities = {only_arm.arm_key: 1.0}
            effective_posteriors = {
                only_arm.arm_key: EffectiveArmPosterior(
                    arm_key=only_arm.arm_key,
                    contextual_arm_key=f"{context_key}|{only_arm.arm_key}",
                    pool_arm_key=only_arm.pool_arm_key,
                    context_key=context_key,
                    alpha_prior=a0,
                    beta_prior=b0,
                    arm_delta_alpha=arm_da,
                    arm_delta_beta=arm_db,
                    pool_delta_alpha=pool_da,
                    pool_delta_beta=pool_db,
                    alpha_eff=a_eff,
                    beta_eff=b_eff,
                    posterior_mean=a_eff / (a_eff + b_eff),
                    sampled_theta=sampled_theta,
                    propensity=1.0,
                )
            }
            return Decision(
                policy_version=self.policy_version,
                seed=seed,
                coarse_context_key=context_key,
                no_op=False,
                no_op_reason=None,
                chosen_arm=only_arm,
                chosen_propensity=1.0,
                exploration_rate=self.epsilon,
                allowed_candidates=allowed,
                excluded_candidates=excluded,
                effective_posteriors=effective_posteriors,
                propensities=propensities,
                inputs_used=inputs_used,
            )

        # Stage 2a: Monte Carlo propensity estimation (M = self.propensity_draws draws)
        # Group arms by pool_arm_key so each (time_window, channel) pool draws a shared
        # hierarchical pool sample per iteration, combined with the arm-specific sample.
        pool_params: dict[str, tuple[float, float]] = {}
        for arm in allowed:
            if arm.pool_arm_key not in pool_params:
                a0, b0, _, _, pool_da, pool_db, _, _ = raw_posteriors[arm.arm_key]
                pool_params[arm.pool_arm_key] = (a0 + pool_da, b0 + pool_db)

        win_counts: dict[str, int] = {arm.arm_key: 0 for arm in allowed}
        draws = max(1, self.propensity_draws)
        for _ in range(draws):
            pool_thetas = {
                p_key: rng.betavariate(p_a, p_b) for p_key, (p_a, p_b) in pool_params.items()
            }
            best_arm_key = allowed[0].arm_key
            best_theta = -1.0
            for arm in allowed:
                _, _, _, _, _, _, a_eff, b_eff = raw_posteriors[arm.arm_key]
                arm_theta = rng.betavariate(a_eff, b_eff)
                theta = 0.85 * pool_thetas[arm.pool_arm_key] + 0.15 * arm_theta
                if theta > best_theta:
                    best_theta = theta
                    best_arm_key = arm.arm_key
            win_counts[best_arm_key] += 1

        propensities = {}
        for arm in allowed:
            w_a = win_counts[arm.arm_key] / draws
            p_a = (1.0 - self.epsilon) * w_a + (self.epsilon / k)
            propensities[arm.arm_key] = p_a

        # Stage 2b: Actual decision draw (epsilon-uniform exploration + Thompson argmax)
        u = rng.random()
        decision_pool_thetas = {
            p_key: rng.betavariate(p_a, p_b) for p_key, (p_a, p_b) in pool_params.items()
        }
        sampled_thetas: dict[str, float] = {}
        for arm in allowed:
            _, _, _, _, _, _, a_eff, b_eff = raw_posteriors[arm.arm_key]
            arm_theta = rng.betavariate(a_eff, b_eff)
            sampled_thetas[arm.arm_key] = (
                0.85 * decision_pool_thetas[arm.pool_arm_key] + 0.15 * arm_theta
            )

        if u < self.epsilon:
            chosen_arm = allowed[rng.randrange(k)]
        else:
            chosen_arm = max(allowed, key=lambda a: sampled_thetas[a.arm_key])

        effective_posteriors = {}
        for arm in allowed:
            a0, b0, arm_da, arm_db, pool_da, pool_db, a_eff, b_eff = raw_posteriors[arm.arm_key]
            effective_posteriors[arm.arm_key] = EffectiveArmPosterior(
                arm_key=arm.arm_key,
                contextual_arm_key=f"{context_key}|{arm.arm_key}",
                pool_arm_key=arm.pool_arm_key,
                context_key=context_key,
                alpha_prior=a0,
                beta_prior=b0,
                arm_delta_alpha=arm_da,
                arm_delta_beta=arm_db,
                pool_delta_alpha=pool_da,
                pool_delta_beta=pool_db,
                alpha_eff=a_eff,
                beta_eff=b_eff,
                posterior_mean=a_eff / (a_eff + b_eff),
                sampled_theta=sampled_thetas[arm.arm_key],
                propensity=propensities[arm.arm_key],
            )

        return Decision(
            policy_version=self.policy_version,
            seed=seed,
            coarse_context_key=context_key,
            no_op=False,
            no_op_reason=None,
            chosen_arm=chosen_arm,
            chosen_propensity=propensities[chosen_arm.arm_key],
            exploration_rate=self.epsilon,
            allowed_candidates=allowed,
            excluded_candidates=excluded,
            effective_posteriors=effective_posteriors,
            propensities=propensities,
            inputs_used=inputs_used,
        )


def run_selector_decision(
    context: SelectorContext,
    arm_stats: dict[str, ArmStat] | None = None,
    *,
    seed: int = 0,
    epsilon: float = DEFAULT_EPSILON,
    propensity_draws: int = DEFAULT_PROPENSITY_DRAWS,
) -> Decision:
    """Convenience wrapper that creates a seeded RNG and runs ThompsonPolicy.choose."""
    policy = ThompsonPolicy(
        arm_stats,
        epsilon=epsilon,
        propensity_draws=propensity_draws,
    )
    return policy.choose(context, random.Random(seed), seed=seed)


def replay_selector_decision(
    inputs_used: dict[str, Any],
    seed: int,
) -> Decision:
    """Re-run a logged selector decision from its serialized inputs_used snapshot and seed."""
    context = SelectorContext.model_validate(inputs_used["context"])
    raw_arm_stats = inputs_used.get("arm_stats", {})
    arm_stats = {key: ArmStat.model_validate(val) for key, val in raw_arm_stats.items()}
    epsilon = float(inputs_used.get("epsilon", DEFAULT_EPSILON))
    propensity_draws = int(inputs_used.get("propensity_draws", DEFAULT_PROPENSITY_DRAWS))
    policy_version = str(inputs_used.get("policy_version", SELECTOR_POLICY_VERSION))
    policy = ThompsonPolicy(
        arm_stats,
        epsilon=epsilon,
        propensity_draws=propensity_draws,
        policy_version=policy_version,
    )
    return policy.choose(context, random.Random(seed), seed=seed)


def evaluate_reward_window(
    *,
    decision_id: str,
    current_status: Literal["no_op", "pending", "rewarded_1", "rewarded_0"],
    decision_created_at: datetime,
    event_timestamp: datetime,
    checkin_status: Literal["done", "partial", "skipped"] | None,
    arm_stat: ArmStat,
    pool_stat: ArmStat,
) -> RewardUpdateResult:
    """Idempotently compute 6-hour check-in or expiry reward updates for arm and pool stats."""
    elapsed_seconds = (event_timestamp - decision_created_at).total_seconds()
    within_window = elapsed_seconds <= REWARD_WINDOW_HOURS * 3600

    if current_status in ("no_op", "rewarded_1"):
        reward_val = 1 if current_status == "rewarded_1" else None
        return RewardUpdateResult(
            decision_id=decision_id,
            previous_status=current_status,
            new_status=current_status,
            reward_value=reward_val,
            applied_delta_alpha=0.0,
            applied_delta_beta=0.0,
            updated_arm_stat=arm_stat,
            updated_pool_stat=pool_stat,
        )

    if current_status == "pending":
        if within_window and checkin_status in ("done", "partial"):
            delta_alpha = 1.0
            delta_beta = 0.0
            new_status: Literal["rewarded_1", "rewarded_0"] = "rewarded_1"
            reward_value = 1
            pull_inc = 1
            reward_inc = 1
        else:
            delta_alpha = 0.0
            delta_beta = 1.0
            new_status = "rewarded_0"
            reward_value = 0
            pull_inc = 1
            reward_inc = 0

        updated_arm = ArmStat(
            arm_key=arm_stat.arm_key,
            alpha=arm_stat.alpha + delta_alpha,
            beta=arm_stat.beta + delta_beta,
            alpha_prior=arm_stat.alpha_prior,
            beta_prior=arm_stat.beta_prior,
            pulls=arm_stat.pulls + pull_inc,
            rewards=arm_stat.rewards + reward_inc,
        )
        updated_pool = ArmStat(
            arm_key=pool_stat.arm_key,
            alpha=pool_stat.alpha + delta_alpha,
            beta=pool_stat.beta + delta_beta,
            alpha_prior=pool_stat.alpha_prior,
            beta_prior=pool_stat.beta_prior,
            pulls=pool_stat.pulls + pull_inc,
            rewards=pool_stat.rewards + reward_inc,
        )
        return RewardUpdateResult(
            decision_id=decision_id,
            previous_status=current_status,
            new_status=new_status,
            reward_value=reward_value,
            applied_delta_alpha=delta_alpha,
            applied_delta_beta=delta_beta,
            updated_arm_stat=updated_arm,
            updated_pool_stat=updated_pool,
        )

    # current_status == "rewarded_0"
    if within_window and checkin_status in ("done", "partial"):
        delta_alpha = 1.0
        delta_beta = -1.0
        updated_arm = ArmStat(
            arm_key=arm_stat.arm_key,
            alpha=arm_stat.alpha + delta_alpha,
            beta=max(0.01, arm_stat.beta + delta_beta),
            alpha_prior=arm_stat.alpha_prior,
            beta_prior=arm_stat.beta_prior,
            pulls=arm_stat.pulls,
            rewards=arm_stat.rewards + 1,
        )
        updated_pool = ArmStat(
            arm_key=pool_stat.arm_key,
            alpha=pool_stat.alpha + delta_alpha,
            beta=max(0.01, pool_stat.beta + delta_beta),
            alpha_prior=pool_stat.alpha_prior,
            beta_prior=pool_stat.beta_prior,
            pulls=pool_stat.pulls,
            rewards=pool_stat.rewards + 1,
        )
        return RewardUpdateResult(
            decision_id=decision_id,
            previous_status=current_status,
            new_status="rewarded_1",
            reward_value=1,
            applied_delta_alpha=delta_alpha,
            applied_delta_beta=delta_beta,
            updated_arm_stat=updated_arm,
            updated_pool_stat=updated_pool,
        )

    return RewardUpdateResult(
        decision_id=decision_id,
        previous_status=current_status,
        new_status="rewarded_0",
        reward_value=0,
        applied_delta_alpha=0.0,
        applied_delta_beta=0.0,
        updated_arm_stat=arm_stat,
        updated_pool_stat=pool_stat,
    )


def simulate_persona_14_days(
    *,
    seed: int = 20260420,
    days: int = 14,
    decisions_per_day: int = 2,
) -> dict[str, Any]:
    """Run a deterministic 14-day synthetic persona simulation (SC-001).

    The persona responds with 90% completion probability when nudged in the
    `evening` via `whatsapp` and 5% completion probability for all other
    (time_window, channel) combinations.
    """
    from datetime import UTC, timedelta

    env_rng = random.Random(seed ^ 0x5A5A5A5A)
    arm_stats: dict[str, ArmStat] = {}
    slots = (
        PlannedSlotCandidateInput(
            slot_id="slot-mov",
            habit_domain="movement",
            preferred_time_window=TimeWindow.EVENING,
            primary_action_id="mov_02",
            smaller_action_id="mov_01",
        ),
        PlannedSlotCandidateInput(
            slot_id="slot-nut",
            habit_domain="nutrition",
            preferred_time_window=TimeWindow.EVENING,
            primary_action_id="nut_01",
            smaller_action_id="nut_01_s",
        ),
    )

    total_decisions = 0
    week2_decisions = 0
    week2_evening_whatsapp = 0
    min_propensity_observed = 1.0
    min_theoretical_propensity = 1.0
    replay_verified = True
    base_dt = datetime(2026, 4, 1, 9, 0, tzinfo=UTC)

    for day in range(days):
        completed_today: list[str] = []
        for dec_idx in range(decisions_per_day):
            step_seed = seed + day * 100 + dec_idx
            ctx = SelectorContext(
                user_id="sim-persona-evening-wa",
                local_date=f"2026-04-{day + 1:02d}",
                local_time="18:00" if dec_idx == 1 else "10:00",
                current_time_window=TimeWindow.EVENING if dec_idx == 1 else TimeWindow.MORNING,
                day_type="workday",
                work_pattern="day",
                preferred_channel=Channel.WHATSAPP,
                quiet_hours_start="22:00",
                quiet_hours_end="06:00",
                daily_notification_budget=decisions_per_day,
                nudges_sent_today=dec_idx,
                consented_channels=(Channel.APP, Channel.WHATSAPP, Channel.SMS),
                completed_slot_ids_today=tuple(completed_today),
                planned_slots=slots,
            )
            decision = run_selector_decision(ctx, arm_stats, seed=step_seed)
            replayed = replay_selector_decision(decision.inputs_used, step_seed)
            if (
                replayed.chosen_arm != decision.chosen_arm
                or replayed.propensities != decision.propensities
            ):
                replay_verified = False

            if decision.no_op or decision.chosen_arm is None:
                continue

            total_decisions += 1
            k = len(decision.allowed_candidates)
            min_theoretical_propensity = min(min_theoretical_propensity, DEFAULT_EPSILON / k)
            min_propensity_observed = min(
                min_propensity_observed,
                min(decision.propensities.values()),
            )

            chosen = decision.chosen_arm
            is_ev_wa = (
                chosen.time_window == TimeWindow.EVENING and chosen.channel == Channel.WHATSAPP
            )
            if day >= days // 2:
                week2_decisions += 1
                if is_ev_wa:
                    week2_evening_whatsapp += 1

            # Ground-truth synthetic persona response: responds predominantly to evening + whatsapp
            win_prob = 0.92 if is_ev_wa else 0.05
            completed = env_rng.random() < win_prob
            checkin_status: Literal["done", "skipped"] = "done" if completed else "skipped"
            if completed:
                completed_today.append(chosen.slot_id)

            post = decision.effective_posteriors[chosen.arm_key]
            existing_arm = arm_stats.get(
                post.contextual_arm_key,
                ArmStat(
                    arm_key=post.contextual_arm_key,
                    alpha=post.alpha_prior,
                    beta=post.beta_prior,
                    alpha_prior=post.alpha_prior,
                    beta_prior=post.beta_prior,
                ),
            )
            existing_pool = arm_stats.get(
                post.pool_arm_key,
                ArmStat(
                    arm_key=post.pool_arm_key,
                    alpha=2.0,
                    beta=2.0,
                    alpha_prior=2.0,
                    beta_prior=2.0,
                ),
            )
            dec_time = base_dt + timedelta(days=day, hours=dec_idx * 8)
            upd = evaluate_reward_window(
                decision_id=f"sim-{day}-{dec_idx}",
                current_status="pending",
                decision_created_at=dec_time,
                event_timestamp=dec_time + timedelta(hours=1),
                checkin_status=checkin_status,
                arm_stat=existing_arm,
                pool_stat=existing_pool,
            )
            if upd.updated_arm_stat is not None:
                arm_stats[post.contextual_arm_key] = upd.updated_arm_stat
            if upd.updated_pool_stat is not None:
                arm_stats[post.pool_arm_key] = upd.updated_pool_stat

    week2_share = week2_evening_whatsapp / week2_decisions if week2_decisions > 0 else 0.0
    return {
        "total_decisions": total_decisions,
        "week2_decisions": week2_decisions,
        "week2_evening_whatsapp_count": week2_evening_whatsapp,
        "week2_evening_whatsapp_share": week2_share,
        "min_propensity_observed": min_propensity_observed,
        "min_theoretical_propensity": min_theoretical_propensity,
        "deterministic_replay_verified": replay_verified,
    }
