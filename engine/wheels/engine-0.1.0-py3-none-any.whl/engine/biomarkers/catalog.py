"""Versioned biomarker catalogue: codes, LOINC, units, plausibility and fixed thresholds (F21 R3).

Pure data plus small pure functions. Values are ``Decimal`` so conversions are exact and
reproducible (SC-003). Nothing here interprets a value clinically; the safety boundary only
decides whether the fixed care-team note is shown and plan intensity is held (FR-011).
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal
from enum import StrEnum
from types import MappingProxyType
from typing import Final

CATALOG_VERSION: Final = "bm-1"
ANALYSIS_CONFIG_VERSION: Final = "bm-analysis-1"
BP_PANEL_LOINC: Final = "85354-9"
VALUE_QUANTUM: Final = Decimal("0.01")


class BiomarkerCode(StrEnum):
    HBA1C = "hba1c"
    SYSTOLIC_BP = "systolic_bp"
    DIASTOLIC_BP = "diastolic_bp"
    TOTAL_CHOLESTEROL = "total_cholesterol"
    LDL_CHOLESTEROL = "ldl_cholesterol"
    HDL_CHOLESTEROL = "hdl_cholesterol"
    TRIGLYCERIDES = "triglycerides"
    BMI = "bmi"
    WAIST = "waist"


BODY_MEASURES: Final = frozenset({BiomarkerCode.BMI, BiomarkerCode.WAIST})


@dataclass(frozen=True, slots=True)
class UnitConversion:
    """``standard = value * multiply / divide + add`` for one accepted source unit."""

    unit: str
    multiply: Decimal = Decimal(1)
    divide: Decimal = Decimal(1)
    add: Decimal = Decimal(0)

    def apply(self, value: Decimal) -> Decimal:
        return value * self.multiply / self.divide + self.add


@dataclass(frozen=True, slots=True)
class BiomarkerSpec:
    code: BiomarkerCode
    loinc_codes: tuple[str, ...]
    standard_unit: str
    conversions: tuple[UnitConversion, ...]
    plausible_min: Decimal
    plausible_max: Decimal


def _same(*units: str) -> tuple[UnitConversion, ...]:
    return tuple(UnitConversion(unit) for unit in units)


_MG_DL_CHOL = UnitConversion("mg/dL", divide=Decimal("38.67"))
_MMHG = _same("mmHg", "mm[Hg]")
_MMOL_L = _same("mmol/L")

BIOMARKER_CATALOG: Final = MappingProxyType(
    {
        spec.code: spec
        for spec in (
            BiomarkerSpec(
                BiomarkerCode.HBA1C,
                ("4548-4", "59261-8"),
                "%",
                (
                    *_same("%"),
                    UnitConversion("mmol/mol", multiply=Decimal("0.09148"), add=Decimal("2.152")),
                ),
                Decimal("3.0"),
                Decimal("20.0"),
            ),
            BiomarkerSpec(
                BiomarkerCode.SYSTOLIC_BP, ("8480-6",), "mmHg", _MMHG, Decimal(60), Decimal(300)
            ),
            BiomarkerSpec(
                BiomarkerCode.DIASTOLIC_BP, ("8462-4",), "mmHg", _MMHG, Decimal(30), Decimal(200)
            ),
            BiomarkerSpec(
                BiomarkerCode.TOTAL_CHOLESTEROL,
                ("2093-3",),
                "mmol/L",
                (*_MMOL_L, _MG_DL_CHOL),
                Decimal("1.0"),
                Decimal("20.0"),
            ),
            BiomarkerSpec(
                BiomarkerCode.LDL_CHOLESTEROL,
                ("13457-7", "18262-6"),
                "mmol/L",
                (*_MMOL_L, _MG_DL_CHOL),
                Decimal("0.2"),
                Decimal("15.0"),
            ),
            BiomarkerSpec(
                BiomarkerCode.HDL_CHOLESTEROL,
                ("2085-9",),
                "mmol/L",
                (*_MMOL_L, _MG_DL_CHOL),
                Decimal("0.1"),
                Decimal("5.0"),
            ),
            BiomarkerSpec(
                BiomarkerCode.TRIGLYCERIDES,
                ("2571-8",),
                "mmol/L",
                (*_MMOL_L, UnitConversion("mg/dL", divide=Decimal("88.57"))),
                Decimal("0.1"),
                Decimal("50.0"),
            ),
            BiomarkerSpec(
                BiomarkerCode.BMI, ("39156-5",), "kg/m2", _same("kg/m2"), Decimal(10), Decimal(90)
            ),
            BiomarkerSpec(
                BiomarkerCode.WAIST,
                ("8280-0", "56086-2"),
                "cm",
                (*_same("cm"), UnitConversion("in", multiply=Decimal("2.54"))),
                Decimal(40),
                Decimal(250),
            ),
        )
    }
)

_LOINC_INDEX: Final = MappingProxyType(
    {loinc: spec.code for spec in BIOMARKER_CATALOG.values() for loinc in spec.loinc_codes}
)

SAFETY_BOUNDARY: Final = MappingProxyType(
    {
        BiomarkerCode.SYSTOLIC_BP: Decimal("180"),
        BiomarkerCode.DIASTOLIC_BP: Decimal("120"),
        BiomarkerCode.HBA1C: Decimal("10.0"),
    }
)

# Follow-up minus baseline at or below these values counts as meaningful change (FR-014).
# BMI is a relative change in percent; all others are absolute in the standard unit.
MEANINGFUL_CHANGE: Final = MappingProxyType(
    {
        BiomarkerCode.HBA1C: Decimal("-0.5"),
        BiomarkerCode.SYSTOLIC_BP: Decimal("-5"),
        BiomarkerCode.DIASTOLIC_BP: Decimal("-3"),
        BiomarkerCode.LDL_CHOLESTEROL: Decimal("-0.3"),
        BiomarkerCode.BMI: Decimal("-5"),
        BiomarkerCode.WAIST: Decimal("-5"),
    }
)
RELATIVE_THRESHOLD_CODES: Final = frozenset({BiomarkerCode.BMI})


def code_for_loinc(loinc: str) -> BiomarkerCode | None:
    """Catalogue code for a LOINC code, or None when the code is out of scope."""
    return _LOINC_INDEX.get(loinc)


def loinc_codes_for(codes: tuple[BiomarkerCode, ...]) -> tuple[str, ...]:
    """LOINC codes to request for the given biomarkers (the BP panel when BP is wanted)."""
    loincs = [loinc for code in codes for loinc in BIOMARKER_CATALOG[code].loinc_codes]
    if {BiomarkerCode.SYSTOLIC_BP, BiomarkerCode.DIASTOLIC_BP} & set(codes):
        loincs.append(BP_PANEL_LOINC)
    return tuple(loincs)


def to_standard_unit(code: BiomarkerCode, value: Decimal, unit: str) -> Decimal | None:
    """Convert to the standard unit (rounded to 0.01), or None for an unknown unit."""
    for conversion in BIOMARKER_CATALOG[code].conversions:
        if conversion.unit == unit:
            return conversion.apply(value).quantize(VALUE_QUANTUM, rounding=ROUND_HALF_UP)
    return None


def is_plausible(code: BiomarkerCode, value: Decimal) -> bool:
    spec = BIOMARKER_CATALOG[code]
    return spec.plausible_min <= value <= spec.plausible_max


def meets_safety_boundary(code: BiomarkerCode, value: Decimal) -> bool:
    boundary = SAFETY_BOUNDARY.get(code)
    return boundary is not None and value >= boundary
