"""The live Lapse Radar for the sandbox (spec 023 US3).

Every simulated day the existing, audited ``engine.lapse_radar`` is run on the user's real history
and consented context. This module only prepares its inputs and keeps the episode and coach state;
the scoring and the reasons are the radar's own (Constitution III).

Rules that matter here:
* only closed days with no check-in count as missed; today counts once it has a mark;
* missing or switched-off sensor data is never inactivity (the activity signal is simply left out);
* withdrawing consent to use check-ins pauses the radar instead of scoring.
"""

from __future__ import annotations

from datetime import date, timedelta
from functools import cache
from typing import Any

from engine.lapse_radar import (
    CheckInDayRecord,
    DailyActivitySample,
    Features,
    LapseContextInput,
    LapseHistoryInput,
    LapseReasonCode,
    LapseSignalsInput,
    LapseState,
    LapseWeights,
    NudgeResponseRecord,
    SensorSyncStatus,
    features,
    load_lapse_weights,
    score,
)
from engine.progress import ACTIVE_STATUSES
from engine.sandbox.commands import Event
from engine.sandbox.context import (
    NIGHT_BLOCK_WINDOW_DAYS,
    PATTERN_CHANGE_WINDOW_DAYS,
    RAMADAN_WINDOW_DAYS,
    consent_granted,
    has_sensor,
    latest_context,
    todays_steps,
    with_latest_context,
)
from engine.sandbox.state import State, to_engine_work_pattern
from engine.sandbox.trail import append_entry, last_decision_id

LEVELS: tuple[str, ...] = ("steady", "watch", "lapse_risk", "lapsed")
LAPSE_LEVELS: frozenset[str] = frozenset({"lapse_risk", "lapsed"})
RECOVERY_OFFER_SPACING_DAYS = 2  # at most one recovery message per 48 simulated hours
RADAR_CONSENTS: tuple[str, ...] = (
    "checkins:risk_detection",
    "activity_sensor:risk_detection",
    "work_pattern:risk_detection",
)
_STATUS_RANK = {"skipped": 1, "partial": 2, "done": 3}
_LEVEL_OF = {
    LapseState.HEALTHY: "steady",
    LapseState.WATCH: "watch",
    LapseState.LAPSE_RISK: "lapse_risk",
    LapseState.LAPSED: "lapsed",
}


@cache
def _weights() -> LapseWeights:
    return load_lapse_weights()


def _best_status_by_day(state: State) -> dict[str, str]:
    best: dict[str, str] = {}
    for entry in state["checkins"]:
        current = best.get(entry["date"])
        if current is None or _STATUS_RANK[entry["status"]] > _STATUS_RANK[current]:
            best[entry["date"]] = entry["status"]
    return best


def _history(state: State) -> LapseHistoryInput:
    best = _best_status_by_day(state)
    today = date.fromisoformat(state["current_date"])
    day = date.fromisoformat(state["start_date"])
    records: list[CheckInDayRecord] = []
    while day <= today:
        iso = day.isoformat()
        status = best.get(iso)
        if status is None:
            if day == today:
                break  # today is not over, so it is not a missed day yet
            status = "unanswered"
        records.append(CheckInDayRecord(local_date=iso, status=status))
        day += timedelta(days=1)
    nudges = tuple(
        NudgeResponseRecord(local_date=r.local_date, responded=r.status in ACTIVE_STATUSES)
        for r in records[-7:]
    )
    return LapseHistoryInput(checkins=tuple(records), nudge_responses=nudges)


def _signals(state: State) -> LapseSignalsInput:
    if not (consent_granted(state, "activity_sensor:risk_detection") and has_sensor(state)):
        return LapseSignalsInput()  # missing data is left out, never read as inactivity
    samples = tuple(
        DailyActivitySample(local_date=day["date"], activity_value=float(day["steps"]))
        for day in state["context_days"]
        if day["steps"] is not None
    )
    return LapseSignalsInput(
        wearable_consented=True, sync_status=SensorSyncStatus.ACTIVE, daily_samples=samples
    )


def _context(state: State) -> LapseContextInput:
    day = latest_context(state)
    use_routine = consent_granted(state, "work_pattern:risk_detection")

    def within(counter: int | None, window: int) -> bool:
        return use_routine and counter is not None and counter <= window

    return LapseContextInput(
        user_id=state["profile"]["persona_id"] or "sandbox-user",
        local_date=state["current_date"],
        enrolled_local_date=state["start_date"],
        work_pattern=to_engine_work_pattern(day["work_pattern"]),
        night_shift_block_started_recently=within(
            day["night_shift_block_day"], NIGHT_BLOCK_WINDOW_DAYS
        ),
        work_pattern_changed_recently=within(day["pattern_change_day"], PATTERN_CHANGE_WINDOW_DAYS),
        ramadan_started_recently=within(day["ramadan_day"], RAMADAN_WINDOW_DAYS),
    )


def _reason_params(code: LapseReasonCode, feats: Features) -> dict[str, Any]:
    if code is LapseReasonCode.CHECKIN_GAP:
        return {"days": feats.days_since_last_checkin}
    if code is LapseReasonCode.LAPSED_INACTIVITY_WINDOW:
        return {
            "days": max(
                feats.consecutive_no_checkin_and_no_signal_days, feats.days_since_last_checkin
            )
        }
    return {}


def _context_codes(feats: Features) -> list[str]:
    codes: list[str] = []
    if feats.night_shift_block_active:
        codes.append(LapseReasonCode.NIGHT_SHIFT_TRANSITION.value)
    elif feats.work_pattern_change and not feats.ramadan_started:
        codes.append(LapseReasonCode.WORK_PATTERN_CHANGE.value)
    if feats.ramadan_started:
        codes.append(LapseReasonCode.RAMADAN_STARTED.value)
    return codes


def _with_todays_steps(state: State) -> State:
    active_today = any(
        c["date"] == state["current_date"] and c["status"] in ACTIVE_STATUSES
        for c in state["checkins"]
    )
    day = {**latest_context(state), "steps": todays_steps(state, checked_in=active_today)}
    return with_latest_context(state, day)


def _record(state: State, result: dict[str, Any]) -> State:
    others = [r for r in state["risk_results"] if r["date"] != result["date"]]
    return {**state, "risk_results": [*others, result]}


def _score(state: State) -> tuple[State, dict[str, Any]]:
    """Score the current day and log it. Returns the state and the new RiskResult."""
    today = state["current_date"]
    excluded = [pair for pair in RADAR_CONSENTS if not consent_granted(state, pair)]
    if not consent_granted(state, "checkins:risk_detection"):
        result: dict[str, Any] = {
            "date": today,
            "score": None,
            "level": "paused",
            "reasons": [{"code": "consent_paused", "params": {}}],
            "context": [],
            "features": {},
            "excluded_sources": excluded,
            "weights_version": _weights().version,
            "policy_version": _weights().version,
        }
        used: dict[str, Any] = {"paused": True}
    else:
        feats = features(_history(state), _signals(state), _context(state))
        risk = score(feats, _weights())
        level = _LEVEL_OF[risk.state]
        result = {
            "date": today,
            "score": risk.score,
            "level": level,
            "reasons": [
                {"code": code.value, "params": _reason_params(code, feats)}
                for code in risk.reason_codes
            ],
            "context": _context_codes(feats),
            "features": {
                "days_since_last_checkin": feats.days_since_last_checkin,
                "completion_rate_7d": round(feats.completion_rate_7d, 4),
                "completion_rate_28d": round(feats.completion_rate_28d, 4),
                "consecutive_silent_days": feats.consecutive_no_checkin_and_no_signal_days,
                "activity_signal_available": feats.wearable_signal_available,
            },
            "excluded_sources": excluded,
            "weights_version": risk.policy_version,
            "policy_version": risk.policy_version,
        }
        used = dict(result["features"])
    entry_state = append_entry(
        state,
        decision_type="risk_scored",
        on=today,
        policy_version=result["policy_version"],
        inputs_used={**used, "context": result["context"]},
        excluded_sources=excluded,
        candidate_set=[*LEVELS, "paused"],
        chosen=result["level"],
        propensities=[1.0],
        summary_key="trail.risk_scored",
    )
    result["decision_id"] = last_decision_id(entry_state)
    return _record(entry_state, result), result


def _engaged_recently(state: State) -> bool:
    """Whether the user did something today or yesterday.

    An engaged user has not lapsed, even if the 7-day pace still looks quiet next to an older,
    busier baseline. Without this, someone who just came back would be offered help again.
    """
    today = date.fromisoformat(state["current_date"])
    best = _best_status_by_day(state)
    recent = (today.isoformat(), (today - timedelta(days=1)).isoformat())
    return any(best.get(day) in ACTIVE_STATUSES for day in recent)


def _open_episode(state: State) -> dict[str, Any] | None:
    return next((e for e in reversed(state["lapse_episodes"]) if e["closed_on"] is None), None)


def _offer_allowed(state: State, today: str) -> bool:
    offers = [m["date"] for m in state["coach_messages"] if m["kind"] == "recovery_offer"]
    if not offers:
        return True
    return (date.fromisoformat(today) - date.fromisoformat(offers[-1])).days >= (
        RECOVERY_OFFER_SPACING_DAYS
    )


def add_message(
    state: State, kind: str, copy_key: str, params: dict[str, Any]
) -> tuple[State, str]:
    message_id = f"m{len(state['coach_messages']) + 1}"
    message = {
        "id": message_id,
        "date": state["current_date"],
        "kind": kind,
        "copy_key": copy_key,
        "params": params,
        "decision_id": last_decision_id(state),
    }
    return {**state, "coach_messages": [*state["coach_messages"], message]}, message_id


def score_today(state: State) -> tuple[State, list[Event]]:
    """Run the radar for the current day, then open an episode and offer help when it is needed."""
    previous = state["risk_results"][-1]["level"] if state["risk_results"] else None
    working, result = _score(_with_todays_steps(state))
    events: list[Event] = []
    if result["level"] != previous:
        events.append({"type": "risk_changed", "level": result["level"]})

    if (
        result["level"] in LAPSE_LEVELS
        and _open_episode(working) is None
        and not _engaged_recently(working)
    ):
        episode = {
            "id": f"e{len(working['lapse_episodes']) + 1}",
            "opened_on": working["current_date"],
            "level_at_open": result["level"],
            "barrier": None,
            "closed_on": None,
            "time_to_recovery_days": None,
        }
        working = {**working, "lapse_episodes": [*working["lapse_episodes"], episode]}
        events.append({"type": "episode_opened", "episode_id": episode["id"]})
        if _offer_allowed(working, working["current_date"]):
            working, message_id = add_message(
                working, "recovery_offer", "coach.recovery_offer", {"episode_id": episode["id"]}
            )
            events.append({"type": "coach_message", "message_id": message_id})
    return working, events


def close_open_episode(state: State) -> tuple[State, list[Event]]:
    """Close the open episode when activity resumes, and welcome the user back (no gap length)."""
    episode = _open_episode(state)
    if episode is None:
        return state, []
    today = state["current_date"]
    closed = {
        **episode,
        "closed_on": today,
        "time_to_recovery_days": (
            date.fromisoformat(today) - date.fromisoformat(episode["opened_on"])
        ).days,
    }
    episodes = [closed if e is episode else e for e in state["lapse_episodes"]]
    working: State = {**state, "lapse_episodes": episodes}
    working, message_id = add_message(working, "welcome_back", "coach.welcome_back", {})
    return working, [
        {"type": "episode_closed", "episode_id": closed["id"]},
        {"type": "coach_message", "message_id": message_id},
    ]
