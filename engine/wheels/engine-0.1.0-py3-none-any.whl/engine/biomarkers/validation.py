"""Validate and normalise Malaffi observations into minimal results (F21 FR-004, FR-007, FR-011).

Only catalogue codes become results. Anything else yields nothing at all (it is never stored or
logged with a value). Excluded values become ``Exclusion`` records that carry a reason only.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, InvalidOperation
from enum import StrEnum
from typing import Final

from engine.biomarkers.catalog import (
    BIOMARKER_CATALOG,
    BODY_MEASURES,
    BP_PANEL_LOINC,
    BiomarkerCode,
    code_for_loinc,
    is_plausible,
    meets_safety_boundary,
    to_standard_unit,
)
from engine.biomarkers.windows import FOLLOW_UP_WINDOWS, MeasurementWindow, WindowType

OBSERVATION_RESOURCE: Final = "Observation"


class ExclusionReason(StrEnum):
    UNKNOWN_UNIT = "unknown_unit"
    IMPLAUSIBLE_VALUE = "implausible_value"
    BODY_MEASURES_OPTED_OUT = "body_measures_opted_out"
    OUT_OF_WINDOW = "out_of_window"
    BEFORE_CONSENT = "before_consent"


@dataclass(frozen=True, slots=True)
class BiomarkerResult:
    window_type: WindowType
    biomarker: BiomarkerCode
    value: Decimal
    unit: str
    original_value: Decimal
    original_unit: str
    result_date: date
    source_resource_id: str
    safety_flag: bool


@dataclass(frozen=True, slots=True)
class Exclusion:
    biomarker: BiomarkerCode
    window_type: WindowType
    reason: ExclusionReason
    source_resource_id: str


@dataclass(frozen=True, slots=True)
class _Reading:
    code: BiomarkerCode
    raw_value: object
    unit: str


def _readings(observation: Mapping[str, object]) -> tuple[_Reading, ...]:
    if observation.get("resourceType") != OBSERVATION_RESOURCE:
        return ()
    loinc = str(observation.get("code", ""))
    if loinc == BP_PANEL_LOINC:
        components = observation.get("components", ())
        parts = components if isinstance(components, list | tuple) else ()
        return tuple(r for part in parts if isinstance(part, Mapping) for r in _readings_of(part))
    return _readings_of(observation)


def _readings_of(source: Mapping[str, object]) -> tuple[_Reading, ...]:
    code = code_for_loinc(str(source.get("code", "")))
    if code is None:
        return ()
    return (_Reading(code, source.get("value"), str(source.get("unit", ""))),)


def _parse_decimal(raw: object) -> Decimal | None:
    try:
        parsed = Decimal(str(raw))
    except InvalidOperation:
        return None
    return parsed if parsed.is_finite() else None


def _parse_date(raw: object) -> date | None:
    try:
        return date.fromisoformat(str(raw)[:10])
    except ValueError:
        return None


@dataclass(frozen=True, slots=True)
class _Context:
    window: MeasurementWindow
    body_measures_excluded: bool
    consented_at: date | None
    result_date: date | None
    resource_id: str


def _exclusion_reason(reading: _Reading, ctx: _Context) -> ExclusionReason | None:
    if ctx.body_measures_excluded and reading.code in BODY_MEASURES:
        return ExclusionReason.BODY_MEASURES_OPTED_OUT
    if ctx.result_date is None or not ctx.window.contains(ctx.result_date):
        return ExclusionReason.OUT_OF_WINDOW
    if (
        ctx.window.window_type in FOLLOW_UP_WINDOWS
        and ctx.consented_at is not None
        and ctx.result_date < ctx.consented_at
    ):
        return ExclusionReason.BEFORE_CONSENT
    return None


def _evaluate(reading: _Reading, ctx: _Context) -> BiomarkerResult | Exclusion:
    def excluded(reason: ExclusionReason) -> Exclusion:
        return Exclusion(reading.code, ctx.window.window_type, reason, ctx.resource_id)

    reason = _exclusion_reason(reading, ctx)
    if reason is not None:
        return excluded(reason)
    original = _parse_decimal(reading.raw_value)
    if original is None:
        return excluded(ExclusionReason.IMPLAUSIBLE_VALUE)
    standard = to_standard_unit(reading.code, original, reading.unit)
    if standard is None:
        return excluded(ExclusionReason.UNKNOWN_UNIT)
    if not is_plausible(reading.code, standard):
        return excluded(ExclusionReason.IMPLAUSIBLE_VALUE)
    assert ctx.result_date is not None  # guaranteed by _exclusion_reason
    return BiomarkerResult(
        window_type=ctx.window.window_type,
        biomarker=reading.code,
        value=standard,
        unit=BIOMARKER_CATALOG[reading.code].standard_unit,
        original_value=original,
        original_unit=reading.unit,
        result_date=ctx.result_date,
        source_resource_id=ctx.resource_id,
        safety_flag=meets_safety_boundary(reading.code, standard),
    )


def validate_and_normalise(
    observation: Mapping[str, object],
    window: MeasurementWindow,
    *,
    body_measures_excluded: bool,
    consented_at: date | None,
) -> tuple[BiomarkerResult | Exclusion, ...]:
    """Validate one observation for one window; a BP panel yields two outcomes."""
    ctx = _Context(
        window=window,
        body_measures_excluded=body_measures_excluded,
        consented_at=consented_at,
        result_date=_parse_date(observation.get("effectiveDate")),
        resource_id=str(observation.get("id", "")),
    )
    return tuple(_evaluate(reading, ctx) for reading in _readings(observation))
