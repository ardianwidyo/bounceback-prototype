"""DoH approval gate for Malaffi access (F21 FR-001, FR-003; research R2).

Retrieval from Malaffi needs an active approval **and** active consent. Reading results that are
already stored needs consent only, so a suspended approval stops new retrieval without hiding a
participant's own results.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from typing import Final, Literal, get_args

from engine.biomarkers.catalog import BiomarkerCode

ApprovalStatusLiteral = Literal["active", "suspended", "expired"]
REQUIRED_DATA_REGION: Final = "uaenorth"
_STATUSES: Final = frozenset(get_args(ApprovalStatusLiteral))


class GateReason(StrEnum):
    DOH_APPROVAL_INACTIVE = "doh_approval_inactive"
    CONSENT_REQUIRED = "consent_required"
    OUT_OF_SCOPE = "out_of_scope"


class GatePurpose(StrEnum):
    RETRIEVE = "retrieve"
    READ = "read"


@dataclass(frozen=True, slots=True)
class MalaffiApproval:
    approval_reference: str
    authority: str
    status: ApprovalStatusLiteral
    effective_from: datetime
    effective_until: datetime
    permitted_codes: tuple[BiomarkerCode, ...]
    data_region: str

    def __post_init__(self) -> None:
        if not self.approval_reference.strip():
            raise ValueError("approval_reference must not be empty")
        if self.status not in _STATUSES:
            raise ValueError(f"unknown approval status {self.status!r}")
        if self.effective_from >= self.effective_until:
            raise ValueError("effective_from must be before effective_until")
        if self.data_region != REQUIRED_DATA_REGION:
            raise ValueError("Malaffi data must stay in uaenorth")
        if not set(self.permitted_codes) <= set(BiomarkerCode):
            raise ValueError("permitted_codes must be catalogue codes")


DEFAULT_SYNTHETIC_APPROVAL: Final = MalaffiApproval(
    approval_reference="DOH-MALAFFI-SYN-0001",
    authority="Department of Health – Abu Dhabi (synthetic)",  # noqa: RUF001
    status="active",
    effective_from=datetime(2026, 1, 1, tzinfo=UTC),
    effective_until=datetime(2028, 12, 31, 23, 59, 59, tzinfo=UTC),
    permitted_codes=tuple(BiomarkerCode),
    data_region=REQUIRED_DATA_REGION,
)


@dataclass(frozen=True, slots=True)
class GateDecision:
    allowed: bool
    reason: GateReason | None


def is_active(approval: MalaffiApproval, now: datetime) -> bool:
    return (
        approval.status == "active"
        and approval.effective_from <= now <= approval.effective_until
        and approval.data_region == REQUIRED_DATA_REGION
    )


def evaluate_gate(
    approval: MalaffiApproval,
    *,
    consent_allowed: bool,
    now: datetime,
    requested_codes: Iterable[BiomarkerCode],
    purpose: GatePurpose = GatePurpose.RETRIEVE,
) -> GateDecision:
    """Decide whether access may proceed; reasons in priority approval > consent > scope."""
    if purpose is GatePurpose.READ:
        if consent_allowed:
            return GateDecision(True, None)
        return GateDecision(False, GateReason.CONSENT_REQUIRED)
    if not is_active(approval, now):
        return GateDecision(False, GateReason.DOH_APPROVAL_INACTIVE)
    if not consent_allowed:
        return GateDecision(False, GateReason.CONSENT_REQUIRED)
    if not set(requested_codes) <= set(approval.permitted_codes):
        return GateDecision(False, GateReason.OUT_OF_SCOPE)
    return GateDecision(True, None)
