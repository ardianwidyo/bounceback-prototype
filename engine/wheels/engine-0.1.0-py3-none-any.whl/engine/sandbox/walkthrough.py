"""The guided "Show me" walkthrough (spec 023 US7).

Each step runs real commands through ``apply``, so what a judge sees is the engine's own
behaviour, never a scripted result. The steps are data: the commands to run, in order.
``walkthrough.step`` counts the steps done; ``start`` does step 1 (meet Fatima) and the eight
``next`` commands do steps 2 to 9.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from engine.sandbox.checkin import active_plan
from engine.sandbox.commands import Event, Handler, apply
from engine.sandbox.state import SandboxError, State
from engine.sandbox.trail import append_entry

PERSONA_ID = "persona-fatima"
LAST_STEP = 9
POLICY_VERSION = "walkthrough-1"
QUIET_DAYS = 4  # three quiet days, then the day of the comeback check-in

CommandMaker = Callable[[State], dict[str, Any]]


def _check_in(state: State) -> dict[str, Any]:
    slot_id = active_plan(state)["items"][0]["slot_id"]
    return {"type": "check_in", "slot_id": slot_id, "status": "done"}


def _choose_barrier(state: State) -> dict[str, Any]:
    open_episodes = [e for e in state["lapse_episodes"] if e["closed_on"] is None]
    if not open_episodes:
        raise SandboxError("invalid_command")
    return {"type": "choose_barrier", "episode_id": open_episodes[-1]["id"], "barrier": "tired"}


def _accept_proposal(state: State) -> dict[str, Any]:
    pending = state["pending_proposal"]
    if pending is None:
        raise SandboxError("invalid_command")
    return {"type": "respond_proposal", "proposal_id": pending["id"], "choice": "accept"}


def _fixed(command: dict[str, Any]) -> CommandMaker:
    return lambda _state: command


# Steps 2 to 9, in the fixed order of the contract.
STEPS: tuple[tuple[CommandMaker, ...], ...] = (
    (_check_in,),
    (_fixed({"type": "advance_days", "days": 1}), _check_in),
    (_fixed({"type": "set_context", "night_shift_block": True}),),
    (_fixed({"type": "advance_days", "days": QUIET_DAYS}),),
    (_choose_barrier,),
    (_accept_proposal,),
    (_check_in,),
    (_fixed({"type": "set_context", "ramadan": True}), _accept_proposal),
)


def _start(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    if state is not None and not command.get("confirm_replace"):
        raise SandboxError("confirm_required")
    loaded = _run(
        None,
        {"type": "load_persona", "persona_id": PERSONA_ID, "locale": command.get("locale", "en")},
    )
    return {**loaded[0], "walkthrough": {"active": True, "step": 1}}, loaded[1]


def _run(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    result = apply(state, command)
    if not result["ok"]:
        raise SandboxError(result["error"]["code"])
    return result["state"], result["events"]


def _next(state: State) -> tuple[State, list[Event]]:
    step = state["walkthrough"]["step"]
    working = state
    events: list[Event] = []
    ran: list[str] = []
    for make in STEPS[step - 1]:
        command = make(working)
        working, produced = _run(working, command)
        events.extend(produced)
        ran.append(command["type"])
    done = step + 1
    recorded = append_entry(
        working,
        decision_type="choice_recorded",
        on=working["current_date"],
        policy_version=POLICY_VERSION,
        inputs_used={"step": done, "commands": ran},
        excluded_sources=[],
        candidate_set=[],
        chosen="walkthrough_step",
        propensities=[1.0],
        summary_key="trail.walkthrough_step",
    )
    return {**recorded, "walkthrough": {"active": done < LAST_STEP, "step": done}}, events


def _walkthrough(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    action = command["action"]
    if action == "start":
        return _start(state, command)
    if state is None or not state["walkthrough"]["active"]:
        raise SandboxError("invalid_command")
    if action == "exit":
        return {**state, "walkthrough": {**state["walkthrough"], "active": False}}, []
    return _next(state)


HANDLERS: dict[str, Handler] = {"walkthrough": _walkthrough}
