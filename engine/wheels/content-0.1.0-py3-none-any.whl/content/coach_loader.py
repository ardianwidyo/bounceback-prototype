"""Versioned bilingual coach message catalogues and template loader (F07, Principles II, III, V)."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Literal

import yaml

from content.copy_lint import count_words

Locale = Literal["en", "ar", "ur", "hi", "tl", "ml"]
SUPPORTED_COACH_LOCALES: tuple[Locale, ...] = ("en", "ar", "ur", "hi", "tl", "ml")

DEFAULT_MESSAGES_DIR = Path(__file__).with_name("messages")
DEFAULT_LOCALES_DIR = Path(__file__).with_name("locales")

REQUIRED_COACH_TEMPLATE_IDS: tuple[str, ...] = (
    "welcome_greeting",
    "explain_plan",
    "why_this",
    "encouragement",
    "barrier_time",
    "barrier_tired",
    "barrier_pain_or_illness",
    "barrier_low_mood",
    "barrier_travel",
    "barrier_ramadan_fasting",
    "barrier_cost",
    "barrier_family",
    "barrier_not_feeling_it",
    "barrier_other",
    "plan_mutation_refusal",
    "medical_advice_refusal",
    "biomarker_care_team_note",
    "red_flag_chest_pain",
    "red_flag_self_harm",
    "red_flag_disordered_eating",
    "red_flag_emergency_symptom",
    "red_flag_pregnancy_complication",
)


@dataclass(frozen=True, slots=True)
class CoachDisclaimerCopy:
    title: str
    body: str
    emergency_number: str
    helpline_number: str


@dataclass(frozen=True, slots=True)
class CoachQuickReplyChip:
    id: str
    label: str
    prompt: str


@dataclass(frozen=True, slots=True)
class CoachTemplateEntry:
    template_id: str
    body: str


@dataclass(frozen=True, slots=True)
class CoachMessagesCatalogue:
    locale: Locale
    welcome_banner: str
    disclaimer: CoachDisclaimerCopy
    starter_chips: tuple[CoachQuickReplyChip, ...]
    barrier_chips: tuple[CoachQuickReplyChip, ...]
    templates: Mapping[str, CoachTemplateEntry]

    def get_template(self, template_id: str) -> CoachTemplateEntry:
        return self.templates[template_id]


def _parse_chips(
    raw_chips: Any, *, field_name: str, target: Path
) -> tuple[CoachQuickReplyChip, ...]:
    if not isinstance(raw_chips, list) or not raw_chips:
        raise ValueError(f"Coach messages file {target} missing non-empty {field_name!r} list")
    chips: list[CoachQuickReplyChip] = []
    for item in raw_chips:
        if not isinstance(item, Mapping):
            raise ValueError(f"Chip entry in {field_name!r} must be a mapping in {target}")
        chip_id = str(item.get("id", "")).strip()
        label = str(item.get("label", "")).strip()
        prompt = str(item.get("prompt", "")).strip()
        if not chip_id or not label or not prompt:
            raise ValueError(f"Chip entry in {field_name!r} has empty id/label/prompt in {target}")
        chips.append(CoachQuickReplyChip(id=chip_id, label=label, prompt=prompt))
    return tuple(chips)


@lru_cache(maxsize=12)
def load_coach_messages(
    locale: Locale = "en",
    path: Path | None = None,
) -> CoachMessagesCatalogue:
    """Load and validate localized coach messages for 'en', 'ar', 'ur', 'hi', 'tl', or 'ml'."""
    if locale not in SUPPORTED_COACH_LOCALES:
        raise ValueError(
            f"Unsupported locale {locale!r}; expected one of {SUPPORTED_COACH_LOCALES}"
        )
    if path is not None:
        target = path
        data = yaml.safe_load(target.read_text(encoding="utf-8"))
    elif locale in ("en", "ar"):
        target = DEFAULT_MESSAGES_DIR / f"coach.{locale}.yaml"
        data = yaml.safe_load(target.read_text(encoding="utf-8"))
    else:
        target = DEFAULT_LOCALES_DIR / "coach_locales.yaml"
        bundle = yaml.safe_load(target.read_text(encoding="utf-8"))
        data = bundle.get(locale) if isinstance(bundle, Mapping) else None
    if not isinstance(data, Mapping):
        raise ValueError(f"Invalid coach messages YAML in {target}")

    welcome_banner = str(data.get("welcome_banner", "")).strip()
    if not welcome_banner or count_words(welcome_banner) > 30:
        raise ValueError(f"welcome_banner must be 1..30 words in {target}")

    raw_disclaimer = data.get("disclaimer")
    if not isinstance(raw_disclaimer, Mapping):
        raise ValueError(f"Missing 'disclaimer' mapping in {target}")
    disclaimer = CoachDisclaimerCopy(
        title=str(raw_disclaimer.get("title", "")).strip(),
        body=str(raw_disclaimer.get("body", "")).strip(),
        emergency_number=str(raw_disclaimer.get("emergency_number", "")).strip(),
        helpline_number=str(raw_disclaimer.get("helpline_number", "")).strip(),
    )
    if (
        not disclaimer.title
        or not disclaimer.body
        or not disclaimer.emergency_number
        or not disclaimer.helpline_number
    ):
        raise ValueError(f"Incomplete disclaimer fields in {target}")

    starter_chips = _parse_chips(
        data.get("starter_chips"), field_name="starter_chips", target=target
    )
    if not (3 <= len(starter_chips) <= 5):
        raise ValueError(f"starter_chips must have 3..5 items in {target}")

    barrier_chips = _parse_chips(
        data.get("barrier_chips"), field_name="barrier_chips", target=target
    )
    if len(barrier_chips) != 3:
        raise ValueError(f"barrier_chips must have 3 items in {target}")

    raw_templates = data.get("templates")
    if not isinstance(raw_templates, Mapping):
        raise ValueError(f"Missing 'templates' mapping in {target}")

    templates: dict[str, CoachTemplateEntry] = {}
    for template_id in REQUIRED_COACH_TEMPLATE_IDS:
        entry = raw_templates.get(template_id)
        if not isinstance(entry, Mapping):
            raise ValueError(f"Missing coach template {template_id!r} in {target}")
        body = str(entry.get("body", "")).strip()
        if not body:
            raise ValueError(f"Empty body for coach template {template_id!r} in {target}")
        words = count_words(body)
        if words > 60:
            raise ValueError(
                f"Coach template {template_id!r} in {target} has {words} words (max 60)"
            )
        templates[template_id] = CoachTemplateEntry(template_id=template_id, body=body)

    return CoachMessagesCatalogue(
        locale=locale,
        welcome_banner=welcome_banner,
        disclaimer=disclaimer,
        starter_chips=starter_chips,
        barrier_chips=barrier_chips,
        templates=templates,
    )
