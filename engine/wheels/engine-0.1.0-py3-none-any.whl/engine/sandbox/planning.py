"""Builds plan items for the sandbox from the audited ``plan_builder`` (spec 023).

``build_plan`` takes 1-2 behaviours and picks up to 3 actions, so a plan across the three areas is
built one area at a time. With one or two areas each gets 2 items; with three areas each gets 1.

The per-area seeds are kept with the plan. Rebuilding under a new context (Ramadan, a night-shift
block) with the **same seeds** picks the same actions and only changes their cues and times, so a
proposal can show a clean before -> after. Every real choice is logged in the decision trail
(Constitution III); a rebuild made only to compare is not.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from content.library import Behaviour, Library
from engine.plan_builder import CombScores, ContextInput, GoalInput, PlannedActionDraft, build_plan
from engine.sandbox.cues import fasting_window, place_times
from engine.sandbox.library import get_library
from engine.sandbox.rng import next_seed
from engine.sandbox.state import State, to_engine_work_pattern
from engine.sandbox.trail import append_entry, last_decision_id

ITEMS_PER_AREA_FEW_AREAS = 2
ITEMS_PER_AREA_MANY_AREAS = 1
ITEMS_PER_AREA_FIRST_BLOCK_DAY = 1
MANY_AREAS = 3
DEFAULT_COMB: tuple[int, int, int] = (3, 3, 3)
FASTING_RESTRICTION = "fasting_hours"


@dataclass(frozen=True)
class PlanContext:
    """The situation a plan is built for. Stored with the plan so a change can be detected."""

    ramadan: bool = False
    work_pattern: str = "regular_day"
    first_block_day: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "ramadan": self.ramadan,
            "work_pattern": self.work_pattern,
            "first_block_day": self.first_block_day,
        }

    @staticmethod
    def from_dict(raw: Mapping[str, Any]) -> PlanContext:
        return PlanContext(
            ramadan=bool(raw["ramadan"]),
            work_pattern=str(raw["work_pattern"]),
            first_block_day=bool(raw["first_block_day"]),
        )


@dataclass(frozen=True)
class Selection:
    """What ``select_items`` chose, before anything is logged."""

    items: list[dict[str, Any]]
    seeds: dict[str, int]
    audits: list[dict[str, Any]]
    policy_version: str
    state: State  # the RNG counter is advanced only when new seeds were drawn


def items_per_area(area_count: int, *, first_block_day: bool = False) -> int:
    if first_block_day:
        return ITEMS_PER_AREA_FIRST_BLOCK_DAY
    return ITEMS_PER_AREA_MANY_AREAS if area_count >= MANY_AREAS else ITEMS_PER_AREA_FEW_AREAS


def next_plan_version(state: State) -> int:
    """The version number the next plan will get."""
    versions: list[int] = [plan["version"] for plan in state["plans"]]
    return max(versions) + 1


def quiet_hours_of(state: State) -> tuple[str, str]:
    quiet = state["profile"]["quiet_hours"]
    return quiet["start"], quiet["end"]


def is_restricted(area: str, action_id: str, library: Library) -> bool:
    """Movement, and any food or drink action, must stay out of the fasting hours."""
    action = library.get(action_id)
    consumes = action is not None and FASTING_RESTRICTION in action.avoid_contexts
    return area == Behaviour.MOVEMENT.value or consumes


def item_from_draft(
    action: PlannedActionDraft,
    *,
    slot_id: str,
    library_version: str,
    decision_id: str | None = None,
    clock_time: str = "",
) -> dict[str, Any]:
    """A plan item (JSON) from an engine action draft."""
    return {
        "slot_id": slot_id,
        "action_id": action.action_id,
        "library_version": library_version,
        "area": action.behaviour.value,
        "cue_id": action.cue_id,
        "cue_en": action.cue_en,
        "cue_ar": action.cue_ar,
        "if_then_en": action.if_then_en,
        "if_then_ar": action.if_then_ar,
        "reason_en": action.reason_en,
        "reason_ar": action.reason_ar,
        "bct_codes": list(action.bct_codes),
        "level": action.level.value,
        "duration_min": action.duration_min,
        "clock_time": clock_time,
        "decision_id": decision_id,
    }


def place_items(
    items: list[dict[str, Any]], state: State, context: PlanContext
) -> list[dict[str, Any]]:
    """Give each item a display time outside quiet hours (and outside fasting hours if fasting)."""
    library = get_library()
    window = fasting_window() if context.ramadan else None
    entries = [
        (item["cue_id"], is_restricted(item["area"], item["action_id"], library)) for item in items
    ]
    times = place_times(entries, quiet_hours_of(state), window)
    return [{**item, "clock_time": time} for item, time in zip(items, times, strict=True)]


def select_items(
    state: State,
    *,
    version: int,
    context: PlanContext,
    seeds: Mapping[str, int] | None = None,
) -> Selection:
    """Choose the plan items for ``context``. Pass ``seeds`` to repeat an earlier plan's choices."""
    profile = state["profile"]
    library = get_library()
    areas = list(profile["areas"])
    per_area = items_per_area(len(areas), first_block_day=context.first_block_day)
    engine_context = ContextInput(
        work_pattern=to_engine_work_pattern(context.work_pattern),  # type: ignore[arg-type]
        barriers=tuple(profile.get("barriers", ())),
        contraindications=tuple(profile["contraindications"]),
        ramadan_mode=context.ramadan,
        locale=state["locale"],
    )
    comb = CombScores(*profile.get("comb", DEFAULT_COMB))

    working = state
    used_seeds: dict[str, int] = {}
    items: list[dict[str, Any]] = []
    audits: list[dict[str, Any]] = []
    policy_version = ""
    for area in areas:
        if seeds is not None:
            seed = seeds[area]
        else:
            seed, working = next_seed(working)
        used_seeds[area] = seed
        goals = GoalInput((Behaviour(area),), why=profile.get("why", ""))
        draft = build_plan(goals, engine_context, comb, library, seed)
        policy_version = draft.audit.policy_version
        for index, action in enumerate(draft.actions[:per_area]):
            items.append(
                item_from_draft(
                    action, slot_id=f"v{version}s{len(items) + 1}", library_version=library.version
                )
            )
            audits.append(
                {
                    "area": area,
                    "seed": seed,
                    "cue_id": action.cue_id,
                    "candidates": list(draft.audit.candidate_ids_by_slot[index]),
                    "propensity": action.propensity,
                }
            )
    return Selection(
        items=place_items(items, state, context),
        seeds=used_seeds,
        audits=audits,
        policy_version=policy_version,
        state=working,
    )


def log_selection(
    state: State, selection: Selection, context: PlanContext
) -> tuple[State, list[dict[str, Any]]]:
    """Write the trail for a selection that is really used. Returns the state and logged items."""
    library = get_library()
    profile = state["profile"]
    working = state
    logged: list[dict[str, Any]] = []
    for item, audit in zip(selection.items, selection.audits, strict=True):
        working = append_entry(
            working,
            decision_type="action_selected",
            on=working["current_date"],
            policy_version=selection.policy_version,
            inputs_used={"area": audit["area"], "cue_id": audit["cue_id"], "seed": audit["seed"]},
            excluded_sources=[],
            candidate_set=audit["candidates"],
            chosen=item["action_id"],
            propensities=[audit["propensity"]],
            summary_key="trail.action_selected",
        )
        logged.append({**item, "decision_id": last_decision_id(working)})

    comb = CombScores(*profile.get("comb", DEFAULT_COMB))
    working = append_entry(
        working,
        decision_type="plan_built",
        on=working["current_date"],
        policy_version=selection.policy_version,
        inputs_used={
            "areas": list(profile["areas"]),
            "work_pattern": context.work_pattern,
            "barriers": list(profile.get("barriers", ())),
            "comb": [comb.capability, comb.opportunity, comb.motivation],
            "ramadan_mode": context.ramadan,
            "library_version": library.version,
            "items_per_area": items_per_area(
                len(profile["areas"]), first_block_day=context.first_block_day
            ),
        },
        excluded_sources=[],
        candidate_set=sorted({c for audit in selection.audits for c in audit["candidates"]}),
        chosen=[item["action_id"] for item in logged],
        propensities=[1.0],
        summary_key="trail.plan_built",
    )
    return working, logged


def build_plan_items(
    state: State, *, version: int, context: PlanContext | None = None
) -> tuple[State, list[dict[str, Any]], dict[str, int]]:
    """Choose and log plan items. Returns the state, the items and the per-area seeds used."""
    use = context or PlanContext(work_pattern=state["profile"]["work_pattern"])
    selection = select_items(state, version=version, context=use)
    working, items = log_selection(selection.state, selection, use)
    return working, items, selection.seeds
