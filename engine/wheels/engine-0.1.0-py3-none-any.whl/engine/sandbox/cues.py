"""Display clock times for plan cues, and keeping them out of quiet hours (spec 023, T030).

The planner is cue-based ("after iftar", "before main sleep"), not clock-based. The prototype shows
an approximate time per item, derived from its cue. Iftar and suhoor times come from the engine's
prayer windows (``engine.policy.environment``), so there is a single source for the fasting day.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence

from engine.policy.environment import resolve_prayer_windows
from engine.sandbox.state import SandboxError

MINUTES_PER_DAY = 24 * 60
CITY = "abu_dhabi"
IFTAR_OFFSET_MIN = 30  # after Maghrib
SUHOOR_OFFSET_MIN = -45  # before Fajr
QUIET_HOURS_BUFFER_MIN = 30

QuietHours = tuple[str, str]

# Cues that do not depend on the prayer windows.
_FIXED_CUE_TIMES: dict[str, str] = {
    "after_waking": "07:00",
    "after_main_meal": "13:15",
    "before_main_sleep": "21:30",
    "after_shift_arrive_home": "08:30",
    "on_shift_break": "15:00",
    "when_craving_starts": "10:30",
}


def to_minutes(hhmm: str) -> int:
    """Minutes since midnight for an ``HH:MM`` string."""
    hours, minutes = hhmm.split(":")
    return int(hours) * 60 + int(minutes)


def to_hhmm(minutes: int) -> str:
    """``HH:MM`` for minutes since midnight (wraps around midnight)."""
    wrapped = minutes % MINUTES_PER_DAY
    return f"{wrapped // 60:02d}:{wrapped % 60:02d}"


def _prayer_minutes(name: str) -> int:
    windows = {window.prayer_name: window for window in resolve_prayer_windows(CITY)}
    return to_minutes(windows[name].center_time)  # type: ignore[index]


def clock_time(cue_id: str) -> str:
    """Approximate time of day for a cue. Raises ValueError for a cue the planner does not know."""
    if cue_id == "after_iftar":
        return to_hhmm(_prayer_minutes("maghrib") + IFTAR_OFFSET_MIN)
    if cue_id == "before_suhoor":
        return to_hhmm(_prayer_minutes("fajr") + SUHOOR_OFFSET_MIN)
    if cue_id in _FIXED_CUE_TIMES:
        return _FIXED_CUE_TIMES[cue_id]
    raise ValueError(f"no clock time for cue: {cue_id}")


def in_quiet_hours(hhmm: str, quiet: QuietHours) -> bool:
    """True when ``hhmm`` is inside ``[start, end)``; the window may cross midnight."""
    time, start, end = to_minutes(hhmm), to_minutes(quiet[0]), to_minutes(quiet[1])
    if start <= end:
        return start <= time < end
    return time >= start or time < end


def avoid_quiet_hours(hhmm: str, quiet: QuietHours) -> str:
    """``hhmm`` unchanged if allowed, else the nearest edge outside the quiet hours.

    The edges are the quiet end (later) and a short buffer before the quiet start (earlier); the
    nearer one wins and a tie goes to the later time.
    """
    if not in_quiet_hours(hhmm, quiet):
        return hhmm
    time, start, end = to_minutes(hhmm), to_minutes(quiet[0]), to_minutes(quiet[1])
    earlier = (start - QUIET_HOURS_BUFFER_MIN) % MINUTES_PER_DAY
    back_distance = (time - earlier) % MINUTES_PER_DAY
    forward_distance = (end - time) % MINUTES_PER_DAY
    return to_hhmm(earlier) if back_distance < forward_distance else to_hhmm(end)


SPREAD_STEP_MIN = 30
# Quiet hours may cover most of the day, but never so much that nothing can be planned.
MAX_QUIET_MIN = 20 * 60
Entry = tuple[str, bool]
FastingWindow = dict[str, str]


def fasting_window() -> FastingWindow:
    """The fasting hours (Fajr to Maghrib) from the engine's prayer windows."""
    windows = {window.prayer_name: window for window in resolve_prayer_windows(CITY)}
    return {"start": windows["fajr"].center_time, "end": windows["maghrib"].center_time}


def in_window(hhmm: str, window: FastingWindow) -> bool:
    """True when ``hhmm`` is inside the fasting window (Fajr included, Maghrib excluded)."""
    return to_minutes(window["start"]) <= to_minutes(hhmm) < to_minutes(window["end"])


def place_times(
    entries: Sequence[Entry], quiet: QuietHours, window: FastingWindow | None = None
) -> list[str]:
    """A distinct, allowed display time for each ``(cue_id, restricted)`` entry.

    * Nothing is ever placed inside quiet hours.
    * While fasting (a ``window`` is given), a *restricted* item (movement, or food and drink)
      is never placed inside the fasting hours: it goes after iftar instead.
    * Items that would share a moment move later in half-hour steps. Order is preserved.
    """
    used: set[str] = set()
    placed: list[str] = []

    for cue_id, restricted in entries:

        def blocked(time: str, restricted: bool = restricted) -> bool:
            return restricted and window is not None and in_window(time, window)

        candidate = avoid_quiet_hours(clock_time(cue_id), quiet)
        if blocked(candidate):
            candidate = avoid_quiet_hours(clock_time("after_iftar"), quiet)
        candidate = _first_allowed(candidate, used, quiet, blocked)
        used.add(candidate)
        placed.append(candidate)
    return placed


def _first_allowed(
    start: str, used: set[str], quiet: QuietHours, blocked: Callable[[str], bool]
) -> str:
    """The first time at or after ``start`` that is outside quiet hours and not blocked.

    A time nobody else has is preferred. If the allowed part of the day is too small for that, an
    allowed time is shared rather than ever breaking quiet hours. If no time is allowed at all,
    nothing is placed and the command is refused.
    """
    steps = MINUTES_PER_DAY // SPREAD_STEP_MIN
    times = [to_hhmm(to_minutes(start) + step * SPREAD_STEP_MIN) for step in range(steps)]
    allowed = [time for time in times if not in_quiet_hours(time, quiet) and not blocked(time)]
    if not allowed:
        raise SandboxError("invalid_command")
    return next((time for time in allowed if time not in used), allowed[0])
