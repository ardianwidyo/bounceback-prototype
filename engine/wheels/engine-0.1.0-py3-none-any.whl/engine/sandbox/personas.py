"""Synthetic personas and the seeded step series (spec 023 data-model.md § ContextDay).

Persona data lives in ``personas.yaml`` (package data, so it ships in the engine wheel and loads in
the browser). All people are fictional: first names only, no identity fields (Constitution IV).
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from importlib import resources
from random import Random
from types import MappingProxyType
from typing import Any

import yaml

from engine.sandbox.rng import derive_seed

START_DATE = "2026-11-16"
BASELINE_NOISE_LOW = 0.85
BASELINE_NOISE_HIGH = 1.15
NIGHT_SHIFT_STEP_FACTOR = 0.4  # about -60% on the first days of a night-shift block
NIGHT_SHIFT_DROP_DAYS = 3
NO_CHECKIN_STEP_FACTOR = 0.3
# Step noise uses its own derived stream so it never shifts the counter-based draws.
_STEPS_STREAM_OFFSET = 1_000_000


@dataclass(frozen=True)
class Persona:
    persona_id: str
    display_name: str
    areas: tuple[str, ...]
    work_pattern: str
    observes_ramadan: bool
    quiet_hours: tuple[str, str]
    contraindications: tuple[str, ...]
    why: str
    barriers: tuple[str, ...]
    comb: tuple[int, int, int]
    seed: int
    wearable: bool
    steps_baseline: tuple[int, ...]
    start_date: str = START_DATE

    def to_profile(self) -> dict[str, Any]:
        """The ``profile`` object of a fresh SandboxState (fresh lists, safe to mutate)."""
        return {
            "persona_id": self.persona_id,
            "display_name": self.display_name,
            "areas": list(self.areas),
            "work_pattern": self.work_pattern,
            "observes_ramadan": self.observes_ramadan,
            "quiet_hours": {"start": self.quiet_hours[0], "end": self.quiet_hours[1]},
            "contraindications": list(self.contraindications),
            "why": self.why,
            "barriers": list(self.barriers),
            "comb": list(self.comb),
        }


def _to_persona(raw: Mapping[str, Any]) -> Persona:
    quiet = raw["quiet_hours"]
    return Persona(
        persona_id=raw["persona_id"],
        display_name=raw["display_name"],
        areas=tuple(raw["areas"]),
        work_pattern=raw["work_pattern"],
        observes_ramadan=bool(raw["observes_ramadan"]),
        quiet_hours=(quiet["start"], quiet["end"]),
        contraindications=tuple(raw["contraindications"]),
        why=raw["why"],
        barriers=tuple(raw["barriers"]),
        comb=(raw["comb"][0], raw["comb"][1], raw["comb"][2]),
        seed=int(raw["seed"]),
        wearable=bool(raw["wearable"]),
        steps_baseline=tuple(int(steps) for steps in raw["steps_baseline"]),
    )


def _load() -> Mapping[str, Persona]:
    text = resources.files("engine.sandbox").joinpath("personas.yaml").read_text(encoding="utf-8")
    data = yaml.safe_load(text)
    return MappingProxyType({p["persona_id"]: _to_persona(p) for p in data["personas"]})


PERSONAS: Mapping[str, Persona] = _load()


def synthetic_steps(
    *,
    baseline: Sequence[int],
    day_index: int,
    night_shift_block_day: int | None,
    checked_in: bool,
    sensor_consent: bool,
    seed: int,
) -> int | None:
    """Deterministic synthetic step count for one simulated day, or None without sensor consent.

    Missing data is ``None`` and is never read as inactivity (spec FR-015).
    """
    if not sensor_consent:
        return None
    noise = Random(derive_seed(seed, _STEPS_STREAM_OFFSET + day_index)).uniform(
        BASELINE_NOISE_LOW, BASELINE_NOISE_HIGH
    )
    steps = baseline[day_index % len(baseline)] * noise
    if night_shift_block_day is not None and 1 <= night_shift_block_day <= NIGHT_SHIFT_DROP_DAYS:
        steps *= NIGHT_SHIFT_STEP_FACTOR
    if not checked_in:
        steps *= NO_CHECKIN_STEP_FACTOR
    return round(steps)
