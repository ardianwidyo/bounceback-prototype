"""Primary and complementary k>=20 suppression and cooperative challenge aggregation (T015)."""

from __future__ import annotations

from collections.abc import Sequence

from engine.aggregates import TeamMemberContribution, compute_team_aggregate
from engine.workplace.models import (
    MIN_WORKPLACE_K_ANONYMITY,
    WorkplaceChallengeAggregateView,
    WorkplaceCooperativeChallenge,
)

PRIVACY_NOTICE_VISIBLE_EN = (
    "Aggregated across 20 or more active participants. Individual identities, daily logs, "
    "and rankings are never visible to employers."
)
PRIVACY_NOTICE_VISIBLE_AR = (
    "بيانات مجمّعة لـ 20 مشاركاً نشطاً أو أكثر. لا تظهر الهويات الفردية أو السجلات اليومية "
    "أو الترتيب الفردي لصاحب العمل أبداً."
)

PRIVACY_NOTICE_SUPPRESSED_EN = (
    "Metrics are suppressed to protect employee privacy because fewer than 20 active "
    "participants are in this group (or complementary suppression applies)."
)
PRIVACY_NOTICE_SUPPRESSED_AR = (
    "تم إخفاء المؤشرات لحماية خصوصية الموظفين لأن عدد المشاركين النشطين في هذه المجموعة "
    "أقل من 20 مشاركاً (أو لتطبيق الإخفاء التكميلي)."
)


def apply_complementary_k_suppression(
    cell_counts: Sequence[int],
    *,
    min_k: int = MIN_WORKPLACE_K_ANONYMITY,
) -> tuple[bool, ...]:
    """Return a tuple of boolean flags indicating which cells require complementary suppression.

    Why:
    If a breakdown dimension has one or more non-empty cells with `1 <= n < min_k` whose
    combined headcount is `< min_k`, an observer who knows the parent cohort total could
    subtract the visible (`>= min_k`) cells from the total to infer the suppressed `< min_k`
    residual. Suppressing the smallest visible (`>= min_k`) cell ensures the suppressed pool
    always spans at least `min_k` individuals across at least two cells.
    """
    effective_k = max(min_k, MIN_WORKPLACE_K_ANONYMITY)
    flags = [False] * len(cell_counts)

    primary_suppressed_total = sum(n for n in cell_counts if 0 < n < effective_k)
    if primary_suppressed_total == 0 or primary_suppressed_total >= effective_k:
        return tuple(flags)

    # Find the smallest visible cell (n >= effective_k) to act as the complementary partner
    candidate_indices = [idx for idx, n in enumerate(cell_counts) if n >= effective_k]
    if not candidate_indices:
        return tuple(flags)

    smallest_visible_idx = min(candidate_indices, key=lambda idx: (cell_counts[idx], idx))
    flags[smallest_visible_idx] = True
    return tuple(flags)


def compute_challenge_aggregate(
    challenge: WorkplaceCooperativeChallenge,
    contributions: Sequence[TeamMemberContribution],
    *,
    complementary_suppression: bool = False,
    min_k: int = MIN_WORKPLACE_K_ANONYMITY,
) -> WorkplaceChallengeAggregateView:
    """Compute a cooperative challenge aggregate reusing F14 `compute_team_aggregate`."""
    effective_k = max(min_k, MIN_WORKPLACE_K_ANONYMITY)
    team_agg = compute_team_aggregate(
        challenge.team_slug,
        contributions,
        min_k=effective_k,
    )

    suppressed = team_agg.suppressed_k_anonymity or complementary_suppression
    if suppressed:
        return WorkplaceChallengeAggregateView(
            challenge_slug=challenge.challenge_slug,
            org_slug=challenge.org_slug,
            team_slug=challenge.team_slug,
            title_en=challenge.title_en,
            title_ar=challenge.title_ar,
            summary_en=challenge.summary_en,
            summary_ar=challenge.summary_ar,
            goal_metric=challenge.goal_metric,
            target_value=challenge.target_value,
            member_count=team_agg.member_count,
            min_k_threshold=effective_k,
            suppressed_k_anonymity=True,
            complementary_suppression=complementary_suppression,
            total_completed_actions=None,
            total_active_days=None,
            progress_ratio=None,
            goal_reached=None,
            individual_rankings_exposed=False,
            privacy_notice_en=PRIVACY_NOTICE_SUPPRESSED_EN,
            privacy_notice_ar=PRIVACY_NOTICE_SUPPRESSED_AR,
        )

    total_actions = int(team_agg.total_completed_actions or 0)
    total_days = int(team_agg.total_active_days or 0)
    metric_total = total_actions if challenge.goal_metric == "completed_actions" else total_days
    ratio = min(1.0, round(metric_total / float(max(1, challenge.target_value)), 4))
    reached = metric_total >= challenge.target_value

    return WorkplaceChallengeAggregateView(
        challenge_slug=challenge.challenge_slug,
        org_slug=challenge.org_slug,
        team_slug=challenge.team_slug,
        title_en=challenge.title_en,
        title_ar=challenge.title_ar,
        summary_en=challenge.summary_en,
        summary_ar=challenge.summary_ar,
        goal_metric=challenge.goal_metric,
        target_value=challenge.target_value,
        member_count=team_agg.member_count,
        min_k_threshold=effective_k,
        suppressed_k_anonymity=False,
        complementary_suppression=False,
        total_completed_actions=total_actions,
        total_active_days=total_days,
        progress_ratio=ratio,
        goal_reached=reached,
        individual_rankings_exposed=False,
        privacy_notice_en=PRIVACY_NOTICE_VISIBLE_EN,
        privacy_notice_ar=PRIVACY_NOTICE_VISIBLE_AR,
    )
