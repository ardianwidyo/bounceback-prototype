"""Pure, deterministic Blame-Free Recovery Planner engine (F06, Principles II, III, IV, VII)."""

from __future__ import annotations

from dataclasses import replace
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from content.library import Behaviour, Level, Library, MicroAction
from content.recovery_library import (
    BarrierCode,
    CueStrategy,
    RecoveryRule,
    RecoveryRulesCatalogue,
    load_recovery_messages,
    load_recovery_rules,
)
from engine.plan_builder import (
    CUE_CATALOGUE,
    ContextInput,
    CueTemplate,
    DecisionAudit,
    PlanDraft,
    PlannedActionDraft,
    _compose_if_then_ar,
    _compose_if_then_en,
    _compose_reason,
    _level_num,
    suggested_cues_for_context,
)

RECOVERY_POLICY_VERSION = "recovery-rules-v1"

Locale = Literal["en", "ar"]


class RecoveryContextInput(BaseModel):
    """Context parameters used when adapting a plan during a lapse episode."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    shift_type: str | None = None
    fasting: bool = False
    contraindications: tuple[str, ...] = ()


class BeforeAfterActionComparison(BaseModel):
    """Structured before/after comparison for a single adapted planned action slot."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    previous_action: PlannedActionDraft
    adapted_action: PlannedActionDraft
    change_kind: Literal["downshifted", "substituted_for_rest"]
    paused_behaviour: Behaviour | None = None
    summary_label: str
    change_reason_en: str = ""
    change_reason_ar: str = ""


class RecoveryPlanDraft(BaseModel):
    """Deterministic recovery plan output produced by plan_downshift."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    barrier: BarrierCode
    rule_version: str
    plan_draft: PlanDraft
    comparisons: tuple[BeforeAfterActionComparison, ...]
    paused_behaviours: tuple[Behaviour, ...] = ()
    recommends_health_professional: bool = False
    health_professional_note: str | None = None
    health_professional_note_en: str | None = None
    health_professional_note_ar: str | None = None


# F21: the step-up decision records the safety hold and the biomarker catalogue version.
BIOMARKER_HOLD_INPUTS: dict[str, str | bool] = {
    "intensity_hold": True,
    "hold_reason": "biomarker_safety_hold",
    "config_version": "bm-1",
}


class StepUpEvaluation(BaseModel):
    """Eligibility evaluation for the optional 5-check-in step-up invitation."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    eligible: bool
    completed_checkins: int
    required_checkins: int = 5
    reason: Literal[
        "eligible_after_5_checkins",
        "not_recovery_plan",
        "insufficient_checkins",
        "already_dismissed",
        "biomarker_safety_hold",
    ]
    # Inputs that changed the decision (Constitution III); F21 adds the biomarker safety hold.
    decision_inputs: dict[str, str | bool] = Field(default_factory=dict)


def _normalize_work_pattern(shift_type: str | None) -> Literal["day", "rotating", "nights"]:
    if shift_type in ("nights", "night"):
        return "nights"
    if shift_type == "rotating":
        return "rotating"
    return "day"


def _cue_by_id(cue_id: str) -> CueTemplate:
    for cue in CUE_CATALOGUE:
        if cue.id == cue_id:
            return cue
    return CUE_CATALOGUE[0]


def _select_cue_for_strategy(
    strategy: CueStrategy,
    micro: MicroAction,
    previous_action: PlannedActionDraft,
    work_pattern: Literal["day", "rotating", "nights"],
    fasting: bool,
) -> CueTemplate:
    behaviour = Behaviour(micro.behaviour)
    if strategy == CueStrategy.AFTER_IFTAR or (fasting and "fasting_hours" in micro.avoid_contexts):
        return _cue_by_id("after_iftar")
    if strategy in (CueStrategy.POST_SHIFT_OR_ANCHORS, CueStrategy.POST_SHIFT_OR_REST):
        if work_pattern in ("nights", "rotating"):
            if behaviour == Behaviour.SLEEP and strategy == CueStrategy.POST_SHIFT_OR_REST:
                return _cue_by_id("before_main_sleep")
            return _cue_by_id("after_shift_arrive_home")
        if behaviour == Behaviour.SLEEP:
            return _cue_by_id("before_main_sleep")
        return _cue_by_id("after_shift_arrive_home")
    if strategy == CueStrategy.GENTLE_RECOVERY:
        if behaviour == Behaviour.SLEEP:
            return _cue_by_id("before_main_sleep")
        return _cue_by_id("after_main_meal")
    if strategy in (
        CueStrategy.PORTABLE_ANYTIME,
        CueStrategy.NO_COST_HOME,
        CueStrategy.FLEXIBLE_FAMILY_WINDOW,
        CueStrategy.FRESH_SMALLEST_STEP,
        CueStrategy.KEEP_OR_SOFTEN,
    ):
        if behaviour == Behaviour.SLEEP:
            return _cue_by_id("before_main_sleep")
        if behaviour == Behaviour.SMOKING_CESSATION:
            return _cue_by_id("when_craving_starts")
        if work_pattern in ("nights", "rotating"):
            return _cue_by_id("after_shift_arrive_home")
        return _cue_by_id(previous_action.cue_id)
    return _cue_by_id(previous_action.cue_id)


def _select_recovery_micro_action(
    *,
    previous_action: PlannedActionDraft,
    rule: RecoveryRule,
    library: Library,
    active_contra: frozenset[str],
    chosen_ids: set[str],
    fasting: bool,
    sub_idx: int,
) -> tuple[MicroAction, Literal["downshifted", "substituted_for_rest"], Behaviour | None]:
    prev_behaviour = Behaviour(previous_action.behaviour)
    paused_set = set(rule.pause_behaviours)
    is_paused = prev_behaviour in paused_set

    if is_paused and rule.substitute_behaviours:
        target_behaviour = rule.substitute_behaviours[sub_idx % len(rule.substitute_behaviours)]
        change_kind: Literal["downshifted", "substituted_for_rest"] = "substituted_for_rest"
        paused_beh: Behaviour | None = prev_behaviour
    else:
        target_behaviour = prev_behaviour
        change_kind = "downshifted"
        paused_beh = None

    prev_lvl_num = _level_num(previous_action.level)
    target_lvl_num = max(1, min(3, prev_lvl_num + rule.level_delta))
    avoid_tags = set(rule.avoid_context_tags)
    if fasting:
        avoid_tags.add("fasting_hours")

    def _matches(
        act: MicroAction,
        *,
        beh: Behaviour,
        max_lvl: int,
        require_strict_avoid: bool,
    ) -> bool:
        if Behaviour(act.behaviour) != beh:
            return False
        if _level_num(act.level) > max_lvl:
            return False
        if act.duration_min > rule.max_duration_min:
            return False
        if not set(act.contraindications).isdisjoint(active_contra):
            return False
        if is_paused and "mobility_limitation" in act.contraindications:
            return False
        return not (
            require_strict_avoid
            and avoid_tags
            and not set(act.avoid_contexts).isdisjoint(avoid_tags)
            and rule.cue_strategy != CueStrategy.AFTER_IFTAR
        )

    # 1. Try target behaviour at target level (<= 5 min)
    candidates = [
        a
        for a in library.actions
        if _matches(a, beh=target_behaviour, max_lvl=target_lvl_num, require_strict_avoid=True)
    ]
    # 2. If empty and substitute_behaviours exist, try other substitute behaviours
    if not candidates and is_paused and len(rule.substitute_behaviours) > 1:
        for alt_beh in rule.substitute_behaviours:
            candidates = [
                a
                for a in library.actions
                if _matches(a, beh=alt_beh, max_lvl=target_lvl_num, require_strict_avoid=True)
            ]
            if candidates:
                break
    # 3. Fallback without strict avoid tags
    if not candidates:
        candidates = [
            a
            for a in library.actions
            if _matches(a, beh=target_behaviour, max_lvl=target_lvl_num, require_strict_avoid=False)
        ]
    # 4. Ultimate fallback: any L1 <= max_duration_min for target_behaviour
    if not candidates:
        candidates = [
            a
            for a in library.actions
            if Behaviour(a.behaviour) == target_behaviour
            and a.duration_min <= rule.max_duration_min
        ]

    # Sort deterministically:
    # - Prefer unchosen actions
    # - If prefer_alternate_action, prefer actions != previous_action.action_id
    # - Prefer actions at target_lvl_num (L1), shorter duration, then action.id
    def _sort_key(act: MicroAction) -> tuple[int, int, int, int, str]:
        already_used = 1 if act.id in chosen_ids else 0
        same_as_prev = (
            1 if (rule.prefer_alternate_action and act.id == previous_action.action_id) else 0
        )
        lvl_diff = abs(_level_num(act.level) - target_lvl_num)
        return (already_used, same_as_prev, lvl_diff, act.duration_min, act.id)

    candidates.sort(key=_sort_key)
    return candidates[0], change_kind, paused_beh


def plan_downshift(
    plan: PlanDraft,
    barrier: BarrierCode | str,
    library: Library,
    context: RecoveryContextInput | None = None,
    *,
    rules: RecoveryRulesCatalogue | None = None,
    locale: Locale = "en",
) -> RecoveryPlanDraft:
    """Deterministically downshift or adapt a PlanDraft according to the barrier rule."""
    barrier_code = BarrierCode(barrier)
    rules_cat = rules or load_recovery_rules()
    rule = rules_cat.rules[barrier_code]
    ctx = context or RecoveryContextInput()

    messages_en = load_recovery_messages("en")
    messages_ar = load_recovery_messages("ar")
    info_en = (
        messages_en.barriers[barrier_code].info_note
        if barrier_code in messages_en.barriers
        else messages_en.smaller_plan_subtitle
    )
    info_ar = (
        messages_ar.barriers[barrier_code].info_note
        if barrier_code in messages_ar.barriers
        else messages_ar.smaller_plan_subtitle
    )

    work_pattern = _normalize_work_pattern(ctx.shift_type)
    fasting = bool(ctx.fasting or barrier_code == BarrierCode.RAMADAN_FASTING)
    active_contra = frozenset(ctx.contraindications)

    plan_ctx_input = ContextInput(
        work_pattern=work_pattern,
        barriers=("pain",) if barrier_code == BarrierCode.PAIN_OR_ILLNESS else (),
        contraindications=ctx.contraindications,
        ramadan_mode=fasting,
        locale=locale,
    )

    source_actions = list(plan.actions)
    if rule.max_actions is not None and len(source_actions) > rule.max_actions:
        source_actions = source_actions[: rule.max_actions]

    adapted_actions: list[PlannedActionDraft] = []
    comparisons: list[BeforeAfterActionComparison] = []
    chosen_ids: set[str] = set()
    candidate_ids_by_slot: list[tuple[str, ...]] = []
    paused_seen: list[Behaviour] = []

    for idx, prev_action in enumerate(source_actions):
        micro, change_kind, paused_beh = _select_recovery_micro_action(
            previous_action=prev_action,
            rule=rule,
            library=library,
            active_contra=active_contra,
            chosen_ids=chosen_ids,
            fasting=fasting,
            sub_idx=idx,
        )
        if paused_beh is not None and paused_beh not in paused_seen:
            paused_seen.append(paused_beh)

        chosen_ids.add(micro.id)
        candidate_ids_by_slot.append((micro.id,))
        cue = _select_cue_for_strategy(
            rule.cue_strategy,
            micro,
            prev_action,
            work_pattern,
            fasting,
        )

        text_en = micro.text_en.instruction
        text_ar = (
            micro.text_ar.instruction if micro.text_ar is not None else micro.text_en.instruction
        )
        reason_en, reason_ar = _compose_reason(
            Behaviour(micro.behaviour),
            Level(micro.level),
            micro.duration_min,
            plan_ctx_input,
        )

        adapted = PlannedActionDraft(
            id=prev_action.id,
            action_id=micro.id,
            behaviour=Behaviour(micro.behaviour),
            level=Level(micro.level),
            duration_min=micro.duration_min,
            cue_id=cue.id,
            cue_en=cue.text_en,
            cue_ar=cue.text_ar,
            action_text_en=text_en,
            action_text_ar=text_ar,
            if_then_en=_compose_if_then_en(cue.text_en, text_en),
            if_then_ar=_compose_if_then_ar(cue.text_ar, text_ar),
            reason_en=reason_en,
            reason_ar=reason_ar,
            bct_codes=micro.bct_codes,
            propensity=1.0,
        )
        adapted_actions.append(adapted)

        summary_label = info_ar if locale == "ar" else info_en
        comparisons.append(
            BeforeAfterActionComparison(
                previous_action=prev_action,
                adapted_action=adapted,
                change_kind=change_kind,
                paused_behaviour=paused_beh,
                summary_label=summary_label,
                change_reason_en=info_en,
                change_reason_ar=info_ar,
            )
        )

    # Also record any paused behaviours from dropped slots (if max_actions truncated)
    for prev_action in plan.actions:
        beh = Behaviour(prev_action.behaviour)
        if beh in rule.pause_behaviours and beh not in paused_seen:
            paused_seen.append(beh)

    new_start_level = (
        min((a.level for a in adapted_actions), key=_level_num) if adapted_actions else Level.L1
    )
    cues_en, cues_ar = suggested_cues_for_context(plan_ctx_input)
    audit = DecisionAudit(
        policy_version=rules_cat.version,
        library_version=library.version,
        seed=0,
        start_level=new_start_level,
        excluded_action_ids=(),
        candidate_ids_by_slot=tuple(candidate_ids_by_slot),
        chosen_action_ids=tuple(a.action_id for a in adapted_actions),
        propensities=tuple(1.0 for _ in adapted_actions),
        inputs_summary={
            "barrier": barrier_code.value,
            "shift_type": work_pattern,
            "fasting": fasting,
            "contraindications": list(ctx.contraindications),
            "paused_behaviours": [b.value for b in paused_seen],
        },
    )
    adapted_plan = PlanDraft(
        start_level=new_start_level,
        library_version=library.version,
        actions=tuple(adapted_actions),
        suggested_cues_en=cues_en,
        suggested_cues_ar=cues_ar,
        audit=audit,
    )

    hp_note_en = (
        messages_en.health_professional_note if rule.recommends_health_professional else None
    )
    hp_note_ar = (
        messages_ar.health_professional_note if rule.recommends_health_professional else None
    )
    hp_note = hp_note_ar if locale == "ar" else hp_note_en

    return RecoveryPlanDraft(
        barrier=barrier_code,
        rule_version=rules_cat.version,
        plan_draft=adapted_plan,
        comparisons=tuple(comparisons),
        paused_behaviours=tuple(paused_seen),
        recommends_health_professional=rule.recommends_health_professional,
        health_professional_note=hp_note,
        health_professional_note_en=hp_note_en,
        health_professional_note_ar=hp_note_ar,
    )


def evaluate_step_up_eligibility(
    *,
    plan_created_by: str,
    completed_checkins_since_version: int,
    step_up_dismissed: bool = False,
    required_checkins: int = 5,
    plan_source: str | None = None,
    intensity_hold: bool = False,
) -> StepUpEvaluation:
    """Return whether a user on a recovery plan is eligible for an optional step-up invitation.

    ``intensity_hold`` (F21 FR-011) is true while a stored biomarker meets the clinical safety
    boundary; the invitation is then withheld and the hold is recorded as a decision input.
    """
    if intensity_hold:
        return StepUpEvaluation(
            eligible=False,
            completed_checkins=completed_checkins_since_version,
            required_checkins=required_checkins,
            reason="biomarker_safety_hold",
            decision_inputs=dict(BIOMARKER_HOLD_INPUTS),
        )
    inputs: dict[str, str | bool] = {"intensity_hold": False}
    if plan_created_by != "recovery" or plan_source == "recovery_step_up":
        return StepUpEvaluation(
            eligible=False,
            completed_checkins=completed_checkins_since_version,
            required_checkins=required_checkins,
            reason="not_recovery_plan",
            decision_inputs=inputs,
        )
    if step_up_dismissed:
        return StepUpEvaluation(
            eligible=False,
            completed_checkins=completed_checkins_since_version,
            required_checkins=required_checkins,
            reason="already_dismissed",
            decision_inputs=inputs,
        )
    if completed_checkins_since_version < required_checkins:
        return StepUpEvaluation(
            eligible=False,
            completed_checkins=completed_checkins_since_version,
            required_checkins=required_checkins,
            reason="insufficient_checkins",
            decision_inputs=inputs,
        )
    return StepUpEvaluation(
        eligible=True,
        completed_checkins=completed_checkins_since_version,
        required_checkins=required_checkins,
        reason="eligible_after_5_checkins",
        decision_inputs=inputs,
    )


def plan_step_up(
    current_plan: PlanDraft,
    previous_plan: PlanDraft | None,
    library: Library,
    *,
    locale: Locale = "en",
) -> PlanDraft:
    """Produce a stepped-up PlanDraft when the user accepts the optional step-up invitation."""
    if previous_plan is not None and len(previous_plan.actions) > 0:
        audit = DecisionAudit(
            policy_version=RECOVERY_POLICY_VERSION,
            library_version=library.version,
            seed=0,
            start_level=previous_plan.start_level,
            excluded_action_ids=(),
            candidate_ids_by_slot=tuple((a.action_id,) for a in previous_plan.actions),
            chosen_action_ids=tuple(a.action_id for a in previous_plan.actions),
            propensities=tuple(1.0 for _ in previous_plan.actions),
            inputs_summary={"step_up_mode": "restore_previous_plan", "locale": locale},
        )
        return replace(previous_plan, audit=audit)

    # Otherwise step up each action by +1 tier (capped at L3)
    stepped_actions: list[PlannedActionDraft] = []
    chosen_ids: set[str] = set()
    ctx_input = ContextInput(work_pattern="day", locale=locale)

    for prev in current_plan.actions:
        target_lvl_num = min(3, _level_num(prev.level) + 1)
        target_lvl = Level(f"L{target_lvl_num}")
        candidates = [
            a
            for a in library.actions
            if Behaviour(a.behaviour) == prev.behaviour
            and _level_num(a.level) == target_lvl_num
            and a.id not in chosen_ids
        ]
        if not candidates:
            candidates = [
                a
                for a in library.actions
                if Behaviour(a.behaviour) == prev.behaviour
                and _level_num(a.level) <= target_lvl_num
            ]
        candidates.sort(key=lambda a: (abs(_level_num(a.level) - target_lvl_num), a.id))
        micro = candidates[0]
        chosen_ids.add(micro.id)
        cue = _cue_by_id(prev.cue_id)
        text_en = micro.text_en.instruction
        text_ar = (
            micro.text_ar.instruction if micro.text_ar is not None else micro.text_en.instruction
        )
        reason_en, reason_ar = _compose_reason(
            Behaviour(micro.behaviour),
            Level(micro.level),
            micro.duration_min,
            ctx_input,
        )
        stepped_actions.append(
            PlannedActionDraft(
                id=prev.id,
                action_id=micro.id,
                behaviour=Behaviour(micro.behaviour),
                level=Level(micro.level),
                duration_min=micro.duration_min,
                cue_id=cue.id,
                cue_en=cue.text_en,
                cue_ar=cue.text_ar,
                action_text_en=text_en,
                action_text_ar=text_ar,
                if_then_en=_compose_if_then_en(cue.text_en, text_en),
                if_then_ar=_compose_if_then_ar(cue.text_ar, text_ar),
                reason_en=reason_en,
                reason_ar=reason_ar,
                bct_codes=micro.bct_codes,
                propensity=1.0,
            )
        )

    new_start_level = (
        max((a.level for a in stepped_actions), key=_level_num) if stepped_actions else target_lvl
    )
    audit = DecisionAudit(
        policy_version=RECOVERY_POLICY_VERSION,
        library_version=library.version,
        seed=0,
        start_level=new_start_level,
        excluded_action_ids=(),
        candidate_ids_by_slot=tuple((a.action_id,) for a in stepped_actions),
        chosen_action_ids=tuple(a.action_id for a in stepped_actions),
        propensities=tuple(1.0 for _ in stepped_actions),
        inputs_summary={"step_up_mode": "increment_tier", "locale": locale},
    )
    return replace(
        current_plan,
        start_level=new_start_level,
        actions=tuple(stepped_actions),
        audit=audit,
    )


__all__ = [
    "RECOVERY_POLICY_VERSION",
    "BeforeAfterActionComparison",
    "RecoveryContextInput",
    "RecoveryPlanDraft",
    "StepUpEvaluation",
    "evaluate_step_up_eligibility",
    "plan_downshift",
    "plan_step_up",
]
