"""The smaller recovery plan: barrier choice, quiet 48 h offer, re-adapting (spec 023 US4).

The plan comes from the audited ``engine.recovery.plan_downshift`` (barrier rules, 2-5 minute
actions, before -> after reasons in English and Arabic). This module only converts between the
sandbox's plan items and that function's drafts, and records the offer. Nothing here applies a
plan: the user must accept it (Constitution II and III).
"""

from __future__ import annotations

from datetime import date
from typing import Any

from content.library import Behaviour, Level, Library
from content.recovery_library import USER_SELECTABLE_BARRIERS
from engine.plan_builder import DecisionAudit, PlanDraft, PlannedActionDraft
from engine.recovery import RecoveryContextInput, plan_downshift
from engine.sandbox.checkin import active_plan
from engine.sandbox.commands import Event, Handler
from engine.sandbox.library import get_library
from engine.sandbox.planning import (
    PlanContext,
    item_from_draft,
    next_plan_version,
    place_items,
)
from engine.sandbox.state import SandboxError, State, to_engine_work_pattern
from engine.sandbox.trail import append_entry

NO_ANSWER = "no_answer"
NOT_NOW = "not_now"
QUIET_OFFER_AFTER_DAYS = 2  # 48 simulated hours without an answer
LAPSE_REASON = "lapse_barrier"
SELECTABLE: frozenset[str] = frozenset(code.value for code in USER_SELECTABLE_BARRIERS)

Item = dict[str, Any]


def _draft(item: Item, library: Library) -> PlannedActionDraft:
    action = library.get(item["action_id"])
    assert action is not None, item["action_id"]
    text_ar = action.text_ar if action.text_ar is not None else action.text_en
    return PlannedActionDraft(
        id=item["slot_id"],
        action_id=item["action_id"],
        behaviour=Behaviour(item["area"]),
        level=Level(item["level"]),
        duration_min=item["duration_min"],
        cue_id=item["cue_id"],
        cue_en=item["cue_en"],
        cue_ar=item["cue_ar"],
        action_text_en=action.text_en.instruction,
        action_text_ar=text_ar.instruction,
        if_then_en=item["if_then_en"],
        if_then_ar=item["if_then_ar"],
        reason_en=item["reason_en"],
        reason_ar=item["reason_ar"],
        bct_codes=tuple(item["bct_codes"]),
        propensity=1.0,
    )


def _plan_shell(items: list[Item], library: Library) -> PlanDraft:
    actions = tuple(_draft(item, library) for item in items)
    return PlanDraft(
        start_level=Level.L1,
        library_version=library.version,
        actions=actions,
        suggested_cues_en=(),
        suggested_cues_ar=(),
        audit=DecisionAudit(
            policy_version="sandbox",
            library_version=library.version,
            seed=0,
            start_level=Level.L1,
            excluded_action_ids=(),
            candidate_ids_by_slot=(),
            chosen_action_ids=tuple(a.action_id for a in actions),
            propensities=tuple(1.0 for _ in actions),
        ),
    )


def _ref(item: Item) -> dict[str, str]:
    return {
        "action_id": item["action_id"],
        "cue_id": item["cue_id"],
        "clock_time": item["clock_time"],
    }


def downshift(
    state: State, base_items: list[Item], *, barrier: str, context: PlanContext, version: int
) -> dict[str, Any]:
    """A smaller plan for ``barrier`` from ``base_items``: items, changes and any health note."""
    library = get_library()
    recovery_context = RecoveryContextInput(
        shift_type=to_engine_work_pattern(context.work_pattern),
        fasting=context.ramadan,
        contraindications=tuple(state["profile"]["contraindications"]),
    )
    result = plan_downshift(
        _plan_shell(base_items, library),
        barrier,
        library,
        recovery_context,
        locale=state["locale"],
    )
    items = [
        item_from_draft(action, slot_id=f"v{version}s{n}", library_version=library.version)
        for n, action in enumerate(result.plan_draft.actions, start=1)
    ]
    items = place_items(items, state, context)

    by_slot = {item["slot_id"]: item for item in base_items}
    changes: list[dict[str, Any]] = []
    last_detail: dict[str, str] = {"en": "", "ar": ""}
    handled: set[str] = set()
    for comparison, after in zip(result.comparisons, items, strict=False):
        before = by_slot[comparison.previous_action.id]
        handled.add(before["slot_id"])
        last_detail = {"en": comparison.change_reason_en, "ar": comparison.change_reason_ar}
        changes.append(
            {
                "kind": "downshifted" if comparison.change_kind == "downshifted" else "swapped",
                "area": after["area"],
                "before": _ref(before),
                "after": _ref(after),
                "reason_code": LAPSE_REASON,
                "detail": last_detail,
            }
        )
    for before in base_items:
        if before["slot_id"] not in handled:
            changes.append(
                {
                    "kind": "removed",
                    "area": before["area"],
                    "before": _ref(before),
                    "after": None,
                    "reason_code": LAPSE_REASON,
                    "detail": last_detail,
                }
            )
    note = None
    if result.health_professional_note_en:
        note = {
            "en": result.health_professional_note_en,
            "ar": result.health_professional_note_ar or result.health_professional_note_en,
        }
    return {
        "items": items,
        "changes": changes,
        "health_professional_note": note,
        "rule_version": result.rule_version,
    }


def _proposal(
    state: State, plan: dict[str, Any], built: dict[str, Any], *, barrier: str, quiet: bool
) -> dict[str, Any]:
    return {
        "id": None,
        "trigger": "lapse",
        "created_on": state["current_date"],
        "before_version": plan["version"],
        "after_items": built["items"],
        "changes": built["changes"],
        "decision_id": None,
        "status": "pending",
        "barrier": barrier,
        "quiet": quiet,
        "health_professional_note": built["health_professional_note"],
        "context": dict(plan["context"]),
        "seeds": dict(plan["seeds"]),
        "rule_version": built["rule_version"],
    }


def _with_episode(state: State, episode: dict[str, Any], **changes: Any) -> State:
    updated = {**episode, **changes}
    episodes = [updated if e["id"] == episode["id"] else e for e in state["lapse_episodes"]]
    return {**state, "lapse_episodes": episodes}


def _propose(
    state: State, episode: dict[str, Any], *, barrier: str, quiet: bool
) -> tuple[State, list[Event]]:
    # Imported here: proposals imports this module, so a top-level import would be circular.
    from engine.sandbox.proposals import register_proposal

    plan = active_plan(state)
    built = downshift(
        state,
        plan["items"],
        barrier=barrier,
        context=PlanContext.from_dict(plan["context"]),
        version=next_plan_version(state),
    )
    proposal = _proposal(state, plan, built, barrier=barrier, quiet=quiet)
    return register_proposal(
        state,
        proposal,
        inputs={
            "barrier": barrier,
            "rule_version": built["rule_version"],
            "episode_id": episode["id"],
            "quiet": quiet,
        },
    )


def _choose_barrier(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    assert state is not None  # the command schema requires a state
    episode = next(
        (
            e
            for e in state["lapse_episodes"]
            if e["id"] == command["episode_id"] and e["closed_on"] is None
        ),
        None,
    )
    barrier = command["barrier"]
    if episode is None or (barrier != NOT_NOW and barrier not in SELECTABLE):
        raise SandboxError("invalid_command")

    working = _with_episode(state, episode, barrier=barrier)
    if barrier == NOT_NOW:
        working = append_entry(
            working,
            decision_type="choice_recorded",
            on=state["current_date"],
            policy_version="recovery-flow-1",
            inputs_used={"episode_id": episode["id"]},
            excluded_sources=[],
            candidate_set=[*sorted(SELECTABLE), NOT_NOW],
            chosen=NOT_NOW,
            propensities=[1.0],
            summary_key="trail.barrier_not_now",
        )
        return working, []
    return _propose(working, episode, barrier=barrier, quiet=False)


def offer_quiet_downshift(state: State) -> tuple[State, list[Event]]:
    """After 48 simulated hours with no answer, offer one smaller plan quietly, once per episode.

    No message is sent: the offer waits for the user as a pending proposal (FR-007).
    """
    episode = next((e for e in reversed(state["lapse_episodes"]) if e["closed_on"] is None), None)
    if (
        episode is None
        or episode["barrier"] is not None
        or episode.get("quiet_offered")
        or state["pending_proposal"] is not None
    ):
        return state, []
    waited = (
        date.fromisoformat(state["current_date"]) - date.fromisoformat(episode["opened_on"])
    ).days
    if waited < QUIET_OFFER_AFTER_DAYS:
        return state, []
    return _propose(
        _with_episode(state, episode, quiet_offered=True), episode, barrier=NO_ANSWER, quiet=True
    )


def readapt_recovery(state: State, target: PlanContext, trigger: str) -> dict[str, Any] | None:
    """Re-run the smaller plan for a new context, from the plan it was made from.

    Used when Ramadan or a shift change starts while a recovery plan is active, so the plan stays
    small and only its cues and times adapt. The changes compare the plan in use with the new one.
    """
    # Imported here: schedule_adapt imports planning, and this keeps the module graph one-way.
    from engine.sandbox.schedule_adapt import diff_items

    plan = active_plan(state)
    parent = next(p for p in state["plans"] if p["version"] == plan["parent_version"])
    barrier = plan.get("barrier") or NO_ANSWER
    built = downshift(
        state, parent["items"], barrier=barrier, context=target, version=next_plan_version(state)
    )
    after_items, changes = diff_items(
        state["profile"]["areas"], plan["items"], built["items"], trigger
    )
    if not changes:
        return None
    proposal = _proposal(
        state,
        plan,
        {**built, "items": after_items, "changes": changes},
        barrier=barrier,
        quiet=False,
    )
    proposal["trigger"] = trigger
    proposal["context"] = target.to_dict()
    return proposal


HANDLERS: dict[str, Handler] = {"choose_barrier": _choose_barrier}

__all__ = ["HANDLERS", "offer_quiet_downshift", "readapt_recovery"]
