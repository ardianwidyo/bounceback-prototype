"""Pure, deterministic engine for F20 Sahatna & Health Age Integration (`020-sahatna-health-age`).

Provides:
- Department of Health (DoH) Abu Dhabi Data-Sharing Agreement gate (`DohDataSharingAgreement`)
- Canonical LOINC & DoH FHIR R4 Observation mapping (`SAHATNA_FHIR_OBSERVATION_MAPPING`)
- Opaque HMAC-SHA256 signed referral token generation & verification (`30-minute` TTL, single-use)
- SMART on FHIR `uaenorth` issuer validation & URL clinical parameter sanitizer
- Synthetic Sahatna FHIR R4 bundle builder & LOINC Observation bundle validator
- Deterministic Goal & Plan Tailoring (`L1`-`L3` with safety caps) & Longitudinal Change calculator
- Bilingual (`en` & `ar` RTL) encouraging, non-alarming Blame-Free Copy helpers
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any, Literal
from urllib.parse import parse_qsl, urlsplit
from uuid import UUID, uuid5

DohAgreementStatusLiteral = Literal["active", "suspended", "expired"]
ReferralSourceChannelLiteral = Literal["sahatna_app", "screening_visit", "smart_on_fhir_launch"]
GoalDomainLiteral = Literal["movement", "nutrition", "sleep", "smoking"]
AssessmentStageLiteral = Literal["baseline", "followup_3m", "followup_6m", "followup_12m"]
SmokingStatusLiteral = Literal["current", "former", "never"]
StartLevelLiteral = Literal["L1", "L2", "L3"]
BiomarkerShiftDirectionLiteral = Literal["improved", "stable", "gentle_focus"]
SyntheticSahatnaPersonaLiteral = Literal[
    "fatima_baseline", "fatima_followup_6m", "smoker_screening", "high_bp_caution"
]

SAHATNA_POLICY_VERSION = "sahatna-health-age-v1"
REFERRAL_TOKEN_TTL_SECONDS = 1800  # 30 minutes
FHIR_STORE_SERVICE_NAME = "azure_health_data_services_fhir_r4"
FHIR_STORE_REGION = "uaenorth"
DEFAULT_FHIR_ENDPOINT_URL = "https://ws-bounceback-uaenorth-fhir.fhir.azurehealthcareapis.com"
SAHATNA_CODE_SYSTEM = "https://sahatna.doh.gov.ae/fhir/CodeSystem/observation-codes"
LOINC_CODE_SYSTEM = "http://loinc.org"
SNAPSHOT_UUID_NAMESPACE = UUID("8b7d4c12-6e1a-4b88-9312-901a22334455")

FORBIDDEN_CLINICAL_URL_PARAMS: frozenset[str] = frozenset(
    {
        "health_age",
        "healthage",
        "chronological_age",
        "bp",
        "blood_pressure",
        "systolic",
        "diastolic",
        "bmi",
        "hba1c",
        "a1c",
        "cholesterol",
        "lipids",
        "glucose",
        "smoking_status",
        "loinc",
        "observation",
        "diagnosis",
        "condition",
        "emirates_id",
        "emiratesid",
        "mrn",
        "patient_id",
        "patient_name",
        "dob",
        "birth_date",
    }
)

FORBIDDEN_BLAME_AND_ALARM_TERMS: tuple[str, ...] = (
    "you failed",
    "failure",
    "lazy",
    "guilt",
    "shame",
    "streak",
    "don't break the chain",
    "aging fast",
    "danger",
    "critical warning",
    "high disease risk",
    "!",
)

NON_DIAGNOSTIC_DISCLAIMER_EN = (
    "Health Age and screening summaries are for everyday wellness guidance only "
    "and are not a medical diagnosis or treatment plan."
)
NON_DIAGNOSTIC_DISCLAIMER_AR = (
    "ملخص العمر الصحي ونتائج الفحص مخصص لإرشادات العافية اليومية فقط "
    "وليس تشخيصاً طبياً أو خطة علاجية."
)

WELCOME_REFERRAL_EN = (
    "Welcome from Sahatna. Your visit token is verified with zero clinical data "
    "in the link. Whenever you are ready, you can choose whether to connect your "
    "Health Age summary to shape small 2 to 10 minute daily habits."
)
WELCOME_REFERRAL_AR = (
    "مرحباً بك من صحتنا. تم التحقق من رمز الإحالة دون أي بيانات سريرية في الرابط. "
    "عندما تكون مستعداً، يمكنك اختيار ما إذا كنت ترغب في ربط ملخص العمر الصحي "
    "لتصميم عادات يومية صغيرة مدتها من 2 إلى 10 دقائق."
)

CONSENT_GRANTED_MESSAGE_EN = (
    "Your Sahatna Health Age consent is active. You can pause or withdraw this "
    "permission at any time from your Autonomy Center."
)
CONSENT_GRANTED_MESSAGE_AR = (
    "موافقة العمر الصحي من صحتنا نشطة الآن. يمكنك إيقاف هذا الإذن أو سحبه "
    "في أي وقت من مركز الاستقلالية."
)

CONSENT_WITHDRAWN_MESSAGE_EN = (
    "Your Sahatna Health Age permission has been withdrawn and stored screening "
    "snapshots have been removed. Your active habit plan and cumulative active "
    "days remain intact."
)
CONSENT_WITHDRAWN_MESSAGE_AR = (
    "تم سحب إذن العمر الصحي من صحتنا وحذف لقطات الفحص المخزنة فوراً. "
    "تبقى خطة عاداتك النشطة وإجمالي أيامك النشطة محفوظة بالكامل."
)

UNCONSENTED_HEADLINE_EN = "Connect Sahatna Health Age whenever you feel ready"
UNCONSENTED_HEADLINE_AR = "اربط العمر الصحي من صحتنا متى شعرت بالاستعداد"
UNCONSENTED_BODY_EN = (
    "With your permission under the Department of Health Abu Dhabi agreement, "
    "BounceBack can use your Health Age and screening summary to suggest gentle "
    "2 to 10 minute habits and track positive shifts over time."
)
UNCONSENTED_BODY_AR = (
    "بموافقتك وضمن اتفاقية دائرة الصحة في أبوظبي، يمكن لـ BounceBack استخدام "
    "ملخص العمر الصحي والفحص لاقتراح عادات لطيفة مدتها من 2 إلى 10 دقائق "
    "ومتابعة التغيرات الإيجابية بمرور الوقت."
)


class SahatnaIntegrationError(ValueError):
    """Base exception for F20 Sahatna & Health Age integration errors."""


class DohAgreementInactiveError(SahatnaIntegrationError):
    """Raised when the DoH Abu Dhabi Data-Sharing Agreement is suspended, expired, or invalid."""


class ClinicalDataInUrlForbiddenError(SahatnaIntegrationError):
    """Raised when a referral deep link or URL contains clinical metrics or PII."""


class ReferralTokenInvalidError(SahatnaIntegrationError):
    """Raised when an opaque Sahatna referral token is malformed or fails HMAC verification."""


class ReferralTokenExpiredError(SahatnaIntegrationError):
    """Raised when an opaque Sahatna referral token is past its 30-minute expiration window."""


class FhirBundleValidationError(SahatnaIntegrationError):
    """Raised when a FHIR R4 Observation bundle or SMART issuer fails validation."""


@dataclass(frozen=True)
class FhirObservationMappingSpec:
    """Canonical LOINC / DoH FHIR R4 Observation code mapping specification."""

    metric_key: str
    code_system: str
    code: str
    display_name: str
    unit: str
    normal_range_note: str
    safety_cap_rule: str


SAHATNA_FHIR_OBSERVATION_MAPPING: tuple[FhirObservationMappingSpec, ...] = (
    FhirObservationMappingSpec(
        metric_key="health_age",
        code_system=SAHATNA_CODE_SYSTEM,
        code="doh-sahatna-health-age",
        display_name="Sahatna Health Age",
        unit="a",
        normal_range_note="At or below chronological age in years",
        safety_cap_rule=(
            "health_age_delta >= 3 prioritises movement + sleep; "
            "health_age_delta >= 5 caps starting level at L1"
        ),
    ),
    FhirObservationMappingSpec(
        metric_key="chronological_age",
        code_system=LOINC_CODE_SYSTEM,
        code="30525-0",
        display_name="Age",
        unit="a",
        normal_range_note="18 to 110 years",
        safety_cap_rule="Baseline reference for computing health_age_delta_years",
    ),
    FhirObservationMappingSpec(
        metric_key="blood_pressure_panel",
        code_system=LOINC_CODE_SYSTEM,
        code="85354-9",
        display_name="Blood pressure panel with all children optional",
        unit="mm[Hg]",
        normal_range_note="Container for systolic (8480-6) and diastolic (8462-4)",
        safety_cap_rule="Evaluates component observations 8480-6 and 8462-4",
    ),
    FhirObservationMappingSpec(
        metric_key="systolic_bp",
        code_system=LOINC_CODE_SYSTEM,
        code="8480-6",
        display_name="Systolic blood pressure",
        unit="mm[Hg]",
        normal_range_note="< 120 mmHg",
        safety_cap_rule=(
            ">= 130 prioritises movement + sleep; >= 140 caps at L1; "
            ">= 180 advises calm clinician follow-up"
        ),
    ),
    FhirObservationMappingSpec(
        metric_key="diastolic_bp",
        code_system=LOINC_CODE_SYSTEM,
        code="8462-4",
        display_name="Diastolic blood pressure",
        unit="mm[Hg]",
        normal_range_note="< 80 mmHg",
        safety_cap_rule=(
            ">= 85 prioritises movement + sleep; >= 90 caps at L1; "
            ">= 120 advises calm clinician follow-up"
        ),
    ),
    FhirObservationMappingSpec(
        metric_key="bmi",
        code_system=LOINC_CODE_SYSTEM,
        code="39156-5",
        display_name="Body mass index (BMI) [Ratio]",
        unit="kg/m2",
        normal_range_note="18.5 to 24.9 kg/m2",
        safety_cap_rule=">= 25.0 prioritises nutrition + movement; >= 30.0 caps at L1",
    ),
    FhirObservationMappingSpec(
        metric_key="hba1c",
        code_system=LOINC_CODE_SYSTEM,
        code="4548-4",
        display_name="Hemoglobin A1c/Hemoglobin.total in Blood",
        unit="%",
        normal_range_note="< 5.7 %",
        safety_cap_rule=(
            ">= 5.7 prioritises nutrition + movement; >= 6.5 caps at L1; "
            ">= 9.0 advises calm clinician follow-up"
        ),
    ),
    FhirObservationMappingSpec(
        metric_key="cholesterol_total",
        code_system=LOINC_CODE_SYSTEM,
        code="2093-3",
        display_name="Cholesterol [Mass/volume] in Serum or Plasma",
        unit="mg/dL",
        normal_range_note="< 200 mg/dL",
        safety_cap_rule=">= 200.0 prioritises nutrition + movement; >= 240.0 caps at L1",
    ),
    FhirObservationMappingSpec(
        metric_key="smoking_status",
        code_system=LOINC_CODE_SYSTEM,
        code="72166-2",
        display_name="Tobacco smoking status",
        unit="code",
        normal_range_note="never / former / current",
        safety_cap_rule="current prioritises smoking + movement",
    ),
)

PERMITTED_OBSERVATION_CODES: tuple[str, ...] = tuple(
    spec.code for spec in SAHATNA_FHIR_OBSERVATION_MAPPING
)


@dataclass(frozen=True)
class DohDataSharingAgreement:
    """Department of Health Abu Dhabi Data-Sharing Agreement governance record."""

    agreement_id: str
    authority: str
    status: DohAgreementStatusLiteral
    effective_from: datetime
    effective_until: datetime
    fhir_workspace_region: str
    fhir_endpoint_url: str
    smart_on_fhir_supported: bool
    permitted_observation_codes: tuple[str, ...]


DEFAULT_DOH_AGREEMENT = DohDataSharingAgreement(
    agreement_id="DOH-ADPHC-SAHATNA-2026-001",
    authority="Department of Health - Abu Dhabi (DoH / ADPHC)",
    status="active",
    effective_from=datetime(2026, 1, 1, 0, 0, 0, tzinfo=UTC),
    effective_until=datetime(2028, 12, 31, 23, 59, 59, tzinfo=UTC),
    fhir_workspace_region=FHIR_STORE_REGION,
    fhir_endpoint_url=DEFAULT_FHIR_ENDPOINT_URL,
    smart_on_fhir_supported=True,
    permitted_observation_codes=PERMITTED_OBSERVATION_CODES,
)


def build_default_doh_agreement(now: datetime | None = None) -> DohDataSharingAgreement:
    """Return the active default DoH Abu Dhabi data-sharing agreement."""
    _ = now
    return DEFAULT_DOH_AGREEMENT


def ensure_doh_agreement_active(
    agreement: DohDataSharingAgreement,
    now: datetime | None = None,
) -> None:
    """Verify that the DoH Abu Dhabi data-sharing agreement is active and in `uaenorth`."""
    if agreement.fhir_workspace_region != FHIR_STORE_REGION:
        raise DohAgreementInactiveError("FHIR workspace region must be locked to 'uaenorth'.")
    if agreement.status != "active":
        raise DohAgreementInactiveError(
            f"Department of Health data-sharing agreement is {agreement.status}."
        )
    if now is not None:
        check_now = now.astimezone(UTC)
        if check_now < agreement.effective_from or check_now > agreement.effective_until:
            raise DohAgreementInactiveError(
                "Department of Health data-sharing agreement is outside its effective window."
            )


def verify_sahatna_blame_free_copy(text: str) -> bool:
    """Verify user-facing copy has zero fear appeals, blame words, or exclamation marks."""
    lowered = text.lower()
    return all(term not in lowered for term in FORBIDDEN_BLAME_AND_ALARM_TERMS)


@dataclass(frozen=True)
class VerifiedSahatnaReferralToken:
    """Decoded and signature-verified non-clinical referral token payload."""

    referral_id: str
    source_channel: ReferralSourceChannelLiteral
    suggested_domain: GoalDomainLiteral | None
    issued_at: datetime
    expires_at: datetime
    token_digest: str


def generate_sahatna_referral_token(
    *,
    referral_id: str,
    source_channel: ReferralSourceChannelLiteral = "sahatna_app",
    suggested_domain: GoalDomainLiteral | None = "movement",
    secret_key: str,
    now: datetime,
    ttl_seconds: int = REFERRAL_TOKEN_TTL_SECONDS,
) -> str:
    """Generate an opaque HMAC-SHA256 signed referral token carrying zero clinical data."""
    if not referral_id.strip():
        raise ReferralTokenInvalidError("referral_id must not be empty.")
    issued_at = now.astimezone(UTC).replace(microsecond=0)
    expires_at = issued_at + timedelta(seconds=ttl_seconds)
    payload = {
        "rid": referral_id.strip(),
        "src": source_channel,
        "dom": suggested_domain,
        "iat": int(issued_at.timestamp()),
        "exp": int(expires_at.timestamp()),
    }
    raw_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    b64_payload = base64.urlsafe_b64encode(raw_bytes).decode("ascii").rstrip("=")
    sig = hmac.new(
        secret_key.encode("utf-8"),
        b64_payload.encode("ascii"),
        hashlib.sha256,
    ).hexdigest()
    return f"sref_{b64_payload}.{sig}"


def verify_sahatna_referral_token(
    *,
    token: str,
    secret_key: str,
    now: datetime,
) -> VerifiedSahatnaReferralToken:
    """Verify an opaque HMAC-SHA256 signed Sahatna referral token and return its metadata."""
    cleaned = token.strip()
    if not cleaned.startswith("sref_") or "." not in cleaned:
        raise ReferralTokenInvalidError("Malformed Sahatna referral token.")
    body_part = cleaned.removeprefix("sref_")
    b64_payload, _, provided_sig = body_part.partition(".")
    if not b64_payload or not provided_sig:
        raise ReferralTokenInvalidError("Malformed Sahatna referral token parts.")

    expected_sig = hmac.new(
        secret_key.encode("utf-8"),
        b64_payload.encode("ascii"),
        hashlib.sha256,
    ).hexdigest()
    if not hmac.compare_digest(expected_sig, provided_sig):
        raise ReferralTokenInvalidError("Sahatna referral token signature mismatch.")

    padding = "=" * (-len(b64_payload) % 4)
    try:
        decoded = base64.urlsafe_b64decode((b64_payload + padding).encode("ascii"))
        payload = json.loads(decoded.decode("utf-8"))
    except Exception as exc:
        raise ReferralTokenInvalidError("Invalid Sahatna referral token encoding.") from exc

    if not isinstance(payload, dict):
        raise ReferralTokenInvalidError("Referral token payload must be a JSON object.")

    # Ensure zero clinical keys were smuggled into the token payload
    for key in payload:
        if key.lower() in FORBIDDEN_CLINICAL_URL_PARAMS:
            raise ClinicalDataInUrlForbiddenError(
                f"Clinical parameter '{key}' is forbidden inside a referral token."
            )

    referral_id = str(payload.get("rid", "")).strip()
    source_channel = payload.get("src")
    suggested_domain = payload.get("dom")
    iat_ts = payload.get("iat")
    exp_ts = payload.get("exp")

    if (
        not referral_id
        or source_channel not in ("sahatna_app", "screening_visit", "smart_on_fhir_launch")
        or suggested_domain not in ("movement", "nutrition", "sleep", "smoking", None)
        or not isinstance(iat_ts, int)
        or not isinstance(exp_ts, int)
    ):
        raise ReferralTokenInvalidError("Referral token claims are invalid.")

    issued_at = datetime.fromtimestamp(iat_ts, tz=UTC)
    expires_at = datetime.fromtimestamp(exp_ts, tz=UTC)
    check_now = now.astimezone(UTC)
    if check_now > expires_at:
        raise ReferralTokenExpiredError("Sahatna referral token has expired.")

    token_digest = hashlib.sha256(cleaned.encode("utf-8")).hexdigest()
    return VerifiedSahatnaReferralToken(
        referral_id=referral_id,
        source_channel=source_channel,
        suggested_domain=suggested_domain,
        issued_at=issued_at,
        expires_at=expires_at,
        token_digest=token_digest,
    )


def validate_referral_deep_link_safety(deep_link_url: str | None) -> None:
    """Ensure a deep link URL carries zero clinical metrics or personal identifiers."""
    if deep_link_url is None or not deep_link_url.strip():
        return
    parsed = urlsplit(deep_link_url.strip())
    query_pairs = parse_qsl(parsed.query, keep_blank_values=True)
    for key, _ in query_pairs:
        norm_key = key.strip().lower().replace("-", "_")
        if norm_key in FORBIDDEN_CLINICAL_URL_PARAMS:
            raise ClinicalDataInUrlForbiddenError(
                f"Deep link URL contains forbidden clinical or personal parameter '{key}'."
            )
    lowered_path = parsed.path.lower()
    for forbidden in ("health_age=", "bp=", "hba1c=", "bmi=", "emirates_id="):
        if forbidden in lowered_path:
            raise ClinicalDataInUrlForbiddenError(
                "Deep link path contains forbidden clinical data."
            )


def validate_smart_on_fhir_issuer(smart_launch_iss: str | None) -> None:
    """Validate that a SMART on FHIR launch issuer URL points to an HTTPS uaenorth FHIR store."""
    if smart_launch_iss is None or not smart_launch_iss.strip():
        return
    cleaned = smart_launch_iss.strip()
    parsed = urlsplit(cleaned)
    if parsed.scheme != "https" or not parsed.netloc.endswith(".fhir.azurehealthcareapis.com"):
        raise FhirBundleValidationError(
            "SMART on FHIR issuer must be an HTTPS Azure Health Data Services FHIR endpoint."
        )
    if "uaenorth" not in parsed.netloc.lower():
        raise FhirBundleValidationError(
            "SMART on FHIR issuer must reside in the 'uaenorth' sovereign region."
        )


@dataclass(frozen=True)
class FhirHealthAgeSnapshot:
    """Validated FHIR R4 Health Age and screening snapshot stored in `uaenorth`."""

    snapshot_id: UUID
    user_id: UUID
    referral_id: str | None
    assessment_stage: AssessmentStageLiteral
    assessment_at: datetime
    synced_at: datetime
    storage_region: str
    fhir_store_service: str
    chronological_age_years: float
    health_age_years: float
    health_age_delta_years: float
    systolic_bp_mmhg: float | None
    diastolic_bp_mmhg: float | None
    bmi_kg_m2: float | None
    hba1c_pct: float | None
    cholesterol_total_mg_dl: float | None
    smoking_status: SmokingStatusLiteral | None
    observation_codes: tuple[str, ...]
    fhir_bundle_json: dict[str, Any]


def build_synthetic_sahatna_fhir_bundle(
    *,
    persona: SyntheticSahatnaPersonaLiteral = "fatima_baseline",
    assessment_at: datetime,
) -> dict[str, Any]:
    """Build a standards-compliant synthetic HL7 FHIR R4 Bundle of Sahatna Observations."""
    eff_iso = assessment_at.astimezone(UTC).isoformat()

    presets: dict[str, dict[str, Any]] = {
        "fatima_baseline": {
            "chronological_age": 41.0,
            "health_age": 47.0,
            "systolic_bp": 134.0,
            "diastolic_bp": 86.0,
            "bmi": 27.8,
            "hba1c": 5.9,
            "cholesterol_total": 208.0,
            "smoking_status": "never",
        },
        "fatima_followup_6m": {
            "chronological_age": 41.5,
            "health_age": 44.0,
            "systolic_bp": 124.0,
            "diastolic_bp": 80.0,
            "bmi": 26.4,
            "hba1c": 5.6,
            "cholesterol_total": 192.0,
            "smoking_status": "never",
        },
        "smoker_screening": {
            "chronological_age": 38.0,
            "health_age": 42.0,
            "systolic_bp": 126.0,
            "diastolic_bp": 82.0,
            "bmi": 24.2,
            "hba1c": 5.4,
            "cholesterol_total": 195.0,
            "smoking_status": "current",
        },
        "high_bp_caution": {
            "chronological_age": 52.0,
            "health_age": 59.0,
            "systolic_bp": 182.0,
            "diastolic_bp": 112.0,
            "bmi": 29.1,
            "hba1c": 6.2,
            "cholesterol_total": 225.0,
            "smoking_status": "former",
        },
    }
    vals = presets[persona]

    entries: list[dict[str, Any]] = [
        {
            "resource": {
                "resourceType": "Observation",
                "id": "obs-health-age",
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": SAHATNA_CODE_SYSTEM,
                            "code": "doh-sahatna-health-age",
                            "display": "Sahatna Health Age",
                        }
                    ]
                },
                "effectiveDateTime": eff_iso,
                "valueQuantity": {
                    "value": vals["health_age"],
                    "unit": "years",
                    "system": "http://unitsofmeasure.org",
                    "code": "a",
                },
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "obs-chronological-age",
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": LOINC_CODE_SYSTEM,
                            "code": "30525-0",
                            "display": "Age",
                        }
                    ]
                },
                "effectiveDateTime": eff_iso,
                "valueQuantity": {
                    "value": vals["chronological_age"],
                    "unit": "years",
                    "system": "http://unitsofmeasure.org",
                    "code": "a",
                },
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "obs-bp-panel",
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": LOINC_CODE_SYSTEM,
                            "code": "85354-9",
                            "display": "Blood pressure panel with all children optional",
                        }
                    ]
                },
                "effectiveDateTime": eff_iso,
                "component": [
                    {
                        "code": {
                            "coding": [
                                {
                                    "system": LOINC_CODE_SYSTEM,
                                    "code": "8480-6",
                                    "display": "Systolic blood pressure",
                                }
                            ]
                        },
                        "valueQuantity": {
                            "value": vals["systolic_bp"],
                            "unit": "mmHg",
                            "system": "http://unitsofmeasure.org",
                            "code": "mm[Hg]",
                        },
                    },
                    {
                        "code": {
                            "coding": [
                                {
                                    "system": LOINC_CODE_SYSTEM,
                                    "code": "8462-4",
                                    "display": "Diastolic blood pressure",
                                }
                            ]
                        },
                        "valueQuantity": {
                            "value": vals["diastolic_bp"],
                            "unit": "mmHg",
                            "system": "http://unitsofmeasure.org",
                            "code": "mm[Hg]",
                        },
                    },
                ],
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "obs-bmi",
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": LOINC_CODE_SYSTEM,
                            "code": "39156-5",
                            "display": "Body mass index (BMI) [Ratio]",
                        }
                    ]
                },
                "effectiveDateTime": eff_iso,
                "valueQuantity": {
                    "value": vals["bmi"],
                    "unit": "kg/m2",
                    "system": "http://unitsofmeasure.org",
                    "code": "kg/m2",
                },
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "obs-hba1c",
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": LOINC_CODE_SYSTEM,
                            "code": "4548-4",
                            "display": "Hemoglobin A1c/Hemoglobin.total in Blood",
                        }
                    ]
                },
                "effectiveDateTime": eff_iso,
                "valueQuantity": {
                    "value": vals["hba1c"],
                    "unit": "%",
                    "system": "http://unitsofmeasure.org",
                    "code": "%",
                },
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "obs-cholesterol",
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": LOINC_CODE_SYSTEM,
                            "code": "2093-3",
                            "display": "Cholesterol [Mass/volume] in Serum or Plasma",
                        }
                    ]
                },
                "effectiveDateTime": eff_iso,
                "valueQuantity": {
                    "value": vals["cholesterol_total"],
                    "unit": "mg/dL",
                    "system": "http://unitsofmeasure.org",
                    "code": "mg/dL",
                },
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "obs-smoking",
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": LOINC_CODE_SYSTEM,
                            "code": "72166-2",
                            "display": "Tobacco smoking status",
                        }
                    ]
                },
                "effectiveDateTime": eff_iso,
                "valueCodeableConcept": {
                    "coding": [
                        {
                            "system": SAHATNA_CODE_SYSTEM,
                            "code": vals["smoking_status"],
                            "display": f"Smoking status: {vals['smoking_status']}",
                        }
                    ],
                    "text": vals["smoking_status"],
                },
            }
        },
    ]

    return {
        "resourceType": "Bundle",
        "type": "collection",
        "meta": {
            "tag": [
                {
                    "system": "https://azure.microsoft.com/en-us/services/health-data-services/",
                    "code": FHIR_STORE_REGION,
                }
            ]
        },
        "entry": entries,
    }


def parse_and_validate_fhir_r4_health_age_bundle(
    *,
    user_id: UUID,
    fhir_bundle: Mapping[str, Any],
    assessment_stage: AssessmentStageLiteral = "baseline",
    synced_at: datetime,
    referral_id: str | None = None,
) -> FhirHealthAgeSnapshot:
    """Validate a FHIR R4 Observation Bundle and extract Sahatna Health Age & LOINC metrics."""
    if fhir_bundle.get("resourceType") != "Bundle":
        raise FhirBundleValidationError("FHIR payload must have resourceType == 'Bundle'.")

    entries = fhir_bundle.get("entry")
    if not isinstance(entries, list) or not entries:
        raise FhirBundleValidationError("FHIR R4 Bundle must contain a non-empty 'entry' list.")

    # Check regional meta tag if supplied
    meta = fhir_bundle.get("meta")
    if isinstance(meta, Mapping):
        tags = meta.get("tag", [])
        if isinstance(tags, list):
            for tag in tags:
                if isinstance(tag, Mapping):
                    tag_code = str(tag.get("code", "")).lower()
                    if tag_code and tag_code != FHIR_STORE_REGION:
                        raise FhirBundleValidationError(
                            f"FHIR bundle residency tag '{tag_code}' violates 'uaenorth' policy."
                        )

    chronological_age: float | None = None
    health_age: float | None = None
    systolic_bp: float | None = None
    diastolic_bp: float | None = None
    bmi: float | None = None
    hba1c: float | None = None
    cholesterol_total: float | None = None
    smoking_status: SmokingStatusLiteral | None = None
    assessment_at: datetime = synced_at.astimezone(UTC)
    found_codes: list[str] = []

    for item in entries:
        if not isinstance(item, Mapping):
            continue
        res = item.get("resource")
        if not isinstance(res, Mapping) or res.get("resourceType") != "Observation":
            continue

        eff_str = res.get("effectiveDateTime")
        if isinstance(eff_str, str) and eff_str.strip():
            try:
                parsed_dt = datetime.fromisoformat(eff_str.replace("Z", "+00:00"))
                assessment_at = parsed_dt.astimezone(UTC)
            except ValueError:
                pass

        code_obj = res.get("code", {})
        codings = code_obj.get("coding", []) if isinstance(code_obj, Mapping) else []
        if not isinstance(codings, list):
            continue

        for coding in codings:
            if not isinstance(coding, Mapping):
                continue
            code = str(coding.get("code", "")).strip()
            if not code:
                continue
            if code not in PERMITTED_OBSERVATION_CODES:
                raise FhirBundleValidationError(
                    f"Observation code '{code}' is not permitted by the DoH agreement."
                )
            if code not in found_codes:
                found_codes.append(code)

            val_qty = res.get("valueQuantity")
            num_val: float | None = None
            if isinstance(val_qty, Mapping) and isinstance(val_qty.get("value"), (int, float)):
                num_val = float(val_qty["value"])

            if code == "doh-sahatna-health-age" and num_val is not None:
                health_age = num_val
            elif code == "30525-0" and num_val is not None:
                chronological_age = num_val
            elif code == "8480-6" and num_val is not None:
                systolic_bp = num_val
            elif code == "8462-4" and num_val is not None:
                diastolic_bp = num_val
            elif code == "39156-5" and num_val is not None:
                bmi = num_val
            elif code == "4548-4" and num_val is not None:
                hba1c = num_val
            elif code == "2093-3" and num_val is not None:
                cholesterol_total = num_val
            elif code == "72166-2":
                vcc = res.get("valueCodeableConcept")
                raw_smoke: str | None = None
                if isinstance(vcc, Mapping):
                    vcc_codings = vcc.get("coding", [])
                    if isinstance(vcc_codings, list) and vcc_codings:
                        first_c = vcc_codings[0]
                        if isinstance(first_c, Mapping):
                            raw_smoke = str(first_c.get("code", "")).strip().lower()
                    if not raw_smoke and isinstance(vcc.get("text"), str):
                        raw_smoke = vcc["text"].strip().lower()
                elif isinstance(res.get("valueString"), str):
                    raw_smoke = str(res["valueString"]).strip().lower()
                if raw_smoke in ("current", "former", "never"):
                    smoking_status = raw_smoke  # type: ignore[assignment]

            # Handle BP panel components (85354-9)
            if code == "85354-9":
                components = res.get("component", [])
                if isinstance(components, list):
                    for comp in components:
                        if not isinstance(comp, Mapping):
                            continue
                        comp_code_obj = comp.get("code", {})
                        comp_codings = (
                            comp_code_obj.get("coding", [])
                            if isinstance(comp_code_obj, Mapping)
                            else []
                        )
                        comp_qty = comp.get("valueQuantity")
                        comp_val = (
                            float(comp_qty["value"])
                            if isinstance(comp_qty, Mapping)
                            and isinstance(comp_qty.get("value"), (int, float))
                            else None
                        )
                        if comp_val is None or not isinstance(comp_codings, list):
                            continue
                        for cc in comp_codings:
                            if not isinstance(cc, Mapping):
                                continue
                            cc_code = str(cc.get("code", "")).strip()
                            if cc_code == "8480-6":
                                systolic_bp = comp_val
                                if cc_code not in found_codes:
                                    found_codes.append(cc_code)
                            elif cc_code == "8462-4":
                                diastolic_bp = comp_val
                                if cc_code not in found_codes:
                                    found_codes.append(cc_code)

    if health_age is None or chronological_age is None:
        raise FhirBundleValidationError(
            "FHIR R4 Bundle must include both Sahatna Health Age ('doh-sahatna-health-age') "
            "and chronological age ('30525-0') observations."
        )
    if not (18.0 <= chronological_age <= 110.0) or not (18.0 <= health_age <= 120.0):
        raise FhirBundleValidationError(
            "Health Age and chronological age must be within valid adult bounds."
        )

    delta_years = round(health_age - chronological_age, 1)
    snapshot_seed = f"{user_id}:{assessment_stage}:{assessment_at.isoformat()}:{health_age}"
    snapshot_id = uuid5(SNAPSHOT_UUID_NAMESPACE, snapshot_seed)

    return FhirHealthAgeSnapshot(
        snapshot_id=snapshot_id,
        user_id=user_id,
        referral_id=referral_id,
        assessment_stage=assessment_stage,
        assessment_at=assessment_at,
        synced_at=synced_at.astimezone(UTC),
        storage_region=FHIR_STORE_REGION,
        fhir_store_service=FHIR_STORE_SERVICE_NAME,
        chronological_age_years=round(chronological_age, 1),
        health_age_years=round(health_age, 1),
        health_age_delta_years=delta_years,
        systolic_bp_mmhg=None if systolic_bp is None else round(systolic_bp, 1),
        diastolic_bp_mmhg=None if diastolic_bp is None else round(diastolic_bp, 1),
        bmi_kg_m2=None if bmi is None else round(bmi, 1),
        hba1c_pct=None if hba1c is None else round(hba1c, 1),
        cholesterol_total_mg_dl=(
            None if cholesterol_total is None else round(cholesterol_total, 1)
        ),
        smoking_status=smoking_status,
        observation_codes=tuple(found_codes),
        fhir_bundle_json=dict(fhir_bundle),
    )


@dataclass(frozen=True)
class HealthAgeGoalTailoring:
    """Deterministic Goal & Plan Tailoring output derived from a FhirHealthAgeSnapshot."""

    snapshot_id: UUID
    recommended_domains: tuple[GoalDomainLiteral, ...]
    recommended_start_level: StartLevelLiteral
    suggested_action_ids: tuple[str, ...]
    safety_caps_applied: bool
    clinician_followup_advised: bool
    rationale_codes: tuple[str, ...]
    encouraging_headline_en: str
    encouraging_headline_ar: str
    encouraging_body_en: str
    encouraging_body_ar: str
    non_diagnostic_disclaimer_en: str
    non_diagnostic_disclaimer_ar: str
    followup_prompt_en: str | None
    followup_prompt_ar: str | None


DOMAIN_DEFAULT_ACTIONS: dict[tuple[GoalDomainLiteral, StartLevelLiteral], str] = {
    ("movement", "L1"): "MOV_L1_01",
    ("movement", "L2"): "MOV_L2_01",
    ("movement", "L3"): "MOV_L3_01",
    ("nutrition", "L1"): "NUT_L1_01",
    ("nutrition", "L2"): "NUT_L2_01",
    ("nutrition", "L3"): "NUT_L3_01",
    ("sleep", "L1"): "SLP_L1_01",
    ("sleep", "L2"): "SLP_L2_01",
    ("sleep", "L3"): "SLP_L3_01",
    ("smoking", "L1"): "SMK_L1_01",
    ("smoking", "L2"): "SMK_L2_01",
    ("smoking", "L3"): "SMK_L3_01",
}


def tailor_goals_from_health_age(
    snapshot: FhirHealthAgeSnapshot,
) -> HealthAgeGoalTailoring:
    """Deterministically map Health Age and screening observations to domains and safe levels."""
    domains: list[GoalDomainLiteral] = []
    rationale_codes: list[str] = []

    if snapshot.smoking_status == "current":
        domains.extend(["smoking", "movement"])
        rationale_codes.append("smoking_cessation_priority")

    if (
        (snapshot.hba1c_pct is not None and snapshot.hba1c_pct >= 5.7)
        or (snapshot.bmi_kg_m2 is not None and snapshot.bmi_kg_m2 >= 25.0)
        or (
            snapshot.cholesterol_total_mg_dl is not None
            and snapshot.cholesterol_total_mg_dl >= 200.0
        )
    ):
        for dom in ("nutrition", "movement"):
            if dom not in domains:
                domains.append(dom)
        rationale_codes.append("metabolic_nutrition_movement_focus")

    if (
        (snapshot.systolic_bp_mmhg is not None and snapshot.systolic_bp_mmhg >= 130.0)
        or (snapshot.diastolic_bp_mmhg is not None and snapshot.diastolic_bp_mmhg >= 85.0)
        or snapshot.health_age_delta_years >= 3.0
    ):
        vital_domains: tuple[GoalDomainLiteral, GoalDomainLiteral] = ("movement", "sleep")
        for vital_dom in vital_domains:
            if vital_dom not in domains:
                domains.append(vital_dom)
        rationale_codes.append("vitality_movement_sleep_focus")

    if not domains:
        domains = ["movement", "nutrition"]
        rationale_codes.append("balanced_wellness_foundation")

    recommended_domains: tuple[GoalDomainLiteral, ...] = tuple(domains[:2])

    # Evaluate clinical red-flag / follow-up advisory thresholds
    clinician_followup_advised = bool(
        (snapshot.systolic_bp_mmhg is not None and snapshot.systolic_bp_mmhg >= 180.0)
        or (snapshot.diastolic_bp_mmhg is not None and snapshot.diastolic_bp_mmhg >= 120.0)
        or (snapshot.hba1c_pct is not None and snapshot.hba1c_pct >= 9.0)
    )

    # Evaluate L1 gentle safety cap
    safety_caps_applied = bool(
        clinician_followup_advised
        or snapshot.health_age_delta_years >= 5.0
        or (snapshot.systolic_bp_mmhg is not None and snapshot.systolic_bp_mmhg >= 140.0)
        or (snapshot.diastolic_bp_mmhg is not None and snapshot.diastolic_bp_mmhg >= 90.0)
        or (snapshot.hba1c_pct is not None and snapshot.hba1c_pct >= 6.5)
        or (snapshot.bmi_kg_m2 is not None and snapshot.bmi_kg_m2 >= 30.0)
        or (
            snapshot.cholesterol_total_mg_dl is not None
            and snapshot.cholesterol_total_mg_dl >= 240.0
        )
    )

    if safety_caps_applied:
        start_level: StartLevelLiteral = "L1"
        rationale_codes.append("gentle_l1_safety_cap")
    else:
        start_level = "L2"
        rationale_codes.append("steady_l2_starting_step")

    if clinician_followup_advised:
        rationale_codes.append("clinician_followup_recommended")

    suggested_actions = tuple(
        DOMAIN_DEFAULT_ACTIONS[(dom, start_level)] for dom in recommended_domains
    )

    if snapshot.health_age_delta_years > 0:
        headline_en = (
            f"Your Health Age is {snapshot.health_age_years:.0f} (chronological age "
            f"{snapshot.chronological_age_years:.0f}) — small daily steps can move it forward"
        )
        headline_ar = (
            f"عمرك الصحي هو {snapshot.health_age_years:.0f} عاماً (العمر الزمني "
            f"{snapshot.chronological_age_years:.0f}) — خطوات يومية صغيرة تدعم حيويتك"
        )
    else:
        headline_en = (
            f"Your Health Age is {snapshot.health_age_years:.0f} — keep nurturing your "
            "daily rhythm at your own pace"
        )
        headline_ar = (
            f"عمرك الصحي هو {snapshot.health_age_years:.0f} عاماً — واصل دعم إيقاعك "
            "اليومي بالوتيرة التي تناسبك"
        )

    body_en = (
        f"Based on your Sahatna screening, we tailored a gentle {start_level} starting "
        f"option in {', '.join(recommended_domains)} (2 to 10 minutes). You are always free "
        "to pick any focus area or pace."
    )
    body_ar = (
        f"بناءً على فحص صحتنا، صممنا نقطة بداية لطيفة عند المستوى {start_level} "
        "بخطوات مدتها من 2 إلى 10 دقائق. لك كامل الحرية في اختيار أي مجال أو وتيرة."
    )

    followup_en: str | None = None
    followup_ar: str | None = None
    if clinician_followup_advised:
        followup_en = (
            "One or more screening readings would benefit from a calm check-in with "
            "your clinician. While you connect with your care team, we keep your habit "
            "options gentle at L1."
        )
        followup_ar = (
            "تستفيد إحدى قراءات الفحص من مراجعة هادئة مع طبيبك. وأثناء تواصلك مع فريق "
            "الرعاية، نحافظ على خيارات عاداتك لطيفة ومريحة عند المستوى L1."
        )

    return HealthAgeGoalTailoring(
        snapshot_id=snapshot.snapshot_id,
        recommended_domains=recommended_domains,
        recommended_start_level=start_level,
        suggested_action_ids=suggested_actions,
        safety_caps_applied=safety_caps_applied,
        clinician_followup_advised=clinician_followup_advised,
        rationale_codes=tuple(rationale_codes),
        encouraging_headline_en=headline_en,
        encouraging_headline_ar=headline_ar,
        encouraging_body_en=body_en,
        encouraging_body_ar=body_ar,
        non_diagnostic_disclaimer_en=NON_DIAGNOSTIC_DISCLAIMER_EN,
        non_diagnostic_disclaimer_ar=NON_DIAGNOSTIC_DISCLAIMER_AR,
        followup_prompt_en=followup_en,
        followup_prompt_ar=followup_ar,
    )


@dataclass(frozen=True)
class BiomarkerShiftItem:
    """Single screening biomarker shift between baseline and latest snapshot."""

    metric_key: str
    loinc_code: str
    label_en: str
    label_ar: str
    unit: str
    baseline_value: float
    latest_value: float
    change_value: float
    direction: BiomarkerShiftDirectionLiteral


@dataclass(frozen=True)
class HealthAgeLongitudinalSummary:
    """Comparison across baseline and latest FhirHealthAgeSnapshot records over time."""

    snapshots_count: int
    baseline_snapshot_id: UUID
    latest_snapshot_id: UUID
    baseline_assessment_at: datetime
    latest_assessment_at: datetime
    baseline_health_age_years: float
    latest_health_age_years: float
    health_age_change_years: float
    baseline_delta_years: float
    latest_delta_years: float
    cumulative_active_days: int
    biomarker_shifts: tuple[BiomarkerShiftItem, ...]
    summary_en: str
    summary_ar: str


def compute_health_age_longitudinal_change(
    *,
    snapshots: Sequence[FhirHealthAgeSnapshot],
    cumulative_active_days: int,
) -> HealthAgeLongitudinalSummary | None:
    """Compute longitudinal Health Age and screening biomarker shifts across time."""
    if not snapshots:
        return None
    ordered = sorted(snapshots, key=lambda s: (s.assessment_at, s.synced_at))
    baseline = ordered[0]
    latest = ordered[-1]

    health_age_change = round(latest.health_age_years - baseline.health_age_years, 1)

    shifts: list[BiomarkerShiftItem] = []
    metric_defs: tuple[tuple[str, str, str, str, str, float | None, float | None], ...] = (
        (
            "systolic_bp",
            "8480-6",
            "Systolic blood pressure",
            "ضغط الدم الانقباضي",
            "mmHg",
            baseline.systolic_bp_mmhg,
            latest.systolic_bp_mmhg,
        ),
        (
            "diastolic_bp",
            "8462-4",
            "Diastolic blood pressure",
            "ضغط الدم الانبساطي",
            "mmHg",
            baseline.diastolic_bp_mmhg,
            latest.diastolic_bp_mmhg,
        ),
        (
            "bmi",
            "39156-5",
            "Body mass index (BMI)",
            "مؤشر كتلة الجسم",
            "kg/m2",
            baseline.bmi_kg_m2,
            latest.bmi_kg_m2,
        ),
        (
            "hba1c",
            "4548-4",
            "HbA1c",
            "السكر التراكمي HbA1c",
            "%",
            baseline.hba1c_pct,
            latest.hba1c_pct,
        ),
        (
            "cholesterol_total",
            "2093-3",
            "Total cholesterol",
            "الكوليسترول الكلي",
            "mg/dL",
            baseline.cholesterol_total_mg_dl,
            latest.cholesterol_total_mg_dl,
        ),
    )

    for key, loinc, label_en, label_ar, unit, base_val, lat_val in metric_defs:
        if base_val is None or lat_val is None:
            continue
        diff = round(lat_val - base_val, 1)
        if diff < -0.1:
            direction: BiomarkerShiftDirectionLiteral = "improved"
        elif abs(diff) <= 0.1:
            direction = "stable"
        else:
            direction = "gentle_focus"
        shifts.append(
            BiomarkerShiftItem(
                metric_key=key,
                loinc_code=loinc,
                label_en=label_en,
                label_ar=label_ar,
                unit=unit,
                baseline_value=base_val,
                latest_value=lat_val,
                change_value=diff,
                direction=direction,
            )
        )

    if len(ordered) == 1:
        summary_en = (
            f"Your baseline Sahatna Health Age of {baseline.health_age_years:.0f} is saved "
            f"alongside your {cumulative_active_days} cumulative active days. Future "
            "screenings will show how your steady steps add up over time."
        )
        summary_ar = (
            f"تم حفظ العمر الصحي الأساسي من صحتنا ({baseline.health_age_years:.0f} عاماً) "
            f"إلى جانب {cumulative_active_days} يوماً نشطاً تراكمياً. ستعرض الفحوصات القادمة "
            "كيف تتراكم خطواتك الهادئة بمرور الوقت."
        )
    elif health_age_change < 0:
        years_improved = abs(health_age_change)
        summary_en = (
            f"Over {cumulative_active_days} cumulative active days, your Sahatna Health Age "
            f"shifted from {baseline.health_age_years:.0f} to {latest.health_age_years:.0f} "
            f"({years_improved:.1f} years younger)."
        )
        summary_ar = (
            f"خلال {cumulative_active_days} يوماً نشطاً تراكمياً، تحسن العمر الصحي في صحتنا "
            f"من {baseline.health_age_years:.0f} إلى {latest.health_age_years:.0f} عاماً "
            f"(أصغر بـ {years_improved:.1f} سنة)."
        )
    else:
        summary_en = (
            f"You have built {cumulative_active_days} cumulative active days across your "
            f"Sahatna check-ins (Health Age {latest.health_age_years:.0f}). Every small "
            "2 to 10 minute action supports your long-term rhythm."
        )
        summary_ar = (
            f"لقد بنيت {cumulative_active_days} يوماً نشطاً تراكمياً عبر متابعات صحتنا "
            f"(العمر الصحي {latest.health_age_years:.0f} عاماً). كل خطوة صغيرة مدتها "
            "من 2 إلى 10 دقائق تدعم إيقاعك الصحي على المدى الطويل."
        )

    return HealthAgeLongitudinalSummary(
        snapshots_count=len(ordered),
        baseline_snapshot_id=baseline.snapshot_id,
        latest_snapshot_id=latest.snapshot_id,
        baseline_assessment_at=baseline.assessment_at,
        latest_assessment_at=latest.assessment_at,
        baseline_health_age_years=baseline.health_age_years,
        latest_health_age_years=latest.health_age_years,
        health_age_change_years=health_age_change,
        baseline_delta_years=baseline.health_age_delta_years,
        latest_delta_years=latest.health_age_delta_years,
        cumulative_active_days=cumulative_active_days,
        biomarker_shifts=tuple(shifts),
        summary_en=summary_en,
        summary_ar=summary_ar,
    )
