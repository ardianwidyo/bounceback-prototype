"""check_in and progress recomputation (spec 023, T031).

Progress only moves forward: cumulative active days never decrease, and a mark cannot be
downgraded (``skipped -> partial -> done``), so no action can take progress away (Constitution II).
"""

from __future__ import annotations

from typing import Any

from engine.milestones import (
    consistency_7d,
    earned_milestones,
    next_milestone,
)
from engine.progress import (
    ACTIVE_STATUSES,
    can_transition_checkin_status,
    has_clinical_red_flag,
)
from engine.sandbox.commands import Event, Handler
from engine.sandbox.state import SandboxError, State
from engine.sandbox.trail import append_entry

NOTE_MAX_LENGTH = 500
SAFETY_POLICY_VERSION = "safety-1"
MILESTONE_POLICY_VERSION = "milestones-1"


def active_plan(state: State) -> dict[str, Any]:
    """The plan version currently in use."""
    for plan in state["plans"]:
        if plan["active"]:
            return plan  # type: ignore[no-any-return]
    raise SandboxError("invalid_command")


def recompute_progress(state: State) -> dict[str, Any]:
    """Progress derived from the check-ins; other progress keys (milestones, ...) are kept."""
    checkins = state["checkins"]
    today = state["current_date"]
    active = [c for c in checkins if c["status"] in ACTIVE_STATUSES]
    active_dates = {c["date"] for c in active}
    plan = active_plan(state) if state["plans"] else {"items": []}
    plan_slots = {item["slot_id"] for item in plan["items"]}
    today_entries = [
        c for c in checkins if c["date"] == today and (not plan_slots or c["slot_id"] in plan_slots)
    ]
    areas = state["profile"]["areas"]
    previous = state["progress"].get("milestones", [])
    computed = {
        "consistency_7d": {
            "overall": consistency_7d(checkins, today),
            "by_area": {area: consistency_7d(checkins, today, area) for area in areas},
        },
        "milestones": earned_milestones(checkins, previous),
        "next_milestone": next_milestone(len(active_dates)),
        "cumulative_active_days": len(active_dates),
        "cumulative_by_area": {
            area: len({c["date"] for c in active if c["area"] == area})
            for area in state["profile"]["areas"]
        },
        "last_active_date": max(active_dates) if active_dates else None,
        "today": {
            "planned": len(plan["items"]),
            "done": sum(1 for c in today_entries if c["status"] == "done"),
            "partial": sum(1 for c in today_entries if c["status"] == "partial"),
            "skipped": sum(1 for c in today_entries if c["status"] == "skipped"),
        },
    }
    return {**state["progress"], **computed}


def refresh_progress(state: State) -> tuple[State, list[Event]]:
    """Recompute progress; announce and log each milestone that is newly earned.

    Used after anything that can change check-ins or the date, so a milestone is awarded exactly
    once, with a ``milestone_awarded`` trail entry and a ``milestone_earned`` event.
    """
    before = {m["id"] for m in state["progress"].get("milestones", [])}
    updated: State = {**state, "progress": recompute_progress(state)}
    events: list[Event] = []
    for milestone in updated["progress"]["milestones"]:
        if milestone["id"] in before:
            continue
        updated = append_entry(
            updated,
            decision_type="milestone_awarded",
            on=state["current_date"],
            policy_version=MILESTONE_POLICY_VERSION,
            inputs_used={
                "cumulative_active_days": updated["progress"]["cumulative_active_days"],
                "earned_on": milestone["earned_on"],
            },
            excluded_sources=[],
            candidate_set=[],
            chosen=milestone["id"],
            propensities=[1.0],
            summary_key="trail.milestone_awarded",
        )
        events.append({"type": "milestone_earned", "id": milestone["id"]})
    return updated, events


def _check_in(state: State | None, command: dict[str, Any]) -> tuple[State, list[Event]]:
    assert state is not None  # the command schema requires a state
    note = command.get("note")
    if note is not None and len(note) > NOTE_MAX_LENGTH:
        raise SandboxError("invalid_command")
    item = next(
        (i for i in active_plan(state)["items"] if i["slot_id"] == command["slot_id"]), None
    )
    if item is None:
        raise SandboxError("unknown_slot")

    today = state["current_date"]
    existing = next(
        (c for c in state["checkins"] if c["date"] == today and c["slot_id"] == item["slot_id"]),
        None,
    )
    if existing is not None and not can_transition_checkin_status(
        existing["status"], command["status"]
    ):
        return state, []  # a weaker mark never replaces a stronger one

    # A plain re-tap keeps the earlier note and effort; a new note or effort replaces them.
    kept_note = existing["note"] if existing else None
    kept_effort = existing["effort"] if existing else None
    flagged = has_clinical_red_flag(note)
    entry = {
        "id": existing["id"] if existing else f"c{len(state['checkins']) + 1}",
        "date": today,
        "slot_id": item["slot_id"],
        "action_id": item["action_id"],
        "area": item["area"],
        "status": command["status"],
        "note": note if note is not None else kept_note,
        "effort": command.get("effort", kept_effort),
        "safety_flag": flagged or bool(existing and existing["safety_flag"]),
    }
    checkins = [entry if c is existing else c for c in state["checkins"]]
    if existing is None:
        checkins.append(entry)
    updated: State = {**state, "checkins": checkins}
    events: list[Event] = [{"type": "progress_changed"}]

    if flagged:
        updated = append_entry(
            updated,
            decision_type="safety_escalation",
            on=today,
            policy_version=SAFETY_POLICY_VERSION,
            # The note itself is not copied into the trail (data minimisation).
            inputs_used={"slot_id": item["slot_id"], "reason": "red_flag_phrase"},
            excluded_sources=[],
            candidate_set=["continue", "escalate"],
            chosen="escalate",
            propensities=[1.0],
            summary_key="trail.safety_escalation",
        )
        events.append({"type": "safety_escalation", "message_key": "safety.escalation"})

    refreshed, milestone_events = refresh_progress(updated)
    # Imported here: radar uses this module's helpers, so a top-level import would be circular.
    from engine.sandbox.proposals import maybe_invite_step_up
    from engine.sandbox.radar import close_open_episode, score_today

    scored, radar_events = score_today(refreshed)
    if command["status"] in ACTIVE_STATUSES:
        scored, recovery_events = close_open_episode(scored)
        radar_events = [*radar_events, *recovery_events]
        scored, invite_events = maybe_invite_step_up(scored)
        radar_events = [*radar_events, *invite_events]
    return scored, [*events, *milestone_events, *radar_events]


HANDLERS: dict[str, Handler] = {"check_in": _check_in}
