"""Pure, deterministic Goal & Plan Builder engine (F02, Principles II, III, VII, VIII)."""

from __future__ import annotations

import random
from dataclasses import dataclass, field, replace
from decimal import ROUND_HALF_UP, Decimal
from typing import Literal

from content.library import Behaviour, Level, Library, MicroAction
from engine.sampling import select_weighted

POLICY_VERSION = "plan_builder_v1"
WHY_MAX_LENGTH = 120
CUE_MAX_LENGTH = 120

BARRIER_CONTRAINDICATION_MAP: dict[str, tuple[str, ...]] = {
    "pain": ("mobility_limitation", "cardiac_condition"),
    "heat": ("heat_exposure",),
    "shift": (),
    "time": (),
    "energy": (),
    "motivation": (),
}

BARRIER_AVOID_CONTEXT_MAP: dict[str, tuple[str, ...]] = {
    "heat": ("midday_heat",),
}


@dataclass(frozen=True, slots=True)
class GoalInput:
    behaviours: tuple[Behaviour, ...]
    why: str = ""

    def __post_init__(self) -> None:
        cleaned = tuple(Behaviour(b) for b in self.behaviours)
        if not (1 <= len(cleaned) <= 2):
            raise ValueError("behaviours must contain 1 or 2 items")
        if len(set(cleaned)) != len(cleaned):
            raise ValueError("behaviours must be unique")
        trimmed_why = self.why.strip()
        if len(trimmed_why) > WHY_MAX_LENGTH:
            raise ValueError(f"why must not exceed {WHY_MAX_LENGTH} characters")
        object.__setattr__(self, "behaviours", cleaned)
        object.__setattr__(self, "why", trimmed_why)


@dataclass(frozen=True, slots=True)
class CombScores:
    capability: int
    opportunity: int
    motivation: int

    def __post_init__(self) -> None:
        for name, value in (
            ("capability", self.capability),
            ("opportunity", self.opportunity),
            ("motivation", self.motivation),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or not (1 <= value <= 5):
                raise ValueError(f"{name} must be an integer between 1 and 5")


@dataclass(frozen=True, slots=True)
class ContextInput:
    work_pattern: Literal["day", "rotating", "nights"] = "day"
    barriers: tuple[str, ...] = ()
    contraindications: tuple[str, ...] = ()
    ramadan_mode: bool = False
    locale: Literal["en", "ar"] = "en"
    # F21 FR-011: a biomarker at the clinical safety boundary holds plan intensity at L1.
    intensity_hold: bool = False


@dataclass(frozen=True, slots=True)
class CueTemplate:
    id: str
    work_patterns: tuple[str, ...]
    behaviours: tuple[Behaviour, ...]
    ramadan_only: bool
    context_tags: tuple[str, ...]
    text_en: str
    text_ar: str


@dataclass(frozen=True, slots=True)
class PlannedActionDraft:
    id: str
    action_id: str
    behaviour: Behaviour
    level: Level
    duration_min: int
    cue_id: str
    cue_en: str
    cue_ar: str
    action_text_en: str
    action_text_ar: str
    if_then_en: str
    if_then_ar: str
    reason_en: str
    reason_ar: str
    bct_codes: tuple[str, ...]
    propensity: float


@dataclass(frozen=True, slots=True)
class DecisionAudit:
    policy_version: str
    library_version: str
    seed: int
    start_level: Level
    excluded_action_ids: tuple[str, ...]
    candidate_ids_by_slot: tuple[tuple[str, ...], ...]
    chosen_action_ids: tuple[str, ...]
    propensities: tuple[float, ...]
    inputs_summary: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class PlanDraft:
    start_level: Level
    library_version: str
    actions: tuple[PlannedActionDraft, ...]
    suggested_cues_en: tuple[str, ...]
    suggested_cues_ar: tuple[str, ...]
    audit: DecisionAudit


def active_contraindications(context: ContextInput) -> frozenset[str]:
    """Return active contraindication tags from user barriers and explicit contraindications."""
    tags: set[str] = set(context.contraindications)
    for barrier in context.barriers:
        tags.update(BARRIER_CONTRAINDICATION_MAP.get(barrier, ()))
    return frozenset(tags)


def compute_start_level(comb: CombScores) -> Level:
    """Compute conservative starting difficulty level (L1..L3, never L4/L5) from COM-B scores.

    Formula: clamp(round_half_up(mean(C, O, M)) - 1, 1, 3).
    """
    scores = (comb.capability, comb.opportunity, comb.motivation)
    for value in scores:
        if isinstance(value, bool) or not isinstance(value, int) or not (1 <= value <= 5):
            raise ValueError("COM-B scores must be integers between 1 and 5")
    mean = Decimal(sum(scores)) / Decimal(3)
    rounded = int(mean.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    clamped = max(1, min(3, rounded - 1))
    return Level(f"L{clamped}")


CUE_CATALOGUE: tuple[CueTemplate, ...] = (
    CueTemplate(
        id="after_shift_arrive_home",
        work_patterns=("rotating", "nights", "day"),
        behaviours=(Behaviour.MOVEMENT, Behaviour.SLEEP, Behaviour.NUTRITION),
        ramadan_only=False,
        context_tags=(),
        text_en="After I get home from my shift",
        text_ar="بعد عودتي إلى المنزل من مناوبتي",
    ),
    CueTemplate(
        id="on_shift_break",
        work_patterns=("rotating", "nights"),
        behaviours=(Behaviour.MOVEMENT, Behaviour.NUTRITION, Behaviour.SMOKING_CESSATION),
        ramadan_only=False,
        context_tags=(),
        text_en="On my break during a shift",
        text_ar="خلال استراحتي أثناء المناوبة",
    ),
    CueTemplate(
        id="before_main_sleep",
        work_patterns=("day", "rotating", "nights"),
        behaviours=(Behaviour.SLEEP, Behaviour.MOVEMENT),
        ramadan_only=False,
        context_tags=(),
        text_en="30 minutes before my main sleep",
        text_ar="قبل نومي الرئيسي بـ 30 دقيقة",
    ),
    CueTemplate(
        id="after_main_meal",
        work_patterns=("day", "rotating", "nights"),
        behaviours=(Behaviour.NUTRITION, Behaviour.MOVEMENT),
        ramadan_only=False,
        context_tags=("fasting_hours",),
        text_en="Right after my main meal",
        text_ar="مباشرة بعد وجبتي الرئيسية",
    ),
    CueTemplate(
        id="after_iftar",
        work_patterns=("day", "rotating", "nights"),
        behaviours=(
            Behaviour.NUTRITION,
            Behaviour.MOVEMENT,
            Behaviour.SLEEP,
            Behaviour.SMOKING_CESSATION,
        ),
        ramadan_only=True,
        context_tags=(),
        text_en="After I finish Iftar",
        text_ar="بعد الانتهاء من الإفطار",
    ),
    CueTemplate(
        id="before_suhoor",
        work_patterns=("day", "rotating", "nights"),
        behaviours=(Behaviour.NUTRITION, Behaviour.SLEEP),
        ramadan_only=True,
        context_tags=(),
        text_en="Before Suhoor ends",
        text_ar="قبل انتهاء السحور",
    ),
    CueTemplate(
        id="after_waking",
        work_patterns=("day",),
        behaviours=(Behaviour.MOVEMENT, Behaviour.NUTRITION, Behaviour.SMOKING_CESSATION),
        ramadan_only=False,
        context_tags=(),
        text_en="Within 15 minutes of waking up",
        text_ar="خلال 15 دقيقة من الاستيقاظ",
    ),
    CueTemplate(
        id="when_craving_starts",
        work_patterns=("day", "rotating", "nights"),
        behaviours=(Behaviour.SMOKING_CESSATION, Behaviour.MOVEMENT),
        ramadan_only=False,
        context_tags=(),
        text_en="When a craving starts",
        text_ar="عندما تبدأ الرغبة في التدخين",
    ),
)

_BEHAVIOUR_LABEL_EN: dict[Behaviour, str] = {
    Behaviour.MOVEMENT: "movement",
    Behaviour.NUTRITION: "nutrition",
    Behaviour.SLEEP: "sleep",
    Behaviour.SMOKING_CESSATION: "smoking cessation",
}

_BEHAVIOUR_LABEL_AR: dict[Behaviour, str] = {
    Behaviour.MOVEMENT: "الحركة",
    Behaviour.NUTRITION: "التغذية",
    Behaviour.SLEEP: "النوم",
    Behaviour.SMOKING_CESSATION: "الإقلاع عن التدخين",
}

_WORK_PATTERN_LABEL_EN: dict[str, str] = {
    "day": "daytime routine",
    "rotating": "rotating shifts",
    "nights": "night shifts",
}

_WORK_PATTERN_LABEL_AR: dict[str, str] = {
    "day": "جدولك النهاري",
    "rotating": "مناوباتك المتغيرة",
    "nights": "مناوباتك الليلية",
}


def _level_num(level: str | Level) -> int:
    return int(str(level)[1])


def _compose_if_then_en(cue_en: str, instruction_en: str) -> str:
    cleaned_cue = cue_en.strip().rstrip(",.")
    cleaned_inst = instruction_en.strip()
    return f"{cleaned_cue}, I will: {cleaned_inst}"


def _compose_if_then_ar(cue_ar: str, instruction_ar: str) -> str:
    cleaned_cue = cue_ar.strip().rstrip("،.")
    cleaned_inst = instruction_ar.strip()
    return f"{cleaned_cue}، سأقوم بـ: {cleaned_inst}"


def _compose_reason(
    behaviour: Behaviour,
    level: Level,
    duration_min: int,
    context: ContextInput,
) -> tuple[str, str]:
    b_en = _BEHAVIOUR_LABEL_EN[behaviour]
    b_ar = _BEHAVIOUR_LABEL_AR[behaviour]
    wp_en = _WORK_PATTERN_LABEL_EN.get(context.work_pattern, "routine")
    wp_ar = _WORK_PATTERN_LABEL_AR.get(context.work_pattern, "روتيني")
    lvl_num = _level_num(level)

    extras_en: list[str] = []
    extras_ar: list[str] = []
    if "heat" in context.barriers:
        extras_en.append("stays indoors out of the heat")
        extras_ar.append("يتجنب حرارة الخارج")
    if "pain" in context.barriers:
        extras_en.append("keeps movement gentle")
        extras_ar.append("يحافظ على حركة لطيفة")
    if context.ramadan_mode:
        extras_en.append("respects fasting hours")
        extras_ar.append("يراعي أوقات الصيام")

    suffix_en = f" and {' and '.join(extras_en)}" if extras_en else ""
    suffix_ar = f" و{' و'.join(extras_ar)}" if extras_ar else ""

    reason_en = (
        f"Fits your {b_en} goal and {wp_en}{suffix_en} ({duration_min} min, Level {lvl_num})."
    )
    reason_ar = f"يناسب هدف {b_ar} و{wp_ar}{suffix_ar} ({duration_min} دقائق، المستوى {lvl_num})."
    return reason_en, reason_ar


def _eligible_cues_for_action(
    micro: MicroAction,
    context: ContextInput,
) -> tuple[CueTemplate, ...]:
    behaviour = Behaviour(micro.behaviour)
    avoid_tags: set[str] = set()
    for barrier in context.barriers:
        avoid_tags.update(BARRIER_AVOID_CONTEXT_MAP.get(barrier, ()))

    requires_non_fasting = context.ramadan_mode and "fasting_hours" in micro.avoid_contexts

    candidates: list[CueTemplate] = []
    for cue in CUE_CATALOGUE:
        if context.work_pattern not in cue.work_patterns:
            continue
        if cue.ramadan_only and not context.ramadan_mode:
            continue
        if avoid_tags and not set(cue.context_tags).isdisjoint(avoid_tags):
            continue
        if requires_non_fasting and cue.id not in ("after_iftar", "before_suhoor"):
            continue
        candidates.append(cue)

    # Sort cues so behaviour-specific and work-pattern-preferred cues come first
    def _cue_priority(cue: CueTemplate) -> tuple[int, int, int]:
        if requires_non_fasting:
            ramadan_rank = 0 if cue.id in ("after_iftar", "before_suhoor") else 1
        elif context.ramadan_mode and cue.ramadan_only:
            ramadan_rank = 0
        else:
            ramadan_rank = 1

        if (
            (behaviour == Behaviour.SLEEP and cue.id == "before_main_sleep")
            or (behaviour == Behaviour.SMOKING_CESSATION and cue.id == "when_craving_starts")
            or (
                context.work_pattern in ("rotating", "nights")
                and cue.id in ("after_shift_arrive_home", "on_shift_break")
            )
        ):
            beh_rank = 0
        elif behaviour in cue.behaviours:
            beh_rank = 1
        else:
            beh_rank = 2

        return (ramadan_rank, beh_rank, CUE_CATALOGUE.index(cue))

    candidates.sort(key=_cue_priority)
    return tuple(candidates)


def _select_cue(
    micro: MicroAction,
    context: ContextInput,
    used_cue_ids: set[str],
) -> CueTemplate:
    cues = _eligible_cues_for_action(micro, context)
    for cue in cues:
        if cue.id not in used_cue_ids:
            return cue
    return cues[0]


def _to_planned_action_draft(
    slot_index: int,
    micro: MicroAction,
    cue: CueTemplate,
    propensity: float,
    context: ContextInput,
) -> PlannedActionDraft:
    behaviour = Behaviour(micro.behaviour)
    level = Level(micro.level)
    text_en = micro.text_en.instruction
    text_ar = micro.text_ar.instruction if micro.text_ar is not None else micro.text_en.instruction
    reason_en, reason_ar = _compose_reason(behaviour, level, micro.duration_min, context)
    return PlannedActionDraft(
        id=f"pa-{slot_index}",
        action_id=micro.id,
        behaviour=behaviour,
        level=level,
        duration_min=micro.duration_min,
        cue_id=cue.id,
        cue_en=cue.text_en,
        cue_ar=cue.text_ar,
        action_text_en=text_en,
        action_text_ar=text_ar,
        if_then_en=_compose_if_then_en(cue.text_en, text_en),
        if_then_ar=_compose_if_then_ar(cue.text_ar, text_ar),
        reason_en=reason_en,
        reason_ar=reason_ar,
        bct_codes=micro.bct_codes,
        propensity=round(propensity, 6),
    )


def _safe_candidates_for_behaviour(
    library: Library,
    behaviour: Behaviour,
    start_level: Level,
    active_contra: frozenset[str],
    chosen_ids: set[str],
) -> list[MicroAction]:
    max_lvl = _level_num(start_level)
    result: list[MicroAction] = []
    for action in library.actions:
        if Behaviour(action.behaviour) != behaviour:
            continue
        if action.id in chosen_ids:
            continue
        if _level_num(action.level) > max_lvl or _level_num(action.level) > 3:
            continue
        if not (2 <= action.duration_min <= 10):
            continue
        if not set(action.contraindications).isdisjoint(active_contra):
            continue
        result.append(action)
    return result


def _weights_for_candidates(candidates: list[MicroAction], start_level: Level) -> list[float]:
    target_num = _level_num(start_level)
    return [3.0 if _level_num(c.level) == target_num else 1.0 for c in candidates]


def suggested_cues_for_context(context: ContextInput) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Return bilingual suggested cue strings compatible with work pattern and Ramadan mode."""
    avoid_tags: set[str] = set()
    for barrier in context.barriers:
        avoid_tags.update(BARRIER_AVOID_CONTEXT_MAP.get(barrier, ()))

    en_list: list[str] = []
    ar_list: list[str] = []
    for cue in CUE_CATALOGUE:
        if context.work_pattern not in cue.work_patterns:
            continue
        if cue.ramadan_only and not context.ramadan_mode:
            continue
        if avoid_tags and not set(cue.context_tags).isdisjoint(avoid_tags):
            continue
        en_list.append(cue.text_en)
        ar_list.append(cue.text_ar)
    return tuple(en_list), tuple(ar_list)


def build_plan(
    goals: GoalInput,
    context: ContextInput,
    comb: CombScores,
    library: Library,
    seed: int,
) -> PlanDraft:
    """Deterministically select 2-3 micro-actions and compose shift-/Ramadan-aware
    implementation intentions ('When..., I will...') with BCT codes and plain-language reasons.
    """
    rng = random.Random(seed)
    start_level = Level.L1 if context.intensity_hold else compute_start_level(comb)
    max_lvl = _level_num(start_level)
    active_contra = active_contraindications(context)

    target_behaviours = goals.behaviours
    excluded_ids: list[str] = []
    for action in library.actions:
        if Behaviour(action.behaviour) not in target_behaviours:
            continue
        if (
            _level_num(action.level) > max_lvl
            or _level_num(action.level) > 3
            or not set(action.contraindications).isdisjoint(active_contra)
        ):
            excluded_ids.append(action.id)

    if len(target_behaviours) == 1:
        slot_behaviours = [target_behaviours[0], target_behaviours[0], target_behaviours[0]]
    else:
        slot_behaviours = [target_behaviours[0], target_behaviours[1], target_behaviours[0]]

    chosen_actions: list[PlannedActionDraft] = []
    chosen_ids: set[str] = set()
    used_cue_ids: set[str] = set()
    candidate_ids_by_slot: list[tuple[str, ...]] = []
    propensities: list[float] = []

    for preferred_behaviour in slot_behaviours:
        candidates = _safe_candidates_for_behaviour(
            library, preferred_behaviour, start_level, active_contra, chosen_ids
        )
        if not candidates and len(target_behaviours) > 1:
            fallback_behaviour = (
                target_behaviours[1]
                if preferred_behaviour == target_behaviours[0]
                else target_behaviours[0]
            )
            candidates = _safe_candidates_for_behaviour(
                library, fallback_behaviour, start_level, active_contra, chosen_ids
            )
        if not candidates:
            continue

        candidate_ids_by_slot.append(tuple(c.id for c in candidates))
        weights = _weights_for_candidates(candidates, start_level)
        selection = select_weighted(candidates, weights, rng)
        micro = selection.item
        cue = _select_cue(micro, context, used_cue_ids)
        used_cue_ids.add(cue.id)
        chosen_ids.add(micro.id)
        propensities.append(round(selection.propensity, 6))
        chosen_actions.append(
            _to_planned_action_draft(
                len(chosen_actions) + 1, micro, cue, selection.propensity, context
            )
        )

    cues_en, cues_ar = suggested_cues_for_context(context)
    audit = DecisionAudit(
        policy_version=POLICY_VERSION,
        library_version=library.version,
        seed=seed,
        start_level=start_level,
        excluded_action_ids=tuple(excluded_ids),
        candidate_ids_by_slot=tuple(candidate_ids_by_slot),
        chosen_action_ids=tuple(a.action_id for a in chosen_actions),
        propensities=tuple(propensities),
        inputs_summary={
            "behaviours": [b.value for b in goals.behaviours],
            "why": goals.why,
            "work_pattern": context.work_pattern,
            "barriers": list(context.barriers),
            "contraindications": list(context.contraindications),
            "ramadan_mode": context.ramadan_mode,
            "locale": context.locale,
            "intensity_hold": context.intensity_hold,
            "comb": {
                "capability": comb.capability,
                "opportunity": comb.opportunity,
                "motivation": comb.motivation,
            },
        },
    )
    return PlanDraft(
        start_level=start_level,
        library_version=library.version,
        actions=tuple(chosen_actions),
        suggested_cues_en=cues_en,
        suggested_cues_ar=cues_ar,
        audit=audit,
    )


def swap_action(
    current_actions: tuple[PlannedActionDraft, ...],
    target_id: str,
    context: ContextInput,
    comb: CombScores,
    library: Library,
    seed: int,
) -> tuple[tuple[PlannedActionDraft, ...], DecisionAudit]:
    """Replace `target_id` (matching PlannedActionDraft.id or action_id) with an alternative
    safe MicroAction for the same behaviour (or fallback chosen behaviour) at <= start_level,
    returning a new immutable tuple of PlannedActionDraft and a DecisionAudit record.
    """
    target_idx = -1
    for idx, item in enumerate(current_actions):
        if item.id == target_id or item.action_id == target_id:
            target_idx = idx
            break
    if target_idx == -1:
        raise KeyError(f"Action {target_id!r} not found in current_actions")

    target = current_actions[target_idx]
    rng = random.Random(seed)
    start_level = compute_start_level(comb)
    active_contra = active_contraindications(context)
    other_ids = {a.action_id for i, a in enumerate(current_actions) if i != target_idx}
    exclude_current_and_others = set(other_ids) | {target.action_id}

    # 1. Try another safe action for the same behaviour not already in the plan
    candidates = _safe_candidates_for_behaviour(
        library, target.behaviour, start_level, active_contra, exclude_current_and_others
    )
    # 2. Fallback: try another safe action for any behaviour in the plan or library
    if not candidates:
        plan_behaviours = list(dict.fromkeys(a.behaviour for a in current_actions))
        for beh in plan_behaviours + list(Behaviour):
            candidates = _safe_candidates_for_behaviour(
                library, beh, start_level, active_contra, exclude_current_and_others
            )
            if candidates:
                break
    # 3. Wrap-around fallback: if only one safe action exists, keep safe candidate
    if not candidates:
        candidates = _safe_candidates_for_behaviour(
            library, target.behaviour, start_level, active_contra, other_ids
        )
    if not candidates:
        micro_fallback = library.get(target.action_id)
        if micro_fallback is None:
            raise ValueError("No safe candidate available for swap")
        candidates = [micro_fallback]

    weights = _weights_for_candidates(candidates, start_level)
    selection = select_weighted(candidates, weights, rng)
    micro = selection.item
    used_cues = {a.cue_id for i, a in enumerate(current_actions) if i != target_idx}
    cue = _select_cue(micro, context, used_cues)
    replacement = _to_planned_action_draft(
        target_idx + 1, micro, cue, selection.propensity, context
    )
    replacement = replace(replacement, id=target.id)

    updated = list(current_actions)
    updated[target_idx] = replacement

    audit = DecisionAudit(
        policy_version=POLICY_VERSION,
        library_version=library.version,
        seed=seed,
        start_level=start_level,
        excluded_action_ids=tuple(sorted(exclude_current_and_others)),
        candidate_ids_by_slot=(tuple(c.id for c in candidates),),
        chosen_action_ids=(replacement.action_id,),
        propensities=(round(selection.propensity, 6),),
        inputs_summary={
            "operation": "swap",
            "replaced_action_id": target.action_id,
            "work_pattern": context.work_pattern,
            "barriers": list(context.barriers),
            "ramadan_mode": context.ramadan_mode,
        },
    )
    return tuple(updated), audit


def edit_action_cue(
    current_actions: tuple[PlannedActionDraft, ...],
    target_id: str,
    cue_en: str,
    cue_ar: str | None = None,
    cue_id: str = "custom",
) -> tuple[PlannedActionDraft, ...]:
    """Return a new tuple of PlannedActionDraft with the target action's cue and if-then
    sentences updated in both English and Arabic.
    """
    target_idx = -1
    for idx, item in enumerate(current_actions):
        if item.id == target_id or item.action_id == target_id:
            target_idx = idx
            break
    if target_idx == -1:
        raise KeyError(f"Action {target_id!r} not found in current_actions")

    trimmed_en = cue_en.strip()
    trimmed_ar = cue_ar.strip() if cue_ar is not None else ""

    if len(trimmed_en) > CUE_MAX_LENGTH or len(trimmed_ar) > CUE_MAX_LENGTH:
        raise ValueError(f"Cue text must not exceed {CUE_MAX_LENGTH} characters")

    # Ignore blank custom input (preserve existing cue)
    if not trimmed_en and not trimmed_ar:
        return current_actions

    target = current_actions[target_idx]
    final_en = trimmed_en or target.cue_en
    final_ar = trimmed_ar or trimmed_en or target.cue_ar

    # Resolve matching preset cue_id if it matches CUE_CATALOGUE
    resolved_cue_id = cue_id
    for template in CUE_CATALOGUE:
        if final_en == template.text_en or final_ar == template.text_ar:
            resolved_cue_id = template.id
            if not trimmed_ar:
                final_ar = template.text_ar
            if not trimmed_en:
                final_en = template.text_en
            break

    updated_item = replace(
        target,
        cue_id=resolved_cue_id,
        cue_en=final_en,
        cue_ar=final_ar,
        if_then_en=_compose_if_then_en(final_en, target.action_text_en),
        if_then_ar=_compose_if_then_ar(final_ar, target.action_text_ar),
    )
    updated = list(current_actions)
    updated[target_idx] = updated_item
    return tuple(updated)


def remove_action(
    current_actions: tuple[PlannedActionDraft, ...],
    target_id: str,
) -> tuple[PlannedActionDraft, ...]:
    """Remove the target action from `current_actions`.
    Raises `ValueError("Cannot remove the last remaining action")` if `len(current_actions) <= 1`.
    """
    if len(current_actions) <= 1:
        raise ValueError("Cannot remove the last remaining action")

    remaining = [
        item for item in current_actions if item.id != target_id and item.action_id != target_id
    ]
    if len(remaining) == len(current_actions):
        raise KeyError(f"Action {target_id!r} not found in current_actions")
    return tuple(remaining)


def _smaller_safe_candidates_for_action(
    target_action: PlannedActionDraft,
    context: ContextInput,
    library: Library,
    exclude_ids: set[str],
) -> list[MicroAction]:
    """Return safe library candidates in the same behaviour with strictly smaller
    `(level_num, duration_min)`.

    Steps down at most one difficulty level at a time (e.g. L3 -> L2, L2 -> L1) or to a
    shorter duration within the current level when no step-down level exists, ensuring
    shrinking terminates in at most 3 steps.
    """
    active_contra = active_contraindications(context)
    current_lvl = _level_num(target_action.level)
    current_dur = target_action.duration_min

    smaller: list[MicroAction] = []
    for action in library.actions:
        if Behaviour(action.behaviour) != target_action.behaviour:
            continue
        if action.id in exclude_ids or action.id == target_action.action_id:
            continue
        if not (1 <= action.duration_min <= 10):
            continue
        if not set(action.contraindications).isdisjoint(active_contra):
            continue
        cand_lvl = _level_num(action.level)
        if cand_lvl > 3:
            continue
        if (cand_lvl, action.duration_min) < (current_lvl, current_dur):
            smaller.append(action)

    if not smaller:
        return []

    # Prefer stepping down to the next lower level (or lowest level if already L1
    # with shorter duration), picking candidates at the highest available lower level
    # or shortest duration at that level so repeated shrinks terminate in <= 3 steps.
    smaller.sort(key=lambda a: (_level_num(a.level), a.duration_min))
    min_level = _level_num(smaller[0].level)
    min_dur_at_min_level = min(a.duration_min for a in smaller if _level_num(a.level) == min_level)
    # Step down one level at a time (L3 -> L2 -> L1 -> shortest L1).
    step_down_lvl = max(1, current_lvl - 1)
    level_matches = [a for a in smaller if _level_num(a.level) == step_down_lvl]
    if level_matches:
        target_dur = min(a.duration_min for a in level_matches)
        return [a for a in level_matches if a.duration_min == target_dur]
    return [
        a
        for a in smaller
        if _level_num(a.level) == min_level and a.duration_min == min_dur_at_min_level
    ]


def can_shrink_action(
    target_action: PlannedActionDraft,
    context: ContextInput,
    library: Library,
) -> bool:
    """Return True if a safe library action exists with smaller `(level_num, duration_min)`."""
    return bool(_smaller_safe_candidates_for_action(target_action, context, library, set()))


def shrink_action(
    current_actions: tuple[PlannedActionDraft, ...],
    target_id: str,
    context: ContextInput,
    library: Library,
    seed: int = 42,
) -> tuple[tuple[PlannedActionDraft, ...], DecisionAudit, bool]:
    """Step down `target_id` (matching `id` or `action_id`) to a strictly smaller safe action
    in the same behaviour.

    Returns `(updated_actions, audit, did_shrink)`. When `target_id` is already at the minimum
    safe `(level, duration_min)` floor, returns `(tuple(current_actions), audit, False)`.
    """
    target_idx = -1
    for idx, item in enumerate(current_actions):
        if item.id == target_id or item.action_id == target_id:
            target_idx = idx
            break
    if target_idx == -1:
        raise KeyError(f"Action {target_id!r} not found in current_actions")

    target = current_actions[target_idx]
    other_ids = {a.action_id for i, a in enumerate(current_actions) if i != target_idx}
    candidates = _smaller_safe_candidates_for_action(target, context, library, other_ids)
    if not candidates:
        candidates = _smaller_safe_candidates_for_action(target, context, library, set())

    if not candidates:
        audit = DecisionAudit(
            policy_version=POLICY_VERSION,
            library_version=library.version,
            seed=seed,
            start_level=target.level,
            excluded_action_ids=(target.action_id,),
            candidate_ids_by_slot=((),),
            chosen_action_ids=(target.action_id,),
            propensities=(1.0,),
            inputs_summary={
                "operation": "shrink",
                "target_action_id": target.action_id,
                "did_shrink": False,
                "work_pattern": context.work_pattern,
                "barriers": list(context.barriers),
                "ramadan_mode": context.ramadan_mode,
            },
        )
        return tuple(current_actions), audit, False

    rng = random.Random(seed)
    weights = [1.0 for _ in candidates]
    selection = select_weighted(candidates, weights, rng)
    micro = selection.item
    used_cues = {a.cue_id for i, a in enumerate(current_actions) if i != target_idx}
    cue = _select_cue(micro, context, used_cues)
    replacement = _to_planned_action_draft(
        target_idx + 1, micro, cue, selection.propensity, context
    )
    replacement = replace(replacement, id=target.id)

    updated = list(current_actions)
    updated[target_idx] = replacement

    audit = DecisionAudit(
        policy_version=POLICY_VERSION,
        library_version=library.version,
        seed=seed,
        start_level=Level(micro.level),
        excluded_action_ids=tuple(sorted(other_ids | {target.action_id})),
        candidate_ids_by_slot=(tuple(c.id for c in candidates),),
        chosen_action_ids=(replacement.action_id,),
        propensities=(round(selection.propensity, 6),),
        inputs_summary={
            "operation": "shrink",
            "replaced_action_id": target.action_id,
            "did_shrink": True,
            "work_pattern": context.work_pattern,
            "barriers": list(context.barriers),
            "ramadan_mode": context.ramadan_mode,
        },
    )
    return tuple(updated), audit, True
