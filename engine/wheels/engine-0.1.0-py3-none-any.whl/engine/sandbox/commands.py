"""Command validation and dispatch for ``engine.sandbox.apply`` (contracts/sandbox-commands.md).

``apply`` is the single entry point. It validates the command against an explicit schema, works on
a deep copy of the incoming state, dispatches to a registered handler, and returns either
``{"ok": True, "state", "events"}`` or ``{"ok": False, "error": {"code", "message_key"}}``.
Nothing here reads the clock or uses global randomness.
"""

from __future__ import annotations

import copy
import logging
import re
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any, Literal, cast

from engine.sandbox.state import (
    CONSENT_PAIRS,
    LOCALES,
    NON_TOGGLEABLE_CONSENT,
    SandboxError,
    State,
    validate_state,
)

logger = logging.getLogger("engine.sandbox")

Event = dict[str, Any]
Handler = Callable[[State | None, dict[str, Any]], tuple[State | None, list[Event]]]

# Handlers are registered by the modules that implement each command (setup, checkin, ...).
HANDLERS: dict[str, Handler] = {}

MIN_EFFORT = 1
MAX_EFFORT = 5
MIN_ADVANCE_DAYS = 1
MAX_ADVANCE_DAYS = 30
WORK_PATTERNS = ("regular_day", "rotating", "nights")
CHECKIN_STATUSES = ("done", "partial", "skipped")
PROPOSAL_CHOICES = ("accept", "keep", "not_now")
WALKTHROUGH_ACTIONS = ("start", "next", "exit")
_TIME = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")

Kind = Literal["str", "int", "bool", "enum", "time", "str_list", "quiet_hours"]
StateNeed = Literal["required", "none", "optional"]


@dataclass(frozen=True)
class Field:
    name: str
    kind: Kind
    required: bool = True
    choices: tuple[str, ...] = ()


@dataclass(frozen=True)
class CommandSpec:
    fields: tuple[Field, ...]
    state: StateNeed = "required"


_LOCALE = Field("locale", "enum", choices=LOCALES)
_SEED = Field("seed", "int", required=False)

COMMANDS: dict[str, CommandSpec] = {
    "load_persona": CommandSpec((Field("persona_id", "str"), _LOCALE, _SEED), state="none"),
    "quick_setup": CommandSpec(
        (
            Field("areas", "str_list"),
            Field("work_pattern", "enum", choices=WORK_PATTERNS),
            Field("observes_ramadan", "bool"),
            Field("quiet_hours", "quiet_hours"),
            _LOCALE,
            _SEED,
        ),
        state="none",
    ),
    "check_in": CommandSpec(
        (
            Field("slot_id", "str"),
            Field("status", "enum", choices=CHECKIN_STATUSES),
            Field("note", "str", required=False),
            Field("effort", "int", required=False),
        )
    ),
    "advance_days": CommandSpec((Field("days", "int"),)),
    "set_context": CommandSpec(
        (
            Field("night_shift_block", "bool", required=False),
            Field("work_pattern", "enum", required=False, choices=WORK_PATTERNS),
            Field("ramadan", "bool", required=False),
        )
    ),
    "choose_barrier": CommandSpec((Field("episode_id", "str"), Field("barrier", "str"))),
    "respond_proposal": CommandSpec(
        (Field("proposal_id", "str"), Field("choice", "enum", choices=PROPOSAL_CHOICES))
    ),
    "respond_step_up": CommandSpec((Field("accept", "bool"),)),
    "set_consent": CommandSpec(
        (Field("source", "str"), Field("purpose", "str"), Field("granted", "bool"))
    ),
    "set_locale": CommandSpec((_LOCALE,)),
    "set_quiet_hours": CommandSpec((Field("start", "time"), Field("end", "time"))),
    "walkthrough": CommandSpec(
        (
            Field("action", "enum", choices=WALKTHROUGH_ACTIONS),
            Field("confirm_replace", "bool", required=False),
            Field("locale", "enum", choices=LOCALES, required=False),
        ),
        state="optional",
    ),
}


def _is_valid(field: Field, value: Any) -> bool:
    kind = field.kind
    if kind == "str":
        return isinstance(value, str) and value != ""
    if kind == "int":
        return isinstance(value, int) and not isinstance(value, bool)
    if kind == "bool":
        return isinstance(value, bool)
    if kind == "enum":
        return isinstance(value, str) and value in field.choices
    if kind == "time":
        return isinstance(value, str) and _TIME.match(value) is not None
    if kind == "str_list":
        return isinstance(value, list) and all(isinstance(item, str) for item in value)
    # quiet_hours
    return (
        isinstance(value, Mapping)
        and set(value) == {"start", "end"}
        and all(isinstance(v, str) and _TIME.match(v) for v in value.values())
    )


def validate_command(command: object) -> tuple[str, CommandSpec]:
    """Return ``(type, spec)`` for a well-formed command or raise SandboxError."""
    if not isinstance(command, Mapping) or not isinstance(command.get("type"), str):
        raise SandboxError("invalid_command")
    command_type = command["type"]
    spec = COMMANDS.get(command_type)
    if spec is None:
        raise SandboxError("invalid_command")
    names = {f.name for f in spec.fields}
    if any(key != "type" and key not in names for key in command):
        raise SandboxError("invalid_command")
    for field in spec.fields:
        if field.name not in command:
            if field.required:
                raise SandboxError("invalid_command")
            continue
        if not _is_valid(field, command[field.name]):
            raise SandboxError("invalid_command")
    _validate_semantics(command_type, command)
    return command_type, spec


def _validate_semantics(command_type: str, command: Mapping[str, Any]) -> None:
    if command_type == "advance_days" and not (
        MIN_ADVANCE_DAYS <= command["days"] <= MAX_ADVANCE_DAYS
    ):
        raise SandboxError("days_out_of_range")
    if (
        command_type == "check_in"
        and "effort" in command
        and not MIN_EFFORT <= command["effort"] <= MAX_EFFORT
    ):
        raise SandboxError("invalid_command")
    if command_type == "set_quiet_hours":
        _require_room_to_plan(command["start"], command["end"])
    if command_type == "quick_setup":
        _require_room_to_plan(command["quiet_hours"]["start"], command["quiet_hours"]["end"])
    if command_type == "set_context" and not any(
        key in command for key in ("night_shift_block", "work_pattern", "ramadan")
    ):
        raise SandboxError("invalid_command")
    if command_type == "set_consent":
        pair = f"{command['source']}:{command['purpose']}"
        if pair not in CONSENT_PAIRS or pair in NON_TOGGLEABLE_CONSENT:
            raise SandboxError("invalid_command")


def _require_room_to_plan(start: str, end: str) -> None:
    """Quiet hours must leave part of the day free, or nothing could ever be planned."""
    # Imported here: cues needs this module's neighbours, so a top-level import would be circular.
    from engine.sandbox.cues import MAX_QUIET_MIN, MINUTES_PER_DAY, to_minutes

    quiet_minutes = (to_minutes(end) - to_minutes(start)) % MINUTES_PER_DAY
    if quiet_minutes > MAX_QUIET_MIN:
        raise SandboxError("invalid_command")


def _error(code: str, message_key: str) -> dict[str, Any]:
    return {"ok": False, "error": {"code": code, "message_key": message_key}}


def _run(state: State | None, command: object) -> dict[str, Any]:
    command_type, spec = validate_command(command)
    working: State | None = None
    if spec.state == "required" and state is None:
        raise SandboxError("invalid_command")
    if spec.state != "none" and state is not None:
        working = copy.deepcopy(validate_state(state))
    handler = HANDLERS.get(command_type)
    if handler is None:
        raise SandboxError("invalid_command")
    new_state, events = handler(working, dict(cast(Mapping[str, Any], command)))
    if new_state is None:
        raise SandboxError("invalid_command")
    return {"ok": True, "state": validate_state(new_state), "events": events}


def apply(state: object, command: object) -> dict[str, Any]:
    """Apply one command to ``state`` (``None`` for setup commands); never mutates ``state``."""
    try:
        if state is not None and not isinstance(state, dict):
            raise SandboxError("invalid_state_version")
        return _run(state, command)
    except SandboxError as error:
        return _error(error.code, error.message_key)
    except Exception:
        # Never leak a traceback to the UI; details go to the log only.
        logger.exception("sandbox command failed")
        return _error("invalid_command", "errors.invalid_command")
